"""Regenerate LP-driven ecology data, convergence checks and figures."""
from pathlib import Path
from dataclasses import replace,asdict
import json,time
import numpy as np
from scipy.optimize import brentq
from ecology_dfba import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).parent
p=EcologyParameters()
checks={}
start=time.time()
def savedata(name,r):
    np.savez_compressed(HERE/(name+'.npz'),**{k:v for k,v in r.items() if isinstance(v,np.ndarray)})
def finite_jacobian(fn,y,eps=1e-6):
    y=np.asarray(y,dtype=float)
    columns=[]
    for j in range(len(y)):
        step=eps*max(1,abs(y[j]));e=np.zeros(len(y));e[j]=step
        if y[j]<step:
            columns.append((fn(y+e)-fn(y))/step)
        else:
            columns.append((fn(y+e)-fn(y-e))/(2*step))
    return np.column_stack(columns)

rng=np.random.default_rng(13)
error,residual=0.,0.
for resources in np.vstack([10**rng.uniform(-5,1,(200,3)),np.zeros((1,3))]):
    a=solve_fluxes(resources,p,'lp');b=solve_fluxes(resources,p,'analytic');m=lp_matrices(p)
    for species in ['facultative','anaerobe']:
        error=max(error,float(np.max(abs(a[species+'_fluxes']-b[species+'_fluxes']))))
        residual=max(residual,float(np.max(abs(m[species]@a[species+'_fluxes']))))
checks['lp_optimizer_equivalence_max_error']=error
checks['lp_internal_balance_max_residual']=residual
assert error<1e-7 and residual<1e-9
print('LP equivalence verified',flush=True)

cstr={}
for tag,y in [('low',[.05,1e-5,.5,10,.2]),('high',[.1,.15,.5,10,.001])]:
    r=simulate_cstr(y,500,p,'lp',rtol=1e-8,atol=1e-11,points=1001)
    fine=simulate_cstr(y,500,p,'lp',rtol=1e-10,atol=1e-13,points=1001)
    savedata('cstr-'+tag,r);cstr[tag]=r
    terminal=r['state'][-1]
    eig=np.linalg.eigvals(finite_jacobian(lambda z:rhs(0,z,p,'cstr','analytic'),terminal,1e-7))
    checks['cstr_'+tag]={'terminal_state':terminal.tolist(),'derivative_error':float(max(abs(r['terminal_derivative']))),
        'trajectory_refinement_max_error':float(np.max(abs(r['state']-fine['state']))),
        'maximum_real_eigenvalue':float(max(eig.real)),'eigenvalues':[[float(z.real),float(z.imag)] for z in eig]}
    assert max(eig.real)<0 and max(abs(r['terminal_derivative']))<1e-7
    assert np.max(abs(r['state']-fine['state']))<2e-5
print('CSTR attractors verified',flush=True)

sweeps={}
for direction in ['up','down']:
    r=hysteresis_sweep(np.linspace(.02,.8,40),direction,p,backend='lp',duration_per_step=1000,rtol=1e-8,atol=1e-11)
    fine=hysteresis_sweep(np.linspace(.02,.8,40),direction,p,backend='analytic',duration_per_step=2000,rtol=1e-10,atol=1e-13)
    sweeps[direction]=r;savedata('hysteresis-'+direction,r)
    checks['hysteresis_'+direction]={'max_derivative_error':float(max(r['derivative_error'])),
        'doubled_duration_tight_tolerance_max_final_error':float(np.max(abs(r['final_state']-fine['final_state']))),
        'all_converged':bool(np.all(r['converged']))}
    assert np.max(abs(r['final_state']-fine['final_state']))<2e-5
    assert np.all(r['converged'])
# Exact invasion threshold of B on the A-only state at this feed and respiration branch.
gstar=p.dilution_rate*p.carbon_half_saturation/(p.respiratory_yield*p.carbon_uptake_max-p.dilution_rate)
astar=p.respiratory_yield*(p.carbon_feed-gstar)
ostar_B=p.oxygen_inhibition*(p.anaerobe_yield*(1-p.crossfeed_fraction)*p.polymer_uptake_max*p.polymer_feed/(p.polymer_half_saturation+p.polymer_feed)/p.dilution_rate-1)**(1/p.inhibition_exponent)
checks['analytical_anaerobe_invasion_oxygen_supply']=float(ostar_B+p.dilution_rate/p.respiratory_yield*astar/p.oxygen_transfer)
print('Hysteresis verified',time.time()-start,flush=True)

serial={}
for tag,y in [('low',[.01,1e-7,.5,10,.2]),('high',[.1,.1,.5,10,.001])]:
    r=simulate_serial_dilution(y,60,p,'lp',rtol=1e-8,atol=1e-11,points_per_cycle=41)
    fine=simulate_serial_dilution(y,80,p,'analytic',rtol=1e-10,atol=1e-13,points_per_cycle=3)
    serial[tag]=r;savedata('serial-'+tag,r)
    post=r['post_dilution'][-1]
    def cyclemap(z):
        return dilute(simulate_batch(z,p.batch_duration,p,'analytic',rtol=1e-10,atol=1e-13,points=2)['state'][-1],p)
    eig=np.linalg.eigvals(finite_jacobian(cyclemap,post,1e-6))
    checks['serial_'+tag]={'terminal_post_dilution_state':post.tolist(),
        'cycle_difference':r['convergence_error'],
        'extra_cycles_tight_tolerance_error':float(np.max(abs(post-fine['post_dilution'][-1]))),
        'cycle_map_spectral_radius':float(max(abs(eig))),
        'cycle_map_eigenvalues':[[float(z.real),float(z.imag)] for z in eig],
        'last_cycle_growth_factors':(r['pre_dilution'][-1][:2]/r['post_dilution'][-2][:2]).tolist()}
    assert r['convergence_error']<1e-7
    assert max(abs(eig))<1 and np.max(abs(post-fine['post_dilution'][-1]))<2e-5
print('Serial dilution verified',time.time()-start,flush=True)

checks['parameters']=asdict(p)
checks['protocol_scope']='Khazaei experiments are CSTR. Serial dilution is a new protocol extension. Species and parameters are illustrative.'
checks['numerical_scope']='Local Jacobian and cycle-map eigenvalues support local stability. This is not a global basin proof. Hysteresis branches are computed with a rare-species reinoculation at each parameter step.'
checks['runtime_seconds']=time.time()-start
(HERE/'verification.json').write_text(json.dumps(checks,indent=2)+'\n')

import plot_ecology
print(json.dumps(checks,indent=2),flush=True)
