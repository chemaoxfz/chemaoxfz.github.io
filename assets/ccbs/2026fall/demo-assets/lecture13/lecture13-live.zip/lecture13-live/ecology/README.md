# A community can change the environment that determines its own persistence

This teaching model connects two small linear programs to an extracellular balance model. A facultative species consumes shared carbon and oxygen. An anaerobe consumes polymer, releases part of the polymer carbon and grows poorly in oxygen. The facultative species can remove oxygen. The anaerobe can supply the carbon that sustains oxygen removal. This positive feedback supports two stable community outcomes.

The model is inspired by Khazaei et al., Science Advances 6, eaba0353 (2020), DOI 10.1126/sciadv.aba0353. The paper studied *Klebsiella pneumoniae* and *Bacteroides thetaiotaomicron* in continuously stirred tank reactors. The present model uses generic species, lumped conversions and chosen parameters. It reproduces a mechanism and qualitative behaviors. It does not reproduce the paper's genome-scale models, experimental parameters or measured trajectories. Serial dilution is an additional protocol demonstration.

## Choose internal fluxes before advancing the environment

For the facultative species, the nonnegative flux vector is `(u_G, u_O, r, f, mu_A)`. The linear program maximizes `mu_A` subject to

```
u_G = r + f
u_O = r
mu_A = Y_R r + Y_F f
0 <= u_G <= V_G G/(K_G + G)
0 <= u_O <= V_O O/(K_O + O).
```

The variables `r` and `f` represent effective respiratory and fermentative carbon conversion. Their biomass yields are `Y_R` and `Y_F`. Because `Y_R > Y_F > 0`, the unique optimizer uses all permitted carbon, respires up to the oxygen limit and ferments the remainder. The effective yield equations are not atom-resolved reaction chemistry.

For the anaerobe, the nonnegative vector is `(u_P, b, e_G, mu_B)`. Its linear program maximizes `mu_B` subject to

```
u_P = b
e_G = alpha b
mu_B = Y_B (1 - alpha) b
0 <= u_P <= V_P P/(K_P + P) / (1 + (O/K_I)^n).
```

The fraction `alpha` is released as shared carbon. The rest supports biomass at effective yield `Y_B`. The oxygen-inhibition curve is a chosen smooth closure. It is not a measured Hill law for either paper organism.

The external state is `(X_A, X_B, G, P, O)`. In the continuously stirred tank reactor,

```
X_A_dot = (mu_A - D) X_A
X_B_dot = (mu_B - D) X_B
G_dot   = D (G_feed - G) - u_G X_A + e_G X_B
P_dot   = D (P_feed - P) - u_P X_B
O_dot   = k_La (O_star - O) - u_O X_A.
```

Oxygen is supplied through the gas-transfer term, following the form of Khazaei's oxygen balance. No additional dissolved-oxygen inflow term is included. The carbon resources and biomass use ordinary liquid flow balances. These equations hold the volume fixed.

The batch model sets `D=0` in the first four balances. Gas transfer remains active. Every 12 hours, serial dilution retains 30% of biomass and liquid and replaces the other 70% with fresh feed. Thus `X+ = 0.3 X-` and `s+ = 0.3 s- + 0.7 s_feed` for each extracellular resource. Oxygen enters with the fresh medium as well as through gas transfer during a batch.

Time is in hours. Biomass is in g dry weight/L. Resource concentrations are mmol/L. Polymer concentration is expressed as monomer-equivalent carbon. Specific substrate fluxes are mmol/(g dry weight h). Growth rates are 1/h. All chosen values are stored in `EcologyParameters` and `verification.json`.

## Run and change one quantity

The code needs NumPy, SciPy and Matplotlib for figure generation. The simulation itself needs only NumPy and SciPy.

```python
from dataclasses import replace
from ecology.ecology_dfba import EcologyParameters, solve_fluxes, simulate_cstr

p = EcologyParameters()
print(solve_fluxes([0.5, 10.0, 0.2], p))
low = simulate_cstr([0.05, 1e-5, 0.5, 10.0, 0.2], parameters=p)
high = simulate_cstr([0.1, 0.15, 0.5, 10.0, 0.001], parameters=p)
more_oxygen = replace(p, oxygen_supply=0.7)
reset = simulate_cstr(high['state'][-1], parameters=more_oxygen)
```

`backend='lp'` is the default. It solves both linear programs with SciPy's HiGHS solver at every right-hand-side evaluation. `backend='analytic'` evaluates their exact closed-form optimizers. The alternate backend is useful for fast live sweeps. It is not a different biological model.

All trajectory functions return time, the full state, a two-column biomass array, a three-column resource array, names, units and parameter metadata. Serial dilution also returns the states immediately before and after every dilution. Duplicate time values intentionally draw dilution jumps.

## What the numerical checks establish

At oxygen supply `O_star=0.2`, carbon feed `0.5`, polymer feed `10` and dilution rate `D=0.1/h`, two initial states converge to different equilibria. The facultative-only equilibrium is approximately `(0.024722, 0, 0.005556, 10, 0.150556)`. The coexistence equilibrium is approximately `(0.134263, 0.198571, 0.012737, 0.071429, 0.000631)` in the declared state order and units.

Both equilibria are locally stable under a finite-difference Jacobian check. The largest real parts are about `-0.10/h`. Tighter ODE tolerances change the plotted trajectories by at most `1.7e-7` in their native units. Final derivative residuals are below `2e-12`.

Increasing oxygen supply keeps the coexistence branch until between `0.56` and `0.58 mmol/L` on the plotted grid. Decreasing oxygen supply restores coexistence between `0.08` and `0.10 mmol/L`. The exact anaerobe-invasion threshold on the facultative-only branch is about `0.081938 mmol/L` for the chosen model. Each continuation step reintroduces an extinct species at `1e-8 gDW/L` before integration. There is no immigration during integration. This stated invasion probe prevents numerical extinction from artificially preventing recovery. Doubling the holding time from 1000 to 2000 hours changes the final sweep states by less than `1.4e-10`.

Serial dilution also has two stable repeatable cycles. Their post-dilution biomasses are approximately `(0.0075, 0)` and `(0.038629, 0.060000) gDW/L`. At coexistence, each species grows by the factor `1/0.3` within a cycle, exactly compensating dilution. The final cycle differences are below `6e-11`. The cycle-map spectral radii are below `0.324`, supporting local stability. The checks do not prove global basin geometry.

The actual LP solver and the closed-form optimizer agree to below `3e-17` over 201 sampled and boundary resource states. Internal balance residuals are zero at recorded precision. These checks are in `verification.json`. Run `generate_evidence.py` to regenerate the evidence. Run `plot_ecology.py` to redraw the figures from the saved data without recomputing the trajectories.

## Figures and data

`ecology-cstr-hysteresis.svg` compares the two continuously stirred tank reactor trajectories, their dissolved oxygen levels and the oxygen continuation experiment. Solid trajectories begin in the coexistence basin. Dashed trajectories begin in the facultative-only basin. The hysteresis sweep uses the invasion probe described above.

`ecology-serial-dilution.svg` shows convergence of the post-dilution biomasses and the final three growth-and-dilution cycles. Solid curves show coexistence. Dashed curves show the facultative-only cycle. Low oxygen recurs during each coexistence cycle, even though oxygen recovers after the carbon resources are exhausted.

The SVGs use three vertically stacked panels for readable embedding in the core. Wide PNGs remain available for notebook use. Each SVG also has a `-core-preview.png` rendering. The six compressed `.npz` files contain the plotted arrays.
