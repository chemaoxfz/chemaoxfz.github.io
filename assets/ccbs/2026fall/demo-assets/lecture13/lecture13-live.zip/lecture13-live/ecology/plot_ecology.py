"""Redraw checked LP data. SVGs use a vertical reading layout for the core."""
from pathlib import Path
import re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ecology_dfba import EcologyParameters
HERE=Path(__file__).parent
p=EcologyParameters()
cstr={tag:dict(np.load(HERE/('cstr-'+tag+'.npz'))) for tag in ['low','high']}
serial={tag:dict(np.load(HERE/('serial-'+tag+'.npz'))) for tag in ['low','high']}
sweeps={tag:dict(np.load(HERE/('hysteresis-'+tag+'.npz'))) for tag in ['up','down']}
plt.rcParams.update({'font.family':'serif','font.serif':['Georgia','STIXGeneral'],'mathtext.fontset':'stix',
                     'font.size':12,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none',
                     'svg.hashsalt':'lecture13-ecology','figure.facecolor':'#fffdf8','axes.facecolor':'#fffdf8',
                     'savefig.facecolor':'#fffdf8','text.color':'#242424',
                     'axes.labelcolor':'#242424','xtick.color':'#242424','ytick.color':'#242424'})
colors=['#a54424','#237a80'];lowcolor='#a16f26';highcolor='#267d82'

def save(fig,name,vertical):
    if not vertical:
        fig.savefig(HERE/(name+'.png'),dpi=180)
        return
    fig.savefig(HERE/(name+'-core-preview.png'),dpi=130)
    svg=HERE/(name+'.svg')
    fig.savefig(svg,transparent=True)
    text=svg.read_text()
    color_map={'#242424':'var(--fg, #242424)','#000000':'var(--fg, #242424)',
               '#b0b0b0':'var(--rule, #cccccc)',
               '#a54424':'var(--coral, #a54424)','#237a80':'var(--teal, #237a80)',
               '#a16f26':'var(--peri, #a16f26)','#267d82':'var(--teal, #267d82)'}
    for old,new in color_map.items():text=text.replace(old,new)
    for old in re.findall(r'id="([^"]+)"',text):
        new='l13ec-'+name+'-'+old
        text=text.replace('id="'+old+'"','id="'+new+'"').replace('url(#'+old+')','url(#'+new+')').replace('href="#'+old+'"','href="#'+new+'"')
    svg.write_text(text)

def legend(ax,vertical):
    if vertical:
        ax.legend(frameon=False,fontsize=11,loc='upper center',bbox_to_anchor=(.5,-.22),ncol=2)
    else:ax.legend(frameon=False,fontsize=8,loc='center right')

def draw_cstr(vertical):
    fig,ax=plt.subplots(3 if vertical else 1,1 if vertical else 3,
                        figsize=(8.8,11.5) if vertical else (12,3.7),layout='constrained')
    for tag,style in [('low','--'),('high','-')]:
        r=cstr[tag]
        for j,name in enumerate(['Facultative species','Anaerobe']):
            ax[0].plot(r['t'],r['biomass'][:,j],style,color=colors[j],lw=2,label=name if tag=='high' else None)
        ax[1].plot(r['t'],r['resources'][:,2],style,lw=2,color=lowcolor if tag=='low' else highcolor,
                   label='Facultative species alone' if tag=='low' else 'Coexistence')
    for direction,style in [('up','-'),('down','--')]:
        r=sweeps[direction]
        ax[2].plot(r['feed'],r['biomass'][:,1],style,marker='o',ms=3,lw=2,
                   color=highcolor if direction=='up' else lowcolor,
                   label='Increasing oxygen supply' if direction=='up' else 'Decreasing oxygen supply')
    ax[0].set(xlim=(0,100),xlabel='Time (h)',ylabel='Biomass (gDW/L)',title='Same supply, two community outcomes')
    ax[1].set(xlim=(0,100),xlabel='Time (h)',ylabel='Dissolved oxygen (mmol/L)',title='Oxygen removal sustains the anaerobe')
    ax[2].set(xlabel='Oxygen supply O* (mmol/L)',ylabel='Anaerobe biomass (gDW/L)',title='The switching threshold depends on history')
    for a in ax:legend(a,vertical);a.grid(alpha=.15)
    save(fig,'ecology-cstr-hysteresis',vertical);plt.close(fig)

def draw_serial(vertical):
    fig,ax=plt.subplots(3 if vertical else 1,1 if vertical else 3,
                        figsize=(8.8,11.5) if vertical else (12,3.7),layout='constrained')
    for tag,style in [('low','--'),('high','-')]:
        r=serial[tag]
        for j,name in enumerate(['Facultative species','Anaerobe']):
            ax[0].plot(np.arange(1,61),r['post_dilution'][:,j],style,color=colors[j],lw=2,label=name if tag=='high' else None)
        mask=r['t']>=57*p.batch_duration
        for j in [0,1]:
            ax[1].plot(r['t'][mask]-57*p.batch_duration,r['biomass'][mask,j],style,color=colors[j],lw=2)
        ax[2].plot(r['t'][mask]-57*p.batch_duration,r['resources'][mask,2],style,lw=2,
                   color=lowcolor if tag=='low' else highcolor,label='Facultative species alone' if tag=='low' else 'Coexistence')
    ax[0].set(xlabel='Dilution cycle',ylabel='Post-dilution biomass (gDW/L)',title='Two stable cycles survive the same dilution protocol')
    ax[1].set(xlabel='Time across final three cycles (h)',ylabel='Biomass (gDW/L)',title='Growth compensates for each 70% dilution')
    ax[2].set(xlabel='Time across final three cycles (h)',ylabel='Dissolved oxygen (mmol/L)',title='Anaerobiosis recurs within each coexistence cycle')
    for a in ax:a.grid(alpha=.15)
    legend(ax[0],vertical);legend(ax[2],vertical)
    save(fig,'ecology-serial-dilution',vertical);plt.close(fig)

for vertical in [False,True]:
    draw_cstr(vertical);draw_serial(vertical)
