"""Redraw checked LP data. SVGs use a vertical reading layout for the core."""
from pathlib import Path
import re
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ecology_dfba import EcologyParameters
HERE=Path(__file__).parent
notebooks=HERE.parent/'notebooks'
if not (notebooks/'ecology_plot.py').exists():notebooks=HERE.parents[4]/'lecture13-live/notebooks'
sys.path.insert(0,str(notebooks))
from ecology_plot import community_figure, serial_figure
p=EcologyParameters()
cstr={tag:dict(np.load(HERE/('cstr-'+tag+'.npz'))) for tag in ['low','high']}
serial={tag:dict(np.load(HERE/('serial-'+tag+'.npz'))) for tag in ['low','high']}
sweeps={tag:dict(np.load(HERE/('hysteresis-'+tag+'.npz'))) for tag in ['up','down']}
plt.rcParams.update({'font.family':'serif','font.serif':['Georgia','STIXGeneral'],'mathtext.fontset':'stix',
                     'font.size':12,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none',
                     'svg.hashsalt':'lecture13-ecology','figure.facecolor':'#fffdf8','axes.facecolor':'#fffdf8',
                     'savefig.facecolor':'#fffdf8','text.color':'#242424',
                     'axes.labelcolor':'#242424','xtick.color':'#242424','ytick.color':'#242424'})
colors=['#a54424','#237a80'];lowcolor='#a16f26';highcolor='#267d82'

def save(fig,name,vertical):
    if not vertical:
        fig.savefig(HERE/(name+'.png'),dpi=180)
        return
    fig.savefig(HERE/(name+'-core-preview.png'),dpi=130)
    svg=HERE/(name+'.svg')
    fig.savefig(svg,transparent=True)
    text=svg.read_text()
    color_map={'#242424':'var(--fg, #242424)','#000000':'var(--fg, #242424)',
               '#b0b0b0':'var(--rule, #cccccc)',
               '#a54424':'var(--coral, #a54424)','#237a80':'var(--teal, #237a80)',
               '#ee8168':'var(--coral, #EE8168)','#1f9a8e':'var(--teal, #1F9A8E)',
               '#5a73ce':'var(--peri, #5A73CE)','#77488c':'var(--plum, #77488C)',
               '#555555':'var(--muted, #555555)','#777777':'var(--muted, #777777)',
               '#ffffff':'var(--bg2, #ffffff)',
               '#a16f26':'var(--peri, #a16f26)','#267d82':'var(--teal, #267d82)'}
    for old,new in color_map.items():text=text.replace(old,new)
    for old in re.findall(r'id="([^"]+)"',text):
        new='l13ec-'+name+'-'+old
        text=text.replace('id="'+old+'"','id="'+new+'"').replace('url(#'+old+')','url(#'+new+')').replace('href="#'+old+'"','href="#'+new+'"')
    svg.write_text(text)

def legend(ax,vertical):
    if vertical:
        ax.legend(frameon=False,fontsize=11,loc='upper center',bbox_to_anchor=(.5,-.22),ncol=2)
    else:ax.legend(frameon=False,fontsize=8,loc='center right')

def draw_cstr(vertical):
    fig=community_figure(cstr,sweeps,oxygen_supply=p.oxygen_supply)
    save(fig,'ecology-cstr-hysteresis',vertical)
    plt.close(fig)


def draw_serial(vertical):
    fig=serial_figure(serial,batch_duration=p.batch_duration,retained_fraction=p.retained_fraction)
    save(fig,'ecology-serial-dilution',vertical)
    plt.close(fig)

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--only',choices=['cstr','serial'])
    args=parser.parse_args()
    for vertical in [False,True]:
        if args.only in [None,'cstr']:draw_cstr(vertical)
        if args.only in [None,'serial']:draw_serial(vertical)
