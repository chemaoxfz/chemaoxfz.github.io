"""Small LP-driven microbial ecology model for Lecture 13.

An illustrative reduction inspired by Khazaei et al. (2020), not a reproduction
of their organisms, genome-scale reconstructions, parameters or trajectories.
Time: h. Biomass: g dry weight / L. Resources: mmol / L (polymer expressed as
monomer-equivalent carbon). Uptake: mmol / (g dry weight h). Growth: 1 / h.

Each species maximizes its own instantaneous biomass flux. Three internal
lumped balances constrain each LP. External resources and biomass evolve.
Default backend='lp' solves two scipy.optimize.linprog problems per RHS call.
backend='analytic' evaluates the rigorously equivalent optimizer of these tiny
LPs. It is provided for interactive sweeps, with equivalence verified separately.
"""
from dataclasses import dataclass, asdict, replace
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import linprog

STATE_NAMES = ('facultative_biomass', 'anaerobe_biomass', 'shared_carbon', 'polymer_carbon', 'oxygen')
RESOURCE_NAMES = STATE_NAMES[2:]
UNITS = {'time': 'h', 'biomass': 'gDW/L', 'resources': 'mmol/L', 'growth_rate': '1/h', 'uptake_flux': 'mmol/(gDW h)'}

@dataclass(frozen=True)
class EcologyParameters:
    dilution_rate: float = .1
    oxygen_transfer: float = 1.
    oxygen_supply: float = .2
    carbon_feed: float = .5
    polymer_feed: float = 10.
    carbon_uptake_max: float = 20.
    oxygen_uptake_max: float = 25.
    polymer_uptake_max: float = 12.
    carbon_half_saturation: float = .05
    oxygen_half_saturation: float = .01
    polymer_half_saturation: float = .1
    oxygen_inhibition: float = .03
    inhibition_exponent: float = 4.
    respiratory_yield: float = .05
    fermentative_yield: float = .01
    anaerobe_yield: float = .04
    crossfeed_fraction: float = .5
    batch_duration: float = 12.
    retained_fraction: float = .3

    def __post_init__(self):
        positive = ('oxygen_transfer','carbon_uptake_max','oxygen_uptake_max','polymer_uptake_max',
                    'carbon_half_saturation','oxygen_half_saturation','polymer_half_saturation',
                    'oxygen_inhibition','inhibition_exponent','respiratory_yield','fermentative_yield',
                    'anaerobe_yield','batch_duration')
        if any(getattr(self,k) <= 0 for k in positive):
            raise ValueError('Capacities, half-saturations, yields and times must be positive.')
        if any(getattr(self,k)<0 for k in ('dilution_rate','oxygen_supply','carbon_feed','polymer_feed')):
            raise ValueError('Feed and dilution parameters must be nonnegative.')
        if not 0 <= self.crossfeed_fraction < 1 or not 0 < self.retained_fraction < 1:
            raise ValueError('Crossfeed fraction must be in [0,1), retained fraction in (0,1).')
        if self.respiratory_yield <= self.fermentative_yield:
            raise ValueError('This demonstration requires a higher respiratory biomass yield.')


def lp_matrices(parameters=None):
    """Three steady internal balances per species, with explicit flux names.

    A balances carbon, respiratory oxygen and biomass equivalents.
    B balances polymer conversion, released carbon and biomass equivalents.
    The biomass rows use effective yields. They are not atom-resolved chemistry.
    """
    p=parameters or EcologyParameters()
    a=np.array([[1,0,-1,-1,0],[0,1,-1,0,0],
                [0,0,p.respiratory_yield,p.fermentative_yield,-1.]])
    b=np.array([[1,-1,0,0],[0,p.crossfeed_fraction,-1,0],
                [0,p.anaerobe_yield*(1-p.crossfeed_fraction),0,-1.]])
    return {'facultative': a, 'anaerobe': b,
            'facultative_flux_names': ('carbon_uptake','oxygen_uptake','respiration','fermentation','growth'),
            'anaerobe_flux_names': ('polymer_uptake','polymer_conversion','carbon_export','growth')}


def uptake_bounds(resources, parameters=None):
    p=parameters or EcologyParameters()
    g,poly,o=np.maximum(np.asarray(resources,dtype=float),0.)
    return np.array([p.carbon_uptake_max*g/(p.carbon_half_saturation+g),
                     p.oxygen_uptake_max*o/(p.oxygen_half_saturation+o),
                     p.polymer_uptake_max*poly/(p.polymer_half_saturation+poly)
                     /(1+(o/p.oxygen_inhibition)**p.inhibition_exponent)])


def solve_fluxes(resources, parameters=None, backend='lp'):
    p=parameters or EcologyParameters()
    ug,uo,up=uptake_bounds(resources,p)
    if backend == 'lp':
        mats=lp_matrices(p)
        ra=linprog([0,0,0,0,-1.],A_eq=mats['facultative'],b_eq=np.zeros(3),
                   bounds=[(0,ug),(0,uo),(0,None),(0,None),(0,None)],method='highs')
        rb=linprog([0,0,0,-1.],A_eq=mats['anaerobe'],b_eq=np.zeros(3),
                   bounds=[(0,up),(0,None),(0,None),(0,None)],method='highs')
        if not ra.success or not rb.success:
            raise RuntimeError(f'LP failure: {ra.message}; {rb.message}')
        a,b=np.maximum(ra.x,0),np.maximum(rb.x,0)
    elif backend == 'analytic':
        respiration=min(ug,uo)
        fermentation=ug-respiration
        a=np.array([ug,respiration,respiration,fermentation,
                    p.respiratory_yield*respiration+p.fermentative_yield*fermentation])
        b=np.array([up,up,p.crossfeed_fraction*up,p.anaerobe_yield*(1-p.crossfeed_fraction)*up])
    else:
        raise ValueError('backend must be lp or analytic')
    return {'facultative_fluxes':a,'anaerobe_fluxes':b,'growth_rate':np.array([a[-1],b[-1]]),
            'carbon_uptake':a[0],'oxygen_uptake':a[1],'polymer_uptake':b[0],
            'carbon_export':b[2],'backend':backend}


def rhs(t, state, parameters=None, protocol='cstr', backend='lp'):
    p=parameters or EcologyParameters()
    a,b,g,poly,o=np.maximum(np.asarray(state,dtype=float),0.)
    v=solve_fluxes([g,poly,o],p,backend)
    out=np.array([v['growth_rate'][0]*a, v['growth_rate'][1]*b,
                  -v['carbon_uptake']*a+v['carbon_export']*b,
                  -v['polymer_uptake']*b,
                  p.oxygen_transfer*(p.oxygen_supply-o)-v['oxygen_uptake']*a])
    if protocol=='cstr':
        out[:4]+=p.dilution_rate*(np.array([0,0,p.carbon_feed,p.polymer_feed])-np.array([a,b,g,poly]))
    elif protocol!='batch':
        raise ValueError('protocol must be cstr or batch')
    return out


def _result(t,state,p,protocol,backend,**extra):
    state=np.maximum(np.asarray(state),0.)
    return dict(t=np.asarray(t),state=state,biomass=state[:,:2],resources=state[:,2:],
                state_names=STATE_NAMES,resource_names=RESOURCE_NAMES,units=UNITS,
                metadata={'protocol':protocol,'backend':backend,'parameters':asdict(p),
                          'model_status':'illustrative reduction, not paper reproduction'},**extra)


def _simulate(initial_state,duration,p,protocol,backend,rtol,atol,points):
    initial_state=np.asarray(initial_state,dtype=float)
    if initial_state.shape!=(5,) or np.any(initial_state<0) or duration<=0:
        raise ValueError('Use a nonnegative five-entry state and positive duration.')
    grid=None if points is None else np.linspace(0,duration,points)
    sol=solve_ivp(lambda t,y:rhs(t,y,p,protocol,backend),(0,duration),initial_state,
                  t_eval=grid,rtol=rtol,atol=atol,method='LSODA')
    if not sol.success:
        raise RuntimeError(sol.message)
    return _result(sol.t,sol.y.T,p,protocol,backend,solver_nfev=sol.nfev,
                   minimum_unclipped_state=float(sol.y.min()),
                   terminal_derivative=rhs(sol.t[-1],sol.y[:,-1],p,protocol,backend))


def simulate_cstr(initial_state=None,duration=500.,parameters=None,backend='lp',
                  rtol=1e-7,atol=1e-10,points=501):
    p=parameters or EcologyParameters()
    if initial_state is None:
        initial_state=[.1,.15,p.carbon_feed,p.polymer_feed,.001]
    return _simulate(initial_state,duration,p,'cstr',backend,rtol,atol,points)


def simulate_batch(initial_state=None,duration=None,parameters=None,backend='lp',
                   rtol=1e-7,atol=1e-10,points=241):
    p=parameters or EcologyParameters()
    if initial_state is None:
        initial_state=[.02,.02,p.carbon_feed,p.polymer_feed,p.oxygen_supply]
    return _simulate(initial_state,duration or p.batch_duration,p,'batch',backend,rtol,atol,points)


def dilute(state,parameters=None):
    p=parameters or EcologyParameters()
    out=p.retained_fraction*np.maximum(np.asarray(state),0.)
    out[2:]+=(1-p.retained_fraction)*np.array([p.carbon_feed,p.polymer_feed,p.oxygen_supply])
    return out


def simulate_serial_dilution(initial_state=None,cycles=40,parameters=None,backend='lp',
                             rtol=1e-7,atol=1e-10,points_per_cycle=41):
    p=parameters or EcologyParameters()
    if initial_state is None:
        initial_state=[.1,.1,p.carbon_feed,p.polymer_feed,.001]
    state=np.asarray(initial_state,dtype=float)
    if cycles<1: raise ValueError('cycles must be positive')
    ts,ys,cs,pre,post=[],[],[],[],[]
    for cycle in range(cycles):
        result=simulate_batch(state,p.batch_duration,p,backend,rtol,atol,points_per_cycle)
        ts.extend(result['t']+cycle*p.batch_duration)
        ys.extend(result['state'])
        cs.extend([cycle]*len(result['t']))
        pre.append(result['state'][-1])
        state=dilute(pre[-1],p)
        post.append(state)
        # Duplicate time intentionally represents the discontinuous dilution jump.
        ts.append((cycle+1)*p.batch_duration);ys.append(state);cs.append(cycle+1)
    post=np.asarray(post)
    delta=np.max(np.abs(post[-1]-post[-2])) if cycles>1 else float('nan')
    return _result(ts,ys,p,'serial dilution',backend,cycle=np.asarray(cs),
                   pre_dilution=np.asarray(pre),post_dilution=post,
                   dilution_times=np.arange(1,cycles+1)*p.batch_duration,
                   convergence_error=float(delta),converged=bool(delta<1e-7))


def hysteresis_sweep(feed_values,direction='up',parameters=None,control='oxygen_supply',
                     initial_state=None,backend='lp',duration_per_step=500.,
                     invasion_seed=1e-8,rtol=1e-7,atol=1e-10):
    """Quasistatic continuation, with a stated rare-species invasion probe.

    A species below invasion_seed is reinoculated to that biomass at the START
    of each parameter step. There is no immigration term during integration.
    This avoids treating numerical extinction as an irreversible absorbing state.
    Return values follow the requested traversal order. Not all feed ranges
    contain both bifurcations. The demonstration varies oxygen supply.
    """
    p=parameters or EcologyParameters()
    vals=np.sort(np.asarray(feed_values,dtype=float))
    if direction=='down': vals=vals[::-1]
    elif direction!='up': raise ValueError('direction must be up or down')
    if control not in ('oxygen_supply','carbon_feed','polymer_feed'):
        raise ValueError('control must name a feed parameter')
    if initial_state is None:
        initial_state=[.1,.15,p.carbon_feed,p.polymer_feed,.001] if direction=='up' else [.05,invasion_seed,p.carbon_feed,p.polymer_feed,vals[0]]
    state=np.asarray(initial_state,dtype=float)
    states,errors=[],[]
    for val in vals:
        current=replace(p,**{control:float(val)})
        state=state.copy();state[:2]=np.maximum(state[:2],invasion_seed)
        result=simulate_cstr(state,duration_per_step,current,backend,rtol,atol,points=2)
        state=result['state'][-1]
        states.append(state);errors.append(np.max(np.abs(result['terminal_derivative'])))
    states=np.asarray(states)
    comp=states[:,1]/np.maximum(states[:,:2].sum(axis=1),1e-300)
    return dict(feed=vals,control_values=vals,control=control,direction=direction,
                final_state=states,biomass=states[:,:2],resources=states[:,2:],
                composition=comp,derivative_error=np.asarray(errors),
                converged=np.asarray(errors)<1e-7,state_names=STATE_NAMES,
                resource_names=RESOURCE_NAMES,units=UNITS,
                metadata={'parameters':asdict(p),'backend':backend,'invasion_seed':invasion_seed,
                          'duration_per_step':duration_per_step,'model_status':'illustrative reduction'})
