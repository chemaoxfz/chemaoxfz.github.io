import json
from pathlib import Path
import numpy as np
import enzyme_capacity as model
checks=[]
def check(name,ok):
 assert bool(ok),name
 checks.append(name)
for e in [(.6,.4),(.9,.4),(.1,1.)]:
 for u in [0.,1.,5.,10.,20.]:
  for q in [None,0.,.1,1.,100.]:
   d=model.parallel(e,u,q);cap=np.array(e)*[10,5]
   if q is not None:cap*=q/(np.array([1,.05])+q)
   check(f'analytic optimum e={e} u={u} q={q}',np.isclose(d['output'],min(u,sum(cap))))
   check(f'capacity residual e={e} u={u} q={q}',min(d['unused'])>=-1e-10)
for task in [0.,.5,1.,2.,3.]:
 d=model.shared(task)
 check(f'shared capacity {task}',np.isclose(d['output'],6-2*task))
check('exact occupancy example',np.isclose(model.parallel(substrate=.1)['output'],62/33))
check('saved results',json.loads((Path(__file__).parent / 'data/enzyme-results.json').read_text())==model.report())
Path(__file__).with_name('enzyme-verification.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2)+'\n')
print(len(checks),'analytic capacity checks passed.')
