"""Check energies against equilibrium constants and fluxes against elimination."""
import json
from pathlib import Path
import numpy as np
from scipy.linalg import null_space
import thermodynamics as model

checks = []


def check(name, ok):
    assert bool(ok), name
    checks.append(name)


# Independent algebra: ΔG = RT log(Q/Keq).
rt = 8.31446261815324 * 298.15 / 1000
keq = np.exp(17.8 / rt)
for ratio, expected_sign in [(1., -1), (.001, 1)]:
    q = 10 / ratio
    energy = rt * np.log(q / keq)
    check(f"energy identity {ratio}", np.isclose(energy, model.reaction_energy(ratio)))
    check(f"energy sign with uncertainty {ratio}",
          all(np.sign(energy + delta) == expected_sign for delta in [-.5, .5]))
    for constrained in [False, True]:
        result = model.optimize(ratio, constrained)
        flux = np.array(result["flux"])
        # Four independent rows equate every flux to the hexokinase flux.
        expected = 0. if constrained and energy > 0 else 10.
        check(f"elimination optimum {ratio} {constrained}",
              np.allclose(flux, expected))
        check(f"all balances {ratio} {constrained}", np.max(abs(model.S @ flux)) < 1e-12)
        check(f"nonnegative flux {ratio} {constrained}", np.min(flux) >= 0)
check("four independent balances", np.linalg.matrix_rank(model.S) == 4)
check("one shared flux degree of freedom",
      np.allclose(abs(null_space(model.S).ravel()), 1/np.sqrt(5)))
threshold = 10/keq
check("equilibrium", abs(model.reaction_energy(threshold)) < 1e-12)
check("no net forward flux at equilibrium", model.optimize(threshold)["output"] == 0)
check("ATP decade", np.isclose(model.reaction_energy(10)-model.reaction_energy(1),
                               -rt*np.log(10)))
check("product decade", np.isclose(model.reaction_energy(1, 100)-model.reaction_energy(1, 10),
                                   rt*np.log(10)))
check("temperature units", np.isclose(rt, 2.4789570296023884))
report = model.report()
check("saved results reproduce", report == json.loads(
    (Path(__file__).parent / "data/thermodynamics-results.json").read_text()))
Path(__file__).with_name("thermodynamics-verification.json").write_text(
    json.dumps({"passed": len(checks), "checks": checks}, indent=2)+"\n")
print(f"{len(checks)} independent algebra and optimization checks passed.")
