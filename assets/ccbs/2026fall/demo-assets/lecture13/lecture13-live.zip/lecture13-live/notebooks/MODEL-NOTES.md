# What the tutorial computes

Each experiment asks which additional information changes a prediction. A published reconstruction, a published reduced equation and a new illustrative model have different evidential status. They are identified separately below.

## Real model inspection and nutrient comparisons

The first experiments load unchanged BiGG JSON files. iJO1366 contains 1,805 compartment-specific metabolite entries and 2,583 reaction entries in this serialization. The latter includes exchanges and bookkeeping reactions. These counts should not be confused with the 1,136 unique metabolites and 2,251 metabolic reactions reported in the original reconstruction paper. The smaller E. coli core file has 72 metabolite entries and 95 reactions. Both are loaded locally.

The optimization maximizes the biomass-reaction flux subject to `S v = 0` and the archived bounds. Exchange uptake is negative. The tutorial changes glucose, oxygen and succinate lower bounds inside a restoring model context. With glucose uptake capped at 10 mmol/(gDW h), growth is about 0.982372/h at oxygen cap 20, 0.491545/h at cap 5 and 0.241502/h without oxygen. Succinate uptake capped at 20 gives about 0.777439/h with oxygen cap 20. The anaerobic succinate case is infeasible with the model's maintenance and other requirements retained.

The signed biomass table contains all 72 nonzero entries. Its display is ranked by absolute coefficient. A negative entry is consumed and a positive entry is produced. Large ATP, ADP, water, phosphate and H⁺ terms include energetic bookkeeping. Their magnitude does not rank mass fractions or cellular concentrations. Flux variability analysis illustrates that an optimal flux vector need not be unique.

Source: Orth et al., *Molecular Systems Biology* 7, 535 (2011), [DOI 10.1038/msb.2011.65](https://doi.org/10.1038/msb.2011.65), pp. 1–2 and Table I. Model URLs, original archive date and SHA-256 checksums are in `models/PROVENANCE.json`.

## Batch dynamic FBA adds the external environment

At every ODE evaluation, a fresh intracellular LP returns growth `mu` and the glucose exchange flux. The environmental balances are

```text
dX/dt = mu(G) X
dG/dt = v_EX,glucose(G) X
glucose uptake capacity = 10 G/(0.5 + G).
```

Time is hours, biomass `X` is gDW/L and glucose `G` is mmol/L. The uptake capacity is mmol/(gDW h). Initial values are `X=0.05` and `G=10`. Oxygen uptake is capped at 20. ATP maintenance is set to zero for this isolated depletion example. This removes the separate starvation-feasibility problem. Integration stops at `G=10^-5`, then appends no growth. This is a declared endpoint convention.

For these bounds, the independently solved LPs give constant biomass yield 0.0916647464 gDW/mmol glucose. Consequently `X + 0.0916647464 G` is conserved. The glucose threshold is reached at about 4.099 h and final biomass is about 0.966647 gDW/L. Doubling initial biomass speeds depletion and adds 0.05 gDW/L to the final biomass. Internal concentrations are not simulated.

This is a new numerical setup illustrating a sequential LP/external-ODE implementation. Mahadevan et al. also formulated a broader dynamic optimization problem with metabolite balances and flux-change constraints. It would be inaccurate to say every historical dFBA formulation eliminates all metabolite dynamics. Source: Mahadevan, Edwards and Doyle, *Biophysical Journal* 83, 1331–1340 (2002), [DOI 10.1016/S0006-3495(02)73903-9](https://doi.org/10.1016/S0006-3495(02)73903-9), pp. 1332–1333, Eqs. 2–5.

## A protein budget changes the preferred pathway

The illustrative LP has substrate processing `u`, respiration `r`, fermentation `f` and growth `mu`:

```text
maximize mu
u = r + f
mu = 0.4 r + 0.2 f
0.12 r + 0.03 f + 0.5 mu <= 0.5
0 <= u <= uptake capacity, r >= 0, f >= 0, mu >= 0.
```

Growth is per hour. The pathway flux unit is chosen so the yield coefficients convert it to growth. The first two protein-cost coefficients carry the inverse pathway-flux unit. The growth-associated cost 0.5 has units of hours. Every term in the protein inequality is a dimensionless proteome fraction. The coefficients are chosen for teaching and are not fitted E. coli measurements.

Eliminating growth gives protein cost `0.32 r + 0.13 f <= 0.5`. Respiration gives more growth per unit substrate. Fermentation gives more growth per unit protein. The optimal all-respiration state reaches the protein budget at uptake 1.5625. Between uptake 1.5625 and 3.8461538, both pathways operate. Above 3.8461538, the optimum is all fermentation, with growth 0.7692308/h and unused uptake capacity. Without the protein inequality, the model always respires and growth continues to rise as `0.4 × uptake capacity`.

The mechanism follows protein-allocation work. It is not a reproduction of a genome-scale constrained allocation FBA fit. Sources: Basan et al., *Nature* 528, 99–104 (2015), [DOI 10.1038/nature15765](https://doi.org/10.1038/nature15765), pp. 99–101, Eqs. 2–4 and Box 1. Mori et al., *PLoS Computational Biology* 12, e1004913 (2016), [DOI 10.1371/journal.pcbi.1004913](https://doi.org/10.1371/journal.pcbi.1004913), pp. 4–7, Eqs. 2–12 and Fig. 1.

## Mori rich-medium upshifts retain ribosome inventory

For total protein mass `M`, ribosomal protein mass `M_R`, fraction `phi_R=M_R/M`, ribosomal allocation `chi_R` and synthesis activity `sigma`, the source equations are

```text
dM/dt   = sigma M_R
dM_R/dt = sigma chi_R M_R
dphi_R/dt = sigma phi_R (chi_R - phi_R)
growth = sigma phi_R.
```

In the paper's rich-medium approximation, `sigma` and `chi_R` jump to their final constant values. Ribosome fraction retains memory. For final growth `mu_f`, initial post-shift growth `mu_0`, and elapsed time `t`,

```text
growth(t) = mu_f / [1 + (mu_f/mu_0 - 1) exp(-mu_f t)]
M(t)/M(0) = 1 + (mu_0/mu_f) [exp(mu_f t) - 1]
mu_0 = phi_R_initial × mu_f/phi_R_final.
```

The recovery figure uses the source scales `mu_f=2.45/h` and `phi_R_final=0.50`, with chosen initial fractions 0.03, 0.10 and 0.20. The reserve comparison is a new calculation combining this solution with the paper's Eq. 10. It assumes initial `phi_R` equals reserve `phi_0`, uses final `phi_R=0.48` and `mu_f=6(0.48-phi_0)/h`, and compares reserve fractions 0.02, 0.07 and 0.15. Larger reserve helps over a short feast. Smaller reserve eventually benefits from its higher final growth rate. The finite-duration ranking is computed, not assumed.

The model assumes metabolic precursor limitation is relieved by the rich medium. It does not describe arbitrary downshifts to incomplete media. Source: Mori et al., *Nature Communications* 8, 1225 (2017), [DOI 10.1038/s41467-017-01242-8](https://doi.org/10.1038/s41467-017-01242-8), pp. 3–4, Eqs. 2–10, and limitations on p. 7.

## Erickson carbon shifts retain translational activity

The separate carbon-shift example uses Erickson's scalar allocation dynamics, rather than assigning a new relaxation law to Mori's model:

```text
d sigma/dt = sigma [mu_f chi_Cat(sigma) - sigma chi_Rb(sigma)]
chi_Rb(sigma) = phi_0 / (1 - sigma/gamma)
chi_Cat(sigma) = max(0, 1 - sigma chi_Rb(sigma)/lambda_C)
mu_f = lambda_f/(1 - lambda_f/lambda_C).
```

Here `sigma` is total protein synthesis flux per ribosomal protein mass. It reflects elongation and the active ribosome fraction. `mu_f` is a catabolic parameter, not the realized growth rate. The source parameters are `phi_0=0.049`, `gamma=11.02/h` and `lambda_C=1.17/h`. To reconstruct growth, the helper also evolves ribosome fraction using `dphi_Rb/dt=lambda(chi_Rb-phi_Rb)`, where `lambda=sigma phi_Rb`.

The chosen upshift changes steady growth from 0.3/h to 0.8/h. Without pre-expression of the new uptake system, `sigma` starts at its old value. The chosen downshift removes one co-utilized substrate and changes steady growth from 0.8/h to 0.4/h. Its initial `sigma` drops by `mu_f/mu_i`. These initial conditions follow SI Eqs. S52 and S56. The gray first-ten-minute region identifies a regime not resolved by the coarse model. Prolonged growth arrest also lies outside its stated scope.

Source: Erickson et al., *Nature* 551, 119–123 (2017), [DOI 10.1038/nature24299](https://doi.org/10.1038/nature24299), main Eq. 5. Supplementary information pp. 8, 16–17 and 24–25, Eqs. S28–S29, S52 and S56.

## Chemical potentials exclude a spurious ATP cycle

The teaching model tracks `A`, `B`, ATP and ADP. It contains `A + ADP` to `B + ATP`, `B` to `A`, an optional supplied-fuel ATP source and an ATP drain. Phosphate, water and H⁺ are omitted chemostatted species in these transformed reactions. Their fixed contributions enter the stated ATP-synthesis free energy. Fuel and waste are also chemostatted when the legitimate source is available.

Let `d=chemical potential of B - chemical potential of A`, in kJ/mol. Set ATP synthesis cost to 30 kJ/mol. The internal reaction free energies are `d+30` and `-d`. An active direction requires free energy at most −1 kJ/mol. Both directions cannot be active: adding their inequalities would give `30 <= -2`. The fuel-coupled source has free energy −10 kJ/mol and remains admissible. A positive ATP drain has free energy −30 kJ/mol.

The helper enumerates the four possible internal direction-use patterns. It tests chemical-potential feasibility, then optimizes flux over each feasible pattern. With internal capacities 10, ordinary FBA permits ATP drain 10 without fuel and 12 with a fuel source capped at 2. Chemical-potential consistency reduces those values to 0 and 2. This is a small explicit direction-enumeration example. It is not a full genome-scale mixed-integer thermodynamic model.

Source: Henry, Broadbelt and Hatzimanikatis, *Biophysical Journal* 92, 1792–1805 (2007), [DOI 10.1529/biophysj.106.093138](https://doi.org/10.1529/biophysj.106.093138), pp. 1793–1795, Eqs. 1 and 11–16.

## Enzyme capacity and saturation impose different bounds

Two independent one-way pathways convert an internal substrate to a balanced product drain. Uptake is capped at 10. The enzyme-capacity example adds `v_i <= kcat_i E_i` with turnover values `(10,5)` and abundances `(0.6,0.4)`, giving maximum output 8. Adding saturation uses `v_i <= kcat_i E_i q/(K_i+q)` with half-saturation values `(1,0.05)`. At `q=0.1`, the maximum falls to 1.8787879.

The values use consistent normalized units. Enzyme abundance uses the same amount basis as flux. For specific flux per gram dry weight, `E_i` is an abundance per gram dry weight, not automatically a molar concentration. Saturation is a bound in this experiment. It does not assert that every realized reaction rate is known.

Source for the enzyme-capacity construction and its normalization: Sánchez et al., *Molecular Systems Biology* 13, 935 (2017), [DOI 10.15252/msb.20167411](https://doi.org/10.15252/msb.20167411), pp. 2–3 and Fig. 1. The two-pathway network and numerical values are new illustrations.

## Releasing one internal balance produces a transient

The kinetic hybrid keeps the upstream substrate pool dynamic while balancing the downstream product. At a given pool value, product maximization saturates both independent one-way kinetic bounds. There is no shared enzyme cost or competing objective in this example. Thus

```text
v1(q) = 6 q/(1+q)
v2(q) = 2 q/(0.05+q)
dq/dt = input - v1(q) - v2(q)
dB/dt = v1(q) + v2(q).
```

`B` is cumulative product. All pools, fluxes and time use declared normalized units. Input steps from 1 to 5 at time 3. The initial steady pool is 0.0336565 and the final steady pool is 1.0618153. Output is continuous at the input step. The pool accumulates before output reaches 5. Conservation gives `q(t)+B(t)=q(0)+integrated input`.

This new example is not the Covert model. It illustrates the distinction that selected internal dynamics can be retained in an optimization/kinetic hybrid. Covert et al.'s integrated FBA couples ODE fluxes, regulatory constraints and metabolite pooling to FBA. Source: Covert et al., *Bioinformatics* 24, 2044–2050 (2008), [DOI 10.1093/bioinformatics/btn352](https://doi.org/10.1093/bioinformatics/btn352), p. 2046, Section 2.1 and Fig. 3.

## Flux exponent control keeps internal catalytic dynamics

The two-pool plant has intermediate `q_I`, ATP `q_A`, activities `u1,u2`, payoff coefficient 2 and `kappa=1.1`:

```text
S = [[1,-1],[-1,2]]
v1 = 2 q_A u1
v2 = 2 kappa q_I u2
dq/dt = S v + (0,-demand).
```

The initial state `(1/kappa,1)` and activities `(0.5,0.5)` balance demand 1 exactly. Demand steps to 1.1 at time zero. At every sample, a local relative-state prediction retains the catalytic substrate dependence and optimizes changes in log activity. The 20-step horizon uses time step 0.03, concentration-error weights `(0.3,0.08)`, and activity-change penalties 3 or 5.5. The target `(1/kappa+0.07,0.93)` is an explicit task assumption. It is not inferred from stoichiometry.

The local cost sums quadratic log-concentration error and quadratic successive log-activity changes. A positive-definite linear solve finds the unconstrained minimizer. Predicted intermediate and ATP floors 0.001 and 0.6 are checked and remain inactive. A different case activating either floor raises an error instead of silently ignoring it. The held-activity plant is integrated exactly by a matrix exponential. Its executed pools remain positive.

This is adapted from the lecture's archived 2023 notebook reproduction. It retains dynamic pools and structured control. It does not impose an activity ceiling or a binding-order polytope. The optimized activities are not themselves reaction exponents. Nor is this objective pure long-horizon growth maximization. A cellular growth objective can motivate a subsystem tracking objective, but deriving that decomposition requires additional assumptions.

Source: Xiao, Li and Doyle, *American Control Conference* (2023), 1189–1194, [DOI 10.23919/ACC55779.2023.10156281](https://doi.org/10.23919/ACC55779.2023.10156281), pp. 1192–1193, Eqs. 7–11. The published source distinguishes catalytic structure, activity control and closed-loop reaction-order constraints.

## Community dynamics and protocol changes

The sibling `ecology` module contains two growth-maximizing metabolic LPs coupled to two biomass and three external-resource balances. A facultative organism consumes simple carbon and removes oxygen. An anaerobic organism consumes polymer and releases simple carbon. That mutual environmental modification supports two stable outcomes under the same continuous feed. The notebook also tests a newly chosen serial-dilution protocol and an oxygen-supply continuation experiment with an explicit rare-species invasion probe.

The original Khazaei experiment used continuously stirred tank reactors. The small teaching model is a mechanism-based reduction, not a reproduction of its genome-scale reconstructions. The oxygen equation includes gas transfer and uptake without an additional liquid-flow oxygen term. Serial dilution is a separate extension. The exact equations, units, chosen parameters and stability checks are documented in `../ecology/README.md`.

Source: Khazaei et al., *Science Advances* 6, eaba0353 (2020), [DOI 10.1126/sciadv.aba0353](https://doi.org/10.1126/sciadv.aba0353), main text pp. 1–3 and 6–7, Eqs. 1–8. The ecology computation was verified separately with actual HiGHS LPs, convergence checks and local stability calculations.

## Independent verification

The 571 notebook-model checks use independent constructions: a separate sparse HiGHS formulation of real-model FBA, primal-dual certificates, carbon-yield conservation and a separate batch ODE, polygon vertices for protein allocation, absolute protein masses for the two allocation models, analytical saturation limits, material conservation, and an independent Riccati solve plus continuous plant replay for flux exponent control. They test the equations and numerical implementation. They do not turn illustrative parameter choices into fitted biology.

The clean-kernel execution also checks that all notebook cells run in sequence without cached Python state. The portable ZIP is extracted and executed separately before delivery. The JSON data and SVG/PNG figures are generated from the same computations used in the notebook.
