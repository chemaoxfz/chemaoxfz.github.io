# Inspect the added physical assumptions

These additions extend the original experiments in `MODEL-NOTES.md`. The notebook remains the editable teaching source. Its HTML preview is an export of its executed cells.

## Read biomass entries as signed material throughput

The actual iJO1366 core biomass reaction has 72 entries. Its coefficients are mmol per gram dry weight. Multiplication by molecular weight and division by 1,000 gives grams per gram dry weight. COBRApy formula weights give gross consumed mass 29.251801 and gross produced mass 28.251806. The difference is 0.999994.

The large gross totals reflect ATP turnover and other bookkeeping. They are not dry-cell composition fractions. Removing ATP, ADP, phosphate and water from a plot is a view choice, not a complete reconstruction of polymer composition. Feist and Palsson (2010) distinguish biomass composition, synthesis energy and released byproducts.

## Match a culture protocol explicitly

`culture_protocol.py` contains two unit-yield, uptake-limited consumers. Their growth capacities are 0.6 and 1.2 per hour. Their half-saturation constants are 0.05 and 0.4 in the declared resource units. Feed concentration is one. Continuous dilution is 0.15 per hour. Serial culture retains 0.01 every 30.7011 hours.

This matches logarithmic cell loss and feed concentration. It does not match medium volume per hour. Consumer A wins in continuous culture. Consumer B wins in serial culture. Continuous rare-invasion rates and independent quadrature of resident-cycle multipliers verify the reversal. The resource and population equations are new teaching choices. They are not Khazaei's whole-genome model or a generic claim that serial dilution increases diversity.

## Test thermodynamic direction before assuming ATP can drive a reaction

`thermodynamics.py` uses Greinert et al. (2021), Scientific Reports 11:6125, Table 1. The hexokinase standard reaction energy is −17.8 ± 0.5 kJ/mol at 298.15 K and pH 7. Activities are dimensionless. At glucose-6-phosphate/glucose activity ratio ten, ATP/ADP ratios one and 0.001 give −12.09 and +5.03 kJ/mol.

Boundary exchanges maintain the stated conditions. Ordinary steady balance permits output ten in both cases. Requiring favorable forward energy reduces the second output to zero. This is a subsystem feasibility test. It does not model whole-cell ATP supply or infer a reaction speed from free energy.

## Count shared enzyme use once

`enzyme_capacity.py` exposes independent and shared catalysts. Independent enzyme capacities six and two give output eight under supply ten. Sharing a catalyst requires the sum of enzyme demands to fit its available amount. With turnover constants ten and five and amount 0.6, requiring second flux one reduces maximum first flux from six to four. The resource row represents required catalyst amount, not chemical destruction of catalyst.

## Derive the cart correspondence before identifying the states

The notebook uses the linearized Chandra, Buzi and Doyle (2011) glycolytic plant, with downstream sensitivity fixed and upstream feedback separated as an input. A stated invertible coordinate change gives angle and angular velocity for an acceleration-driven damped cart pendulum. ATP maps to a combination of angle and angular velocity. It does not map to angle alone.

The two-state analogy concerns the angular plant in a nondimensional clock. Cart translation can be integrated for the animation without imposing a cart-position objective. The optional force-driven, position-regulating cart in the reading core has four states. The finite gain limit belongs to the matched sensor family, not every possible stick-balancing controller.

## Separate terminal growth from ATP tracking

`growth_control.py` retains intermediate, ATP and log biomass. Rates are `v1=A**-2*u1`, `v2=2*I`, `vg=A*ug`, and specific growth is `0.1*vg`. Growth dilution appears in both concentration equations. Demand rises from 0.6 to 1.4. The objective is final biomass. There is no ATP-error penalty.

The released cases use ATP floors 0.75 and 0.8, a four-unit horizon, 0.1-unit control intervals and ten integration substeps. Checkpoint constraints have a numerical safety margin of 0.0001. Independent continuous integration verifies the actual ATP floor. For floor 0.75, a permitted pause gives final biomass 1.121738. Requiring growth activity at least 0.05 gives 1.117522. Halving the control interval preserves arrest and changes its duration from 0.50 to 0.55.

The JSON files are saved multiple-shooting candidate optima. Grid refinement and multiple initial policies support the stated comparisons. They do not prove a global optimum or validate the coefficients biologically. The optional notebook flag recomputes the chosen case.

## Retain precursor and protein states across a nutrient shift

`allocation_control.py` contains precursor amount, metabolic protein and ribosomal protein. Protein-equivalent units make total protein the biomass measure. Metabolic protein supplies precursor. Ribosomal protein makes new protein. A control allocates newly made protein between the two sectors.

The model omits death, degradation, transport regulation and other biomass sectors. It is an explicit teaching reduction. Its precursor and protein-fraction floors define the viable set. The two-hour notebook example solves live. The eight-hour comparisons load saved results by default.

Maximizing final biomass is equivalent to integrated specific growth under this no-death balance. Integrating absolute growth flux would instead integrate specific growth multiplied by biomass. A running exponential discount changes the objective. A fixed scalar discount multiplying terminal biomass does not.

An eight-hour final-biomass objective initially makes ribosomal protein after the upshift and metabolic protein after the downshift. Discounting running growth at two per hour reverses the downshift's initial allocation. End-of-horizon resource spending is part of the finite task. Controls late in a strongly discounted horizon are weakly determined.

Thiermann et al. (2026), Science 392:eaeb6410, studied translational inhibition and growth–stress-survival differences in bacteria. Their measurements do not assign these discount factors to either species and are not a fit to the notebook's carbon shifts.

## Reproduce independent checks

`verify_all.py` runs the original 571 checks and four additional suites:

| Suite | Independent checks |
| --- | ---: |
| Culture protocol | 19 |
| Thermodynamic reaction energy and feasible flux | 24 |
| Independent and shared enzyme capacities | 157 |
| Growth models, absolute-amount balances and numerical derivatives | 376 |

The total is 1,147. Independent constructions include analytic bounds, quadrature, separate absolute-amount ODEs, conserved material and finite-difference sensitivity checks. The notebook also checks biomass mass accounting and the cart coordinate transformation. Verification establishes the stated model calculations. It does not turn illustrative parameters into species measurements.
