"""Portable Lecture 13 computations. All reduced-model numbers are declared examples.

Real reconstructions are loaded from the bundled, unchanged BiGG JSON files.
No network retrieval occurs in this module. Scientific scope is in MODEL-NOTES.md.
"""
from pathlib import Path
from itertools import product
import json
import warnings
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.optimize import linprog, brentq
from scipy.sparse import coo_matrix
import cobra

HERE=Path(__file__).resolve().parent

def load_model(name='iJO1366'):
    model=cobra.io.load_json_model(HERE/'models'/f'{name}.json')
    model.solver='glpk'
    return model

def display_name(metabolite):
    return 'H⁺' if metabolite.id in ('h_c','h_e','h_p') else metabolite.name

def reaction_entries(reaction):
    return pd.DataFrame([dict(id=m.id,name=display_name(m),coefficient=s,
                              role='consumed' if s<0 else 'produced')
                         for m,s in reaction.metabolites.items()])

def biomass_entries(model):
    objective=next(r for r in model.reactions if abs(r.objective_coefficient)>0)
    table=reaction_entries(objective)
    table['absolute_coefficient']=table.coefficient.abs()
    return table.sort_values(['absolute_coefficient','id'],ascending=[False,True]).reset_index(drop=True)

def set_medium(model,glucose=10,oxygen=20,succinate=0):
    for rid,capacity in [('EX_glc__D_e',glucose),('EX_o2_e',oxygen),('EX_succ_e',succinate)]:
        reaction=model.reactions.get_by_id(rid)
        reaction.bounds=(-float(capacity),reaction.upper_bound)

def solve_condition(model,glucose=10,oxygen=20,succinate=0):
    """Each call restores the original model on exit, including after an error."""
    with model:
        set_medium(model,glucose,oxygen,succinate)
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore',message="Solver status is 'infeasible'.")
            solution=model.optimize(raise_error=False)
        out=dict(glucose=glucose,oxygen=oxygen,succinate=succinate,status=solution.status)
        if solution.status=='optimal':
            out['growth']=float(solution.objective_value)
            for rid in ['EX_glc__D_e','EX_o2_e','EX_ac_e','EX_co2_e','ATPM']:
                out[rid]=float(solution.fluxes[rid])
        return out

def highslp_from_json(name='iJO1366',glucose=10,oxygen=20,succinate=0):
    """Independent sparse SciPy/HiGHS formulation of the same archived JSON."""
    raw=json.loads((HERE/'models'/f'{name}.json').read_text())
    mi={m['id']:i for i,m in enumerate(raw['metabolites'])}
    ri={r['id']:i for i,r in enumerate(raw['reactions'])}
    row,col,val=[],[],[]
    for j,r in enumerate(raw['reactions']):
        for met,stoich in r['metabolites'].items():row.append(mi[met]);col.append(j);val.append(stoich)
    S=coo_matrix((val,(row,col)),shape=(len(mi),len(ri))).tocsr()
    bounds=np.array([[r['lower_bound'],r['upper_bound']] for r in raw['reactions']])
    for rid,cap in [('EX_glc__D_e',glucose),('EX_o2_e',oxygen),('EX_succ_e',succinate)]:bounds[ri[rid],0]=-cap
    objective=np.array([r.get('objective_coefficient',0) for r in raw['reactions']])
    answer=linprog(-objective,A_eq=S,b_eq=np.zeros(len(mi)),bounds=bounds,method='highs')
    return answer,S,bounds,objective

def batch_dfba(initial_biomass=.05,initial_glucose=10.,duration=12.,vmax=10.,km=.5,oxygen=20.):
    """E. coli core LP + external ODE. ATP maintenance is zero for this isolated demo.

    X: gDW/L. G: mmol/L. Uptake: mmol/(gDW h). Growth: 1/h.
    Internal pools retain S v=0. Stop at G=1e-5 mmol/L, then append no growth.
    """
    model=load_model('e_coli_core')
    model.reactions.ATPM.lower_bound=0.
    set_medium(model,glucose=vmax,oxygen=oxygen)
    glucose=model.reactions.EX_glc__D_e
    def fluxes(g):
        glucose.lower_bound=-vmax*max(g,0)/(km+max(g,0))
        solution=model.optimize()
        if solution.status!='optimal':raise RuntimeError(solution.status)
        return float(solution.objective_value),float(solution.fluxes['EX_glc__D_e'])
    def rhs(t,y):
        mu,exchange=fluxes(y[1])
        return [mu*y[0],exchange*y[0]]
    def depletion(t,y):return y[1]-1e-5
    depletion.terminal=True;depletion.direction=-1
    solved=solve_ivp(rhs,[0,duration],[initial_biomass,initial_glucose],events=depletion,
                     dense_output=True,rtol=2e-9,atol=1e-11,max_step=.1)
    if not solved.success:raise RuntimeError(solved.message)
    stop=float(solved.t[-1]);t=np.linspace(0,duration,241)
    y=solved.sol(np.minimum(t,stop)).T
    vals=np.array([fluxes(g) if ti<=stop else (0.,0.) for ti,g in zip(t,y[:,1])])
    return dict(t=t,biomass=y[:,0],glucose=y[:,1],growth=vals[:,0],glucose_exchange=vals[:,1],
                stop_time=stop,maintenance=0.,vmax=vmax,km=km,oxygen=oxygen,
                units={'time':'h','biomass':'gDW/L','glucose':'mmol/L','growth':'1/h'})

def proteome_fluxes(uptake_capacity,protein_budget=.5,constrained=True):
    """Illustrative ATP-yield and protein-cost reduction.

    Variables: glucose processing u, respiration r, fermentation f, growth mu.
    u=r+f, mu=.4r+.2f. Protein fractions: .12r+.03f+.5mu <= .5.
    These coefficients are chosen for teaching, not fitted to a strain.
    """
    S=np.array([[1,-1,-1,0],[0,.4,.2,-1.]])
    protein=np.array([0,.12,.03,.5])
    answer=linprog([0,0,0,-1],A_eq=S,b_eq=[0,0],
                   A_ub=[protein] if constrained else None,
                   b_ub=[protein_budget] if constrained else None,
                   bounds=[(0,uptake_capacity),(0,None),(0,None),(0,None)],method='highs')
    if not answer.success:raise RuntimeError(answer.message)
    u,r,f,mu=answer.x
    return dict(uptake=u,respiration=r,fermentation=f,growth=mu,protein=float(protein@answer.x),
                flux=answer.x,balance=S@answer.x,capacity=uptake_capacity,budget=protein_budget)

def proteome_sweep(capacities=None):
    if capacities is None:capacities=np.linspace(0,6,121)
    rows=[]
    for cap in capacities:
        a=proteome_fluxes(float(cap));b=proteome_fluxes(float(cap),constrained=False)
        rows.append([cap,a['growth'],b['growth'],a['respiration'],a['fermentation'],a['protein']])
    return dict(columns=['uptake_capacity','growth_constrained','growth_without_protein_budget','respiration','fermentation','protein'],values=np.array(rows),overflow_threshold=.5/.32,all_fermentation_threshold=.5/.13)

def mori_upshift(phi_initial=.1,phi_final=.5,growth_final=2.45,duration=3.):
    """Mori et al. 2017 Eqs. 2–8. sigma and chi_R jump to fixed final values."""
    sigma=growth_final/phi_final
    t=np.linspace(0,duration,241)
    growth0=sigma*phi_initial
    growth=growth_final/(1+(growth_final/growth0-1)*np.exp(-growth_final*t))
    mass=1+growth0/growth_final*np.expm1(growth_final*t)
    return dict(t=t,phi=growth/sigma,growth=growth,mass=mass,sigma=sigma,phi_initial=phi_initial,
                phi_final=phi_final,growth_initial_after_shift=growth0,growth_final=growth_final)

def reserve_comparison(reserves=(.02,.07,.15),nu_r=6.,phi_max=.48,duration=6.):
    """Source-based reduction: Mori Eqs. 8,10 plus declared initial phi_R=reserve.

    nu_r and phi_max approximate the paper's parameter scales. This is a new
    calculation from those equations, not digitized experimental observations.
    """
    output=[]
    for reserve in reserves:
        curve=mori_upshift(reserve,phi_max,nu_r*(phi_max-reserve),duration)
        curve.update(reserve=reserve,nu_r=nu_r,phi_max=phi_max)
        output.append(curve)
    return output

def erickson_shift(kind='upshift',growth_initial=None,growth_final=None,duration=12.):
    """Erickson 2017 Eq5 and SI S28–29, S52, S56. Illustrative carbon shifts.

    sigma is protein synthesis per ribosomal protein, not simply elongation.
    The first ~10 min and prolonged growth arrests lie outside this model scope.
    Downshift removes one co-utilized source while the other stays saturating.
    """
    if kind not in ('upshift','downshift'):raise ValueError(kind)
    initial=growth_initial if growth_initial is not None else (.3 if kind=='upshift' else .8)
    final=growth_final if growth_final is not None else (.8 if kind=='upshift' else .4)
    phi0,gamma,lambda_c=.049,11.02,1.17
    mu_i=initial/(1-initial/lambda_c);mu_f=final/(1-final/lambda_c)
    phi_i=phi0+initial/gamma
    sigma_i=initial/phi_i
    sigma0=sigma_i if kind=='upshift' else sigma_i*mu_f/mu_i
    def allocation(sigma):
        ribosome=phi0/(1-sigma/gamma)
        catabolism=max(0.,1-sigma*ribosome/lambda_c)
        return ribosome,catabolism
    def rhs(t,y):
        sigma,phi,logmass=y;chi_r,chi_c=allocation(sigma);growth=sigma*phi
        return [sigma*(mu_f*chi_c-sigma*chi_r),growth*(chi_r-phi),growth]
    t=np.linspace(0,duration,361)
    sol=solve_ivp(rhs,[0,duration],[sigma0,phi_i,0.],t_eval=t,method='DOP853',rtol=1e-10,atol=1e-12)
    if not sol.success:raise RuntimeError(sol.message)
    return dict(kind=kind,t=t,sigma=sol.y[0],phi=sol.y[1],growth=sol.y[0]*sol.y[1],mass=np.exp(sol.y[2]),
                growth_before=initial,growth_final=final,sigma_before=sigma_i,sigma_initial=sigma0,
                phi0=phi0,gamma=gamma,lambda_c=lambda_c,mu_i=mu_i,mu_f=mu_f,
                scope='coarse post-shift kinetics from about 10 min, excluding prolonged arrest')

def thermodynamic_cycle(fuel_capacity=2.,thermodynamic=True):
    """Reject ATP-generating circulation by feasible chemical potentials.

    R1: A+ADP -> B+ATP. R2: B -> A. FUEL: ADP -> ATP, coupled to
    a chemostatted fuel/waste drop of 40 kJ/mol. ATPM: ATP -> ADP.
    ATP synthesis costs 30 kJ/mol. Active reactions require DeltaG<=-1.
    Pi, water and H+ are omitted chemostatted species. Their fixed chemical
    potentials are included in the transformed ATP-synthesis free energy.
    The 2^2 internal active-direction patterns are enumerated exactly.
    """
    S=np.array([[-1,1,0,0],[1,-1,0,0],[1,0,1,-1],[-1,0,-1,1.]])
    patterns=list(product([0,1],repeat=2)) if thermodynamic else [(1,1)]
    audits=[];best=None
    for z in patterns:
        # chemical variable d=mu_B-mu_A. DeltaG1=d+30, DeltaG2=-d.
        A=[];b=[]
        if z[0]:A.append([1.]);b.append(-31.)
        if z[1]:A.append([-1.]);b.append(-1.)
        potential=linprog([0.],A_ub=A or None,b_ub=b or None,bounds=[(-100,100)],method='highs')
        possible=potential.success or not thermodynamic
        audit=dict(active=list(z),potential_feasible=bool(potential.success))
        if possible:
            flux=linprog([0,0,0,-1],A_eq=S,b_eq=np.zeros(4),
                         bounds=[(0,10*z[0]),(0,10*z[1]),(0,fuel_capacity),(0,None)],method='highs')
            audit['ATP']=float(flux.x[3]);audit['flux']=flux.x.tolist()
            if best is None or flux.x[3]>best['ATP']:
                best=dict(ATP=float(flux.x[3]),flux=flux.x,chemical_difference=float(potential.x[0]) if potential.success else None,balance=S@flux.x)
        audits.append(audit)
    return dict(**best,audits=audits,fuel_capacity=fuel_capacity,thermodynamic=thermodynamic)

def enzyme_fluxes(substrate=.1,mode='kinetic',uptake_capacity=10.,abundance=(.6,.4)):
    """A supplied internal substrate feeds two enzymes and a biomass drain.

    Enzyme turnover kcat=(10,5), abundance=(.6,.4), KM=(1,.05).
    Enzyme abundance uses the same amount basis as flux, such as per gDW.
    Absolute units are normalized consistently. FBA gives 10, enzyme bounds 8,
    and saturation at substrate=.1 lowers the drain to 1.8788.
    """
    kcat=np.array([10.,5.]);enzyme=np.array(abundance);km=np.array([1.,.05])
    caps=np.array([np.inf,np.inf])
    if mode in ('enzyme','kinetic'):caps=kcat*enzyme
    if mode=='kinetic':caps=caps*substrate/(km+substrate)
    S=np.array([[1,-1,-1,0],[0,1,1,-1.]])
    answer=linprog([0,0,0,-1],A_eq=S,b_eq=[0,0],
                   bounds=[(0,uptake_capacity),(0,None if np.isinf(caps[0]) else caps[0]),
                           (0,None if np.isinf(caps[1]) else caps[1]),(0,None)],method='highs')
    if not answer.success:raise RuntimeError(answer.message)
    return dict(mode=mode,substrate=substrate,capacity=caps,flux=answer.x,output=float(answer.x[3]),balance=S@answer.x)

def hybrid_pool(duration=12.,step_time=3.,uptake_before=1.,uptake_after=5.):
    """A kinetic/optimization hybrid keeps one internal pool dynamic.

    Saturating enzyme fluxes maximize product flux. Only the downstream
    intermediate is balanced. The substrate pool obeys qdot=uptake-v1-v2.
    """
    def capacity(q):return 6*q/(1+q)+2*q/(.05+q)
    q0=brentq(lambda q:capacity(q)-uptake_before,1e-10,100)
    qfinal=brentq(lambda q:capacity(q)-uptake_after,1e-10,100)
    def rhs(u):
        def fun(t,y):
            # Separate LP with no steady-balance constraint on the changing pool.
            caps=np.array([6.,2.])*max(y[0],0)/(np.array([1.,.05])+max(y[0],0))
            solved=linprog([0,0,-1],A_eq=[[1,1,-1]],b_eq=[0],
                           bounds=[(0,caps[0]),(0,caps[1]),(0,None)],method='highs')
            product=solved.x[2]
            return [u-product,product]
        return fun
    before=solve_ivp(rhs(uptake_before),[0,step_time],[q0,0],dense_output=True,rtol=1e-9,atol=1e-11)
    after=solve_ivp(rhs(uptake_after),[step_time,duration],before.y[:,-1],dense_output=True,rtol=1e-9,atol=1e-11,max_step=.1)
    t=np.linspace(0,duration,241)
    y=np.array([before.sol(ti) if ti<=step_time else after.sol(ti) for ti in t])
    u=np.where(t<step_time,uptake_before,uptake_after)
    return dict(t=t,pool=y[:,0],product=y[:,1],output=capacity(y[:,0]),input=u,
                quasisteady_pool=np.where(t<step_time,q0,qfinal),initial_pool=q0,final_pool=qfinal,step_time=step_time)

def json_ready(value):
    if isinstance(value,np.ndarray):return json_ready(value.tolist())
    if isinstance(value,np.generic):return json_ready(value.item())
    if isinstance(value,float) and not np.isfinite(value):return None
    if isinstance(value,dict):return {k:json_ready(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [json_ready(v) for v in value]
    return value

def write_json(filename,value):
    (HERE/'data'/filename).write_text(json.dumps(json_ready(value),indent=2,allow_nan=False)+'\n')
