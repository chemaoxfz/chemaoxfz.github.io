"""Hexokinase direction test using activity-based standard reaction energy.

Greinert et al. 2021 Table 1: -17.8 +/- 0.5 kJ/mol, 298.15 K, pH 7.
Activities are dimensionless relative to the source's standard state.
This is a subsystem feasibility illustration, not a whole-cell kinetic model.
"""
import numpy as np
from scipy.optimize import linprog

R = .00831446261815324       # kJ mol^-1 K^-1
TEMPERATURE = 298.15
DG_STANDARD = -17.8
DG_UNCERTAINTY = .5
PRODUCT_SUBSTRATE_RATIO = 10.
S = np.array([[1, 0, -1, 0, 0], [0, 1, -1, 0, 0],
              [0, 0, 1, -1, 0], [0, 0, 1, 0, -1.]])


def reaction_energy(atp_adp_ratio, product_substrate_ratio=PRODUCT_SUBSTRATE_RATIO,
                    standard=DG_STANDARD, temperature=TEMPERATURE):
    quotient = product_substrate_ratio/np.asarray(atp_adp_ratio)
    return standard+R*temperature*np.log(quotient)


def optimize(atp_adp_ratio, thermodynamic=True):
    energy = float(reaction_energy(atp_adp_ratio))
    cap = 10.
    hk_bound = (0, cap if not thermodynamic or energy < -1e-8 else 0.)
    solution = linprog([0, 0, 0, -1, 0], A_eq=S, b_eq=np.zeros(4),
                       bounds=[(0, cap), (0, cap), hk_bound, (0, None), (0, None)])
    assert solution.success
    return dict(atp_adp_ratio=float(atp_adp_ratio), energy=energy,
                flux=solution.x.tolist(), output=float(solution.x[3]),
                thermodynamic=thermodynamic)


def report():
    return dict(temperature=TEMPERATURE, pH=7, standard_energy=DG_STANDARD,
                standard_uncertainty=DG_UNCERTAINTY,
                product_substrate_activity_ratio=PRODUCT_SUBSTRATE_RATIO,
                equilibrium_atp_adp_ratio=float(PRODUCT_SUBSTRATE_RATIO*np.exp(
                    DG_STANDARD/(R*TEMPERATURE))),
                energy_change_per_atp_decade=float(-R*TEMPERATURE*np.log(10)),
                cases={name: [optimize(ratio, flag) for flag in [False, True]]
                       for name, ratio in [("ATP_ADP_1", 1.), ("ATP_ADP_0.001", .001)]})
