"""Compute notebook results and figure-data without opening Jupyter."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import lecture13_models as m
import tutorial_figures as figures
import fec_tracking

def main():
    model=m.load_model()
    rows=[]
    for label,glucose,oxygen,succinate in [('Glucose, aerobic',10,20,0),('Glucose, oxygen limited',10,5,0),('Glucose, anaerobic',10,0,0),('Succinate, aerobic',0,20,20),('Succinate, anaerobic',0,0,20)]:
        row=m.solve_condition(model,glucose,oxygen,succinate);row['label']=label;rows.append(row)
    m.write_json('genome-conditions.json',rows)
    biomass=m.biomass_entries(model);biomass.to_csv(m.HERE/'data/biomass-ranked.csv',index=False);figures.biomass(biomass)
    batch=m.batch_dfba();m.write_json('batch-dfba.json',batch);figures.batch(batch)
    protein=m.proteome_sweep();m.write_json('proteome-overflow.json',protein);figures.proteome(protein)
    upshifts=[m.mori_upshift(phi_initial=p) for p in [.03,.1,.2]];m.write_json('mori-upshift.json',upshifts);figures.mori(upshifts)
    reserve=m.reserve_comparison();m.write_json('mori-reserve.json',reserve);figures.reserves(reserve)
    shifts=[m.erickson_shift(kind=k) for k in ['upshift','downshift']];m.write_json('erickson-shifts.json',shifts);figures.erickson(shifts)
    thermo={name:m.thermodynamic_cycle(fuel,flag) for name,fuel,flag in [('no_fuel_fba',0,False),('no_fuel_thermo',0,True),('fuel_fba',2,False),('fuel_thermo',2,True)]}
    m.write_json('thermodynamic-cycle.json',thermo);figures.thermodynamics(thermo)
    enzyme=[m.enzyme_fluxes(mode=mode) for mode in ['fba','enzyme','kinetic']]
    substrates=np.logspace(-3,2,101);outputs=np.array([m.enzyme_fluxes(substrate=q)['output'] for q in substrates])
    m.write_json('enzyme-kinetic.json',dict(cases=enzyme,substrates=substrates,outputs=outputs));figures.enzymes(enzyme,substrates,outputs)
    hybrid=m.hybrid_pool();m.write_json('hybrid-pool.json',hybrid);figures.hybrid(hybrid)
    fec=[fec_tracking.simulate(penalty=p) for p in [3.,5.5]];m.write_json('fec-pools.json',fec);figures.fec(fec)
    plt.close('all')
    print('Generated all non-ecology numerical data and figures.')
    print(pd.DataFrame(rows)[['label','status','growth']].to_string(index=False))

if __name__=='__main__':main()
