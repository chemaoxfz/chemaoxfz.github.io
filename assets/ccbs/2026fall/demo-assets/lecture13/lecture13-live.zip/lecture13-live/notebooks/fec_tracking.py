"""FEC teaching calculation adapted from the verified 2023 notebook reproduction.

Source: lecture13/core-20261013/models.py, relative_discrete and mpc_action.
Here the initial state is exactly balanced and the demand step is exactly t=0.
Optimized activities are not themselves reaction exponents. No explicit
binding-order polytope or activity ceiling is imposed in this demonstration.
"""
import numpy as np
from scipy.linalg import expm,solve

S=np.array([[1.,-1.],[-1.,2.]])
HA=np.array([[0.,1.],[1.,0.]])
KAPPA=1.1

def flux(q,u):return np.array([2*q[1]*u[0],2*KAPPA*q[0]*u[1]])

def relative_discrete(q,u,demand,dt):
    v=flux(q,u)
    A=np.diag(1/q)@S@np.diag(v)@HA
    B=np.diag(1/q)@S@np.diag(v)
    b=(S@v+[0,-demand])/q
    block=np.zeros((5,5));block[:2,:2]=A;block[:2,2:4]=B;block[:2,4]=b
    result=expm(block*dt)
    return result[:2,:2],result[:2,2:4],result[:2,4]

def activity_action(q,u,demand,target,penalty=3.,dt=.03,horizon=20):
    A,B,b=relative_discrete(q,u,demand,dt)
    N=horizon;M=np.zeros((2*N,2*N));offset=np.zeros(2*N)
    for k in range(1,N):
        M[2*k:2*k+2]=A@M[2*(k-1):2*k]
        M[2*k:2*k+2,2*(k-1):2*k]+=B
        offset[2*k:2*k+2]=A@offset[2*(k-1):2*k]+b
    D=np.eye(2*N)
    for k in range(1,N):D[2*k:2*k+2,2*(k-1):2*k]=-np.eye(2)
    weight=np.tile([.3,.08],N)
    error=offset+np.tile(np.log(q/target),N)
    H=M.T@(weight[:,None]*M)+penalty*(D.T@D)
    gradient=M.T@(weight*error)
    z=solve(H,-gradient,assume_a='pos')
    predicted=np.exp((M@z+offset).reshape(N,2)+np.log(q))
    if np.min(predicted[:,0])<.001 or np.min(predicted[:,1])<.6:
        raise ValueError('State floor active. This fast solver assumes inactive state constraints.')
    return u*np.exp(z[:2]),predicted,float(np.max(np.abs(H@z+gradient)))

def simulate(penalty=3.,duration=20.,demand=1.1,dt=.03,horizon=20):
    q=np.array([1/KAPPA,1.]);u=np.array([.5,.5])
    target=np.array([1/KAPPA+.07,.93])
    n=int(round(duration/dt));times=np.arange(n+1)*dt
    states=[q.copy()];activities=[];fluxes=[];residuals=[];minimum=np.array([np.inf,np.inf])
    for t in times[:-1]:
        u,pred,res=activity_action(q,u,demand,target,penalty,dt,horizon)
        activities.append(u.copy());fluxes.append(flux(q,u));residuals.append(res)
        minimum=np.minimum(minimum,pred.min(axis=0))
        # With held activities this structured catalytic plant is exactly affine.
        A=np.array([[-2*KAPPA*u[1],2*u[0],0],[4*KAPPA*u[1],-2*u[0],-demand],[0,0,0.]])
        q=(expm(A*dt)@np.r_[q,1.])[:2]
        if np.any(q<=0):raise ValueError('The simulated pool became nonpositive.')
        states.append(q.copy())
    activities.append(u.copy());fluxes.append(flux(q,u))
    return dict(t=times,q=np.array(states),activity=np.array(activities),flux=np.array(fluxes),
                penalty=penalty,demand=demand,target=target,dt=dt,horizon=horizon,
                predicted_minimum=minimum,stationarity_max=max(residuals),
                units='dimensionless concentration and metabolic time')
