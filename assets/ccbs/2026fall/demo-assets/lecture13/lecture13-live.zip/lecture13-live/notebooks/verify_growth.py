"""Independent absolute-amount ODEs, mass accounting and sensitivities."""
from pathlib import Path
import json
import numpy as np
from scipy.integrate import solve_ivp
import allocation_control as a
import growth_control as g
W=Path(__file__).resolve().parent
checks=[];reports={}
def check(name,ok):
 assert bool(ok),name
 checks.append(name)
for alpha in [.3,1.2]:
 x=a.steady(alpha);q,phi=x[:2];mu=3*q/(.1+q)*phi
 check(f'steady pool balance {alpha}',max(abs(a.rhs(0,x,phi,alpha)[:2]))<1e-14)
 qs=np.geomspace(.001,10,10001)
 mus=1/(1/(3*qs/(.1+qs))+(1+qs)/alpha)
 check(f'analytic steady maximum {alpha}',mu>=max(mus)-1e-12)
for key,d in json.loads((W/'data/allocation-results.json').read_text()).items():
 if 'runs' not in d:continue
 q0,phi0=a.steady(d['alpha_before'])[:2]
 # A, E, R, discounted integral, total imported material.
 state=np.array([q0,1-phi0,phi0,0.,0.]);states=[state.copy()]
 for k,rho in enumerate(d['rho']):
  def fun(t,z):
   precursor,enzyme,ribosome=z[:3];b=enzyme+ribosome;q=precursor/b
   vin=d['alpha_after']*enzyme;vsyn=3*q/(.1+q)*ribosome
   return [vin-vsyn,(1-rho)*vsyn,rho*vsyn,np.exp(-d['discount']*t)*vsyn/b,vin]
  t0=k*d['interval'];t1=(k+1)*d['interval']
  sol=solve_ivp(fun,[t0,t1],state,method='DOP853',rtol=2e-12,atol=2e-14,
                t_eval=np.linspace(t0,t1,d['substeps']+1))
  check(key+f' independent integration {k}',sol.success)
  states.extend(sol.y.T[1:]);state=sol.y[:,-1]
 z=np.array(states);b=z[:,1]+z[:,2]
 comparison=np.column_stack([z[:,0]/b,z[:,2]/b,np.log(b),z[:,3]])
 error=float(np.max(abs(comparison-np.array(d['x']))))
 check(key+' independent absolute-amount trajectory',error<8e-6)
 check(key+' material accounting',max(abs(z[:,0]+b-(q0+1+z[:,4])))<1e-9)
 check(key+' biomass-growth equivalence',abs(np.log(b[-1])-d['summary']['integrated_specific_growth'])<8e-6)
 check(key+' viable state',comparison[:,0].min()>.01999 and comparison[:,1].min()>.01999)
 check(key+' all successful starts',all(r['success'] for r in d['runs']))
 check(key+' multistart objective agreement',np.ptp([r['objective'] for r in d['runs']])<2e-6)
 reports[key]={'independent_max_error':error,'biomass':float(b[-1])}
for key,d in json.loads((W/'data/glycolysis-results.json').read_text()).items():
 init=g.initial();state=np.array([init[0],init[1],1.]);states=[state.copy()];lowest=init[1]
 for k,(ui,ug) in enumerate(d['u']):
  def fun(t,z):
   i,a,b=z;atp=a/b
   invest=atp**-2*ui*b;payoff=2*i;grow=a*ug
   return [invest-payoff,-invest+2*payoff-grow-d['demand']*b,.1*grow]
  sol=solve_ivp(fun,[0,d['interval']],state,method='DOP853',rtol=1e-12,atol=1e-14,dense_output=True)
  check(key+f' independent integration {k}',sol.success)
  extra=sol.sol(np.linspace(0,d['interval'],101));lowest=min(lowest,float(min(extra[1]/extra[2])))
  sample=sol.sol(np.linspace(0,d['interval'],d['substeps']+1)).T
  states.extend(sample[1:]);state=sample[-1]
 z=np.array(states);b=z[:,2];comparison=np.column_stack([z[:,0]/b,z[:,1]/b,np.log(b)])
 error=float(np.max(abs(comparison-np.array(d['x']))))
 check(key+' independent absolute-amount trajectory',error<3e-6)
 check(key+' dense ATP floor',lowest>=d['atp_floor']-3e-6)
 check(key+' objective value',abs(b[-1]-d['summary']['final_biomass'])<3e-6)
 check(key+' all successful starts',all(r['success'] for r in d['runs']))
 reports[key]={'independent_max_error':error,'minimum_ATP_dense':lowest,'biomass':float(b[-1])}
# Finite-difference checks exercise the analytic optimizer gradients independently.
rng=np.random.default_rng(13)
for sample in range(6):
 x=np.array([.08+.3*rng.random(),.1+.4*rng.random(),.2,.1]);rho=.2+.6*rng.random()
 y,aa,bb=a.step(.4,x,rho,.8,.7,.03);eps=1e-6
 jac=np.column_stack([(a.step(.4,x+eps*np.eye(4)[i],rho,.8,.7,.03)[0]-a.step(.4,x-eps*np.eye(4)[i],rho,.8,.7,.03)[0])/(2*eps) for i in range(4)])
 bu=(a.step(.4,x,rho+eps,.8,.7,.03)[0]-a.step(.4,x,rho-eps,.8,.7,.03)[0])/(2*eps)
 check(f'allocation state derivative {sample}',np.max(abs(jac-aa))<1e-8)
 check(f'allocation input derivative {sample}',np.max(abs(bu-bb))<1e-8)
 x=np.array([.5+.2*rng.random(),.8+.1*rng.random(),.1]);u=np.array([.7,.4])
 y,aa,bb=g.step(x,u,1.4,.01)
 jac=np.column_stack([(g.step(x+eps*np.eye(3)[i],u,1.4,.01)[0]-g.step(x-eps*np.eye(3)[i],u,1.4,.01)[0])/(2*eps) for i in range(3)])
 bu=np.column_stack([(g.step(x,u+eps*np.eye(2)[i],1.4,.01)[0]-g.step(x,u-eps*np.eye(2)[i],1.4,.01)[0])/(2*eps) for i in range(2)])
 check(f'ATP state derivative {sample}',np.max(abs(jac-aa))<1e-8)
 check(f'ATP input derivative {sample}',np.max(abs(bu-bb))<1e-8)
(W/'growth-verification.json').write_text(json.dumps({'passed':len(checks),'checks':checks,'reports':reports},indent=2)+'\n')
print(len(checks),'independent growth checks passed.')
print(json.dumps(reports,indent=2))
