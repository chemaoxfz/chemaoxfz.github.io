"""Terminal biomass for an ATP-autocatalytic plant with growth dilution.

This is a new model, not a relabeling of the previous reserve-penalty demo.
Growth yield eps converts ATP allocation into biomass production.
Payoff activity is fixed at its capacity. Controls: investment and growth.
"""
from pathlib import Path
import json
import numpy as np
from scipy.optimize import brentq, minimize

EPSILON = .1
KAPPA = 2.


def initial():
    def balance(a):
        mu = EPSILON*.8*a
        i = a**-2/(KAPPA+mu)
        return -a**-2+2*KAPPA*i-.8*a-.6-mu*a
    a = brentq(balance,.5,1.5)
    i = a**-2/(KAPPA+EPSILON*.8*a)
    return np.array([i,a,0.])


def rhs(x, u, demand):
    i, a = x[:2]
    ui, ug = u
    vi, vp, vg = a**-2*ui, KAPPA*i, a*ug
    mu = EPSILON*vg
    return np.array([vi-vp-mu*i, -vi+2*vp-vg-demand-mu*a, mu])


def linear(x,u,demand):
    i,a=x[:2]
    ui,ug=u
    mu=EPSILON*a*ug
    vi_a=-2*a**-3*ui
    aa=np.array([[-KAPPA-mu, vi_a-EPSILON*ug*i,0],
                 [2*KAPPA,-vi_a-ug-2*EPSILON*a*ug,0],
                 [0,EPSILON*ug,0.]])
    bb=np.array([[a**-2,-EPSILON*a*i],
                 [-a**-2,-a-EPSILON*a*a],
                 [0,EPSILON*a]])
    return aa,bb


def step(x,u,demand,dt):
    eye=np.eye(3)
    k1=rhs(x,u,demand);a1,b1=linear(x,u,demand)
    x2=x+dt*k1/2;k2=rhs(x2,u,demand);a,b=linear(x2,u,demand)
    a2,b2=a@(eye+dt*a1/2),a@(dt*b1/2)+b
    x3=x+dt*k2/2;k3=rhs(x3,u,demand);a,b=linear(x3,u,demand)
    a3,b3=a@(eye+dt*a2/2),a@(dt*b2/2)+b
    x4=x+dt*k3;k4=rhs(x4,u,demand);a,b=linear(x4,u,demand)
    a4,b4=a@(eye+dt*a3),a@(dt*b3)+b
    return (x+dt*(k1+2*k2+2*k3+k4)/6,
            eye+dt*(a1+2*a2+2*a3+a4)/6,
            dt*(b1+2*b2+2*b3+b4)/6)


def evaluate(z,horizon,demand,atp_floor,substeps=5):
    us=z.reshape(-1,2);n=len(z);dt=horizon/len(us)/substeps
    x=initial();d=np.zeros((3,n));xs=[x.copy()];ds=[d.copy()]
    for k,u in enumerate(us):
        for j in range(substeps):
            x,a,b=step(x,u,demand,dt)
            d=a@d;d[:,2*k:2*k+2]+=b
            xs.append(x.copy());ds.append(d.copy())
    xs=np.array(xs);ds=np.array(ds)
    cons=xs[1:,:2]-[.05,atp_floor]
    return -x[2],-d[2],cons.ravel(),ds[1:,:2].reshape(-1,n),xs


def optimize(horizon=4.,demand=1.4,atp_floor=.75,interval=.1,
             growth_floor=0.,substeps=5,warm_seed=None,safety_margin=1e-4):
    # Multiple shooting keeps trial concentrations in the physical domain.
    n=round(horizon/interval);dt=horizon/n/substeps;dim=5*n
    x0=initial();memo={}
    def ev(z):
        key=z.tobytes()
        if key in memo:return memo[key]
        xs=np.vstack([x0,z[:3*n].reshape(n,3)])
        us=z[3*n:].reshape(n,2)
        eq=[];ej=[];ineq=[];ij=[];dense=[x0.copy()]
        for k,u in enumerate(us):
            state=xs[k].copy();a=np.eye(3);b=np.zeros((3,2))
            for j in range(substeps):
                state,aa,bb=step(state,u,demand,dt)
                b=aa@b+bb;a=aa@a
                row=np.zeros((2,dim))
                if k:row[:,3*(k-1):3*k]=a[:2]
                row[:,3*n+2*k:3*n+2*k+2]=b[:2]
                ineq.extend(state[:2]-[.05,atp_floor+safety_margin]);ij.extend(row)
                dense.append(state.copy())
            row=np.zeros((3,dim))
            row[:,3*k:3*k+3]=np.eye(3)
            if k:row[:,3*(k-1):3*k]=-a
            row[:,3*n+2*k:3*n+2*k+2]=-b
            eq.extend(xs[k+1]-state);ej.extend(row)
        memo.clear();memo[key]=(np.array(eq),np.array(ej),np.array(ineq),np.array(ij),np.array(dense))
        return memo[key]
    grad=np.zeros(dim);grad[3*n-1]=-1
    bounds=[(.05,None),(atp_floor+safety_margin,None),(None,None)]*n+[(.0001,1),(growth_floor,1)]*n
    runs=[];answers=[]
    seeds=[]
    for first_growth in [.1,.7]:
        guess=np.tile(x0,(n,1));guess[:,2]=np.arange(1,n+1)*interval*.04
        seeds.append(np.r_[guess.ravel(),np.tile([1.,first_growth],n)])
    if warm_seed is not None:seeds=[np.asarray(warm_seed)]
    for z in seeds:
        ans=minimize(lambda z:-z[3*n-1],z,jac=lambda z:grad,bounds=bounds,
                     constraints=[dict(type='eq',fun=lambda z:ev(z)[0],jac=lambda z:ev(z)[1]),
                                  dict(type='ineq',fun=lambda z:ev(z)[2],jac=lambda z:ev(z)[3])],
                     method='SLSQP',options=dict(ftol=1e-10,maxiter=300))
        val=ev(ans.x)
        runs.append(dict(success=bool(ans.success),message=ans.message,
                         log_biomass=float(-ans.fun),minimum_constraint=float(val[2].min()),
                         defect=float(abs(val[0]).max()),iterations=int(ans.nit)))
        if ans.success and val[2].min()>-1e-7 and abs(val[0]).max()<1e-7:answers.append(ans)
    if not answers:raise RuntimeError(runs)
    ans=min(answers,key=lambda a:a.fun);xs=ev(ans.x)[4];us=ans.x[3*n:].reshape(n,2)
    return dict(horizon=horizon,demand=demand,atp_floor=atp_floor,
                interval=horizon/n,substeps=substeps,growth_floor=growth_floor,
                safety_margin=safety_margin,
                t=np.linspace(0,horizon,len(xs)).tolist(),x=xs.tolist(),
                u=us.tolist(),biomass=np.exp(xs[:,2]).tolist(),runs=runs,
                summary=dict(final_biomass=float(np.exp(xs[-1,2])),
                             log_biomass=float(xs[-1,2]),minimum_atp=float(xs[:,1].min()),
                             arrest_duration=float(sum(us[:,1]<1e-5)*horizon/n),
                             initial_growth_activity=float(us[0,1])))


if __name__=="__main__":
    out={}
    for floor in [.75,.8]:
        result=optimize(atp_floor=floor)
        out[f"floor_{floor:g}"]=result
        print(floor,result["summary"],flush=True)
        Path(__file__).with_name("glycolysis-results.json").write_text(json.dumps(out,indent=2)+"\n")
