"""Execute all tutorial cells in a fresh kernel using this Python interpreter."""
from pathlib import Path
import tempfile,json,sys,time,platform,importlib.metadata
import nbformat
from nbclient import NotebookClient
from jupyter_client import KernelManager
from jupyter_client.kernelspec import KernelSpecManager
from nbconvert import HTMLExporter

HERE=Path(__file__).resolve().parent
path=HERE/'lecture13-live-tutorial.ipynb'
notebook=nbformat.read(path,as_version=4)
start=time.perf_counter()
with tempfile.TemporaryDirectory(prefix='ccbs13-clean-kernel-') as temp:
    kernel=Path(temp)/'ccbs13';kernel.mkdir()
    (kernel/'kernel.json').write_text(json.dumps(dict(argv=[sys.executable,'-m','ipykernel_launcher','-f','{connection_file}'],display_name='CCBS13 verification',language='python')))
    manager=KernelManager(kernel_name='ccbs13',kernel_spec_manager=KernelSpecManager(kernel_dirs=[temp]))
    client=NotebookClient(notebook,km=manager,timeout=600,resources={'metadata':{'path':str(HERE)}})
    try:
        client.execute()
    finally:
        if manager.has_kernel:manager.shutdown_kernel(now=True)
nbformat.write(notebook,path)
code=[c for c in notebook.cells if c.cell_type=='code']
errors=[o for c in code for o in c.outputs if o.output_type=='error']
receipt=dict(python=platform.python_version(),seconds=time.perf_counter()-start,
             code_cells=len(code),executed_cells=sum(c.execution_count is not None for c in code),
             output_errors=len(errors),packages={m:importlib.metadata.version(m) for m in ['cobra','numpy','scipy','pandas','matplotlib','nbformat','nbclient','ipykernel']},
             fresh_kernel=True,models_loaded_offline=True)
(HERE/'execution-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
templates=str(Path(sys.base_prefix)/'share/jupyter/nbconvert/templates')
exporter=HTMLExporter(template_name='lab',extra_template_basedirs=[templates],extra_template_paths=[templates])
body,_=exporter.from_notebook_node(notebook)
(HERE/'lecture13-live-tutorial.html').write_text(body)
print(json.dumps(receipt,indent=2))
