"""Independent scientific checks for the tutorial. Run after generate_results.py."""
from pathlib import Path
import json,hashlib
import numpy as np
from scipy.optimize import linprog
from scipy.integrate import solve_ivp
from scipy.linalg import expm,solve
import lecture13_models as m
import fec_tracking as f

HERE=Path(__file__).resolve().parent
checks=[]
def check(name,passed,evidence=None):
    checks.append(dict(name=name,passed=bool(passed),evidence=evidence))
    if not passed:
        (HERE/'verification.json').write_text(json.dumps(checks,indent=2)+'\n')
        raise AssertionError((name,evidence))
def read(name):return json.loads((HERE/'data'/name).read_text())

model=m.load_model()
old=model.reactions.EX_o2_e.bounds
with model:model.reactions.EX_o2_e.lower_bound=0
check('Native COBRA context restores the changed bound',model.reactions.EX_o2_e.bounds==old)
check('PFK consumes one ATP',model.reactions.PFK.get_coefficient('atp_c')==-1)
biomass=m.biomass_entries(model)
check('Biomass ranking retains every signed coefficient',len(biomass)==len(next(r for r in model.reactions if r.objective_coefficient).metabolites) and np.all(np.diff(biomass.absolute_coefficient)<=0))
for row in read('genome-conditions.json'):
    lp,S,b,c=m.highslp_from_json(glucose=row['glucose'],oxygen=row['oxygen'],succinate=row['succinate'])
    check(row['label']+' independent solver feasibility',lp.success==(row['status']=='optimal'))
    if lp.success:
        check(row['label']+' independent optimum',abs(-lp.fun-row['growth'])<1e-8)
        check(row['label']+' all steady balances',np.max(abs(S@lp.x))<1e-8)
        check(row['label']+' every bound',np.max(np.r_[b[:,0]-lp.x,lp.x-b[:,1]])<1e-8)
        dual=b[:,0]@lp.lower.marginals+b[:,1]@lp.upper.marginals
        check(row['label']+' primal-dual certificate',abs(lp.fun-dual)<1e-8)

# Independent external ODE uses the constant yield established by complete HiGHS LPs.
batch=read('batch-dfba.json')
raw=json.loads((HERE/'models/e_coli_core.json').read_text())
met={v['id']:i for i,v in enumerate(raw['metabolites'])};rxn={v['id']:i for i,v in enumerate(raw['reactions'])}
S=np.zeros((len(met),len(rxn)))
for j,r in enumerate(raw['reactions']):
    for k,v in r['metabolites'].items():S[met[k],j]=v
bounds=np.array([[r['lower_bound'],r['upper_bound']] for r in raw['reactions']]);bounds[rxn['ATPM'],0]=0
bounds[rxn['EX_o2_e'],0]=-20
c=np.array([r.get('objective_coefficient',0) for r in raw['reactions']])
yields=[]
for uptake in np.linspace(.01,9.6,31):
    bounds[rxn['EX_glc__D_e'],0]=-uptake
    ans=linprog(-c,A_eq=S,b_eq=np.zeros(len(met)),bounds=bounds,method='highs')
    check('Batch internal LP feasible at uptake '+str(uptake),ans.success)
    yields.append(-ans.fun/uptake)
check('Batch path has a constant growth yield under these bounds',np.ptp(yields)<1e-9,float(np.ptp(yields)))
Y=float(np.mean(yields));t=np.array(batch['t']);X=np.array(batch['biomass']);G=np.array(batch['glucose'])
check('Batch biomass plus remaining carbon yield is conserved',np.max(abs(X+Y*G-(.05+10*Y)))<2e-8)
reference=solve_ivp(lambda t,y:[Y*10*y[1]/(.5+y[1])*y[0],-10*y[1]/(.5+y[1])*y[0]],
                    [0,batch['stop_time']],[.05,10],method='DOP853',dense_output=True,rtol=1e-11,atol=1e-13)
check('Batch independent ODE agrees with the LP-driven result',np.max(abs(reference.sol(np.minimum(t,batch['stop_time'])).T-np.c_[X,G]))<2e-6)

# Enumerate polygon vertices independently of the four-variable proteome LP.
protein=read('proteome-overflow.json')
for cap,mu,free,r,ferment,budget in protein['values']:
    A=np.array([[-1,0],[0,-1],[1,1],[.32,.13]])
    b=np.array([0,0,cap,.5]);vertices=[]
    for i in range(4):
        for j in range(i):
            if abs(np.linalg.det(A[[i,j]]))<1e-12:continue
            point=np.linalg.solve(A[[i,j]],b[[i,j]])
            if np.all(A@point<=b+1e-9):vertices.append(point)
    expected=max(np.dot([.4,.2],p) for p in vertices)
    check('Protein polygon optimum at cap '+str(cap),abs(mu-expected)<1e-10)
    check('Protein and carbon feasibility at cap '+str(cap),r+ferment<=cap+1e-9 and .32*r+.13*ferment<=.5+1e-9 and abs(mu-.4*r-.2*ferment)<1e-9)
    if cap<protein['overflow_threshold']-1e-9:check('No overflow below the analytic threshold '+str(cap),abs(ferment)<1e-10)
    if cap>protein['overflow_threshold']+1e-9:check('Overflow above the analytic threshold '+str(cap),ferment>0)

for filename in ['mori-upshift.json','mori-reserve.json']:
    for curve in read(filename):
        sigma=curve['sigma'];chi=curve['phi_final'];phi_i=curve['phi_initial'];t=np.array(curve['t'])
        # Independent absolute protein masses: Mdot=sigma*MR, MRdot=sigma*chi*MR.
        sol=solve_ivp(lambda t,y:[sigma*y[1],sigma*chi*y[1]],[0,t[-1]],[1,phi_i],t_eval=t,method='DOP853',rtol=1e-11,atol=1e-13)
        check(filename+' independent protein mass '+str(phi_i),np.max(abs(sol.y[0]/curve['mass']-1))<1e-9)
        check(filename+' independent ribosome fraction '+str(phi_i),np.max(abs(sol.y[1]/sol.y[0]-curve['phi']))<1e-9)
reserve=read('mori-reserve.json')
early=[np.interp(.5,d['t'],d['mass']) for d in reserve];late=[d['mass'][-1] for d in reserve]
check('Larger reserve wins in the short feast',early[2]>early[1]>early[0],early)
check('Smaller reserve wins after a long feast',late[0]>late[1]>late[2],late)

for d in read('erickson-shifts.json'):
    # Independently evolve total protein M, ribosomal protein R, normalized catabolic protein C.
    phi_i=d['phi'][0];mu=d['mu_f'];s0=d['sigma_initial'];gamma=d['gamma'];phi0=d['phi0'];lc=d['lambda_c']
    def proteins(t,y):
        M,R,C=y;J=mu*C;sigma=J/R;chiR=phi0/(1-sigma/gamma);chiC=max(0,1-sigma*chiR/lc)
        return [J,chiR*J,chiC*J]
    sol=solve_ivp(proteins,[0,d['t'][-1]],[1,phi_i,s0*phi_i/mu],t_eval=d['t'],method='RK45',rtol=1e-10,atol=1e-12)
    sigma=mu*sol.y[2]/sol.y[1];growth=mu*sol.y[2]/sol.y[0]
    check(d['kind']+' independent absolute-protein formulation',np.max(abs(growth-d['growth']))<3e-9 and np.max(abs(sigma-d['sigma']))<3e-8)
    check(d['kind']+' asymptotic growth scale',abs(d['growth'][-1]-d['growth_final'])<3e-3)
    check(d['kind']+' positive state and finite allocation',min(d['phi'])>0 and max(d['sigma'])<gamma)
    if d['kind']=='downshift':check('Downshift initial flux ratio from SI S56',abs(d['growth'][0]-d['growth_before']*d['mu_f']/d['mu_i'])<1e-12)

thermo=read('thermodynamic-cycle.json')
check('Ordinary balance admits the closed ATP cycle',thermo['no_fuel_fba']['ATP']==10)
check('Thermodynamics removes ATP without fuel',thermo['no_fuel_thermo']['ATP']==0)
check('Thermodynamics preserves fuel-supported ATP',thermo['fuel_thermo']['ATP']==2)
check('Both internal forward directions have no feasible chemical potentials',not next(a for a in thermo['fuel_thermo']['audits'] if a['active']==[1,1])['potential_feasible'])
for key,d in thermo.items():check(key+' every retained chemical amount balanced',np.max(abs(np.asarray(d['balance'])))<1e-12)

enzyme=read('enzyme-kinetic.json')
check('Enzyme amount independently caps the two pathways at 8',enzyme['cases'][1]['output']==8)
for q,v in zip(enzyme['substrates'],enzyme['outputs']):
    expected=min(10,6*q/(1+q)+2*q/(.05+q))
    check('Independent saturation optimum at substrate '+str(q),abs(v-expected)<1e-10)

hybrid=read('hybrid-pool.json');t=np.array(hybrid['t']);q0=hybrid['initial_pool'];ts=hybrid['step_time']
capacity=lambda q:6*q/(1+q)+2*q/(.05+q)
before=solve_ivp(lambda t,y:[1-capacity(y[0]),capacity(y[0])],[0,ts],[q0,0],dense_output=True,method='DOP853',rtol=1e-12,atol=1e-14)
after=solve_ivp(lambda t,y:[5-capacity(y[0]),capacity(y[0])],[ts,t[-1]],before.y[:,-1],dense_output=True,method='DOP853',rtol=1e-12,atol=1e-14)
reference=np.array([before.sol(z) if z<=ts else after.sol(z) for z in t])
check('Hybrid independent ODE without an LP agrees',np.max(abs(reference-np.c_[hybrid['pool'],hybrid['product']]))<1e-7)
input_integral=np.minimum(t,ts)+5*np.maximum(t-ts,0)
check('Hybrid pool plus cumulative product conserves material',np.max(abs(np.array(hybrid['pool'])+hybrid['product']-q0-input_integral))<1e-8)
check('Hybrid output remains continuous at the input step',abs(hybrid['output'][np.searchsorted(t,ts)]-1)<1e-8)

def riccati_action(q,u,demand,target,penalty,dt,N):
    v=f.flux(q,u);D=np.diag(q)
    physical=np.array([[-2*1.1*u[1],2*u[0]],[4*1.1*u[1],-2*u[0]]])
    A=np.linalg.solve(D,physical@D);B=np.linalg.solve(D,f.S@np.diag(v));b=np.linalg.solve(D,f.S@v+[0,-demand])
    block=np.zeros((5,5));block[:2,:2]=A;block[:2,2:4]=B;block[:2,4]=b;disc=expm(block*dt)
    A,B,b=disc[:2,:2],disc[:2,2:4],disc[:2,4]
    Q=np.diag([.3,.08]);R=penalty*np.eye(2);error=np.log(q/target)
    AA=np.zeros((5,5));AA[:2,:2]=A;AA[:2,4]=b;AA[4,4]=1
    BB=np.zeros((5,2));BB[:2]=B;BB[2:4]=np.eye(2)
    QQ=np.zeros((5,5));QQ[:2,:2]=Q;QQ[:2,4]=Q@error;QQ[4,:2]=error@Q;QQ[4,4]=error@Q@error;QQ[2:4,2:4]=R
    cross=np.zeros((5,2));cross[2:4]=-R;P=np.zeros((5,5))
    for step in range(N-1,-1,-1):
        L=AA.T@P@BB+cross;gain=solve(R+BB.T@P@BB,L.T,assume_a='pos');P=QQ+AA.T@P@AA-L@gain
    return u*np.exp(-(gain@np.array([0,0,0,0,1.])))

for d in read('fec-pools.json'):
    q=np.array(d['q']);u=np.array(d['activity']);target=np.array(d['target']);dt=d['dt'];n=len(q)-1
    for j in [0,1,10,100,n-1]:
        previous=np.array([.5,.5]) if j==0 else u[j-1]
        independent=riccati_action(q[j],previous,d['demand'],target,d['penalty'],dt,d['horizon'])
        check(f'Independent FEC Riccati action R={d["penalty"]}, step={j}',np.max(abs(independent-u[j]))<1e-11)
    replay=q[0].copy();maximum=0.
    for j in range(n):
        sol=solve_ivp(lambda t,y:f.S@f.flux(y,u[j])+[0,-d['demand']],[0,dt],replay,method='DOP853',rtol=1e-12,atol=1e-14)
        replay=sol.y[:,-1];maximum=max(maximum,float(np.max(abs(replay-q[j+1]))))
    check('Independent continuous FEC replay R='+str(d['penalty']),maximum<1e-7,maximum)
    check('FEC predicted and executed concentration floors R='+str(d['penalty']),np.all(np.min(q,axis=0)>[.001,.6]) and np.all(np.array(d['predicted_minimum'])>[.001,.6]))
    check('FEC retains nonzero internal accumulation R='+str(d['penalty']),np.max(abs(np.diff(q,axis=0)/dt))>1e-3)

summary={'checks':len(checks),'all_passed':True,'batch_independent_yield':Y,'coverage':'independent LP, vertex enumeration, absolute-protein ODE, material conservation, Riccati control and continuous replay'}
(HERE/'verification.json').write_text(json.dumps({'summary':summary,'checks':checks},indent=2)+'\n')
print(json.dumps(summary,indent=2))
