"""Structured allocation control with an internal precursor and growing machinery.

Protein-equivalent mass units: B=E+R, A=q B.
v_in=alpha E, v_syn=beta(q) R, beta=3q/(0.1+q).
dA=v_in-v_syn, dE=(1-rho)v_syn, dR=rho v_syn.
No death, protein degradation, active transport regulation or fitted species data.
"""
from pathlib import Path
import json
import numpy as np
from scipy.optimize import minimize
from scipy.integrate import solve_ivp

K = .1
K_R = 3.
Q_FLOOR = .02
PHI_FLOOR = .02


def steady(alpha):
    q = np.sqrt(K*alpha/K_R)
    beta = K_R*q/(K+q)
    phi = alpha/(alpha+beta*(1+q))
    return np.array([q, phi, 0., 0.])


def rhs(t, x, rho, alpha, discount=0.):
    q, phi = x[:2]
    beta = K_R*q/(K+q)
    mu = beta*phi
    return np.array([alpha*(1-phi)-mu*(1+q), mu*(rho-phi),
                     mu, np.exp(-discount*t)*mu])


def linear(t, x, rho, alpha, discount):
    q, phi = x[:2]
    beta = K_R*q/(K+q)
    mu = beta*phi
    mq = K_R*K/(K+q)**2*phi
    a = np.zeros((4, 4))
    a[0, :2] = [-mq*(1+q)-mu, -alpha-beta*(1+q)]
    a[1, :2] = [mq*(rho-phi), beta*(rho-phi)-mu]
    a[2, :2] = [mq, beta]
    a[3, :2] = np.exp(-discount*t)*a[2, :2]
    b = np.array([0., mu, 0., 0.])
    return a, b


def step(t, x, rho, alpha, discount, dt):
    eye = np.eye(4)
    k1 = rhs(t, x, rho, alpha, discount)
    a1, b1 = linear(t, x, rho, alpha, discount)
    x2 = x+dt*k1/2
    k2 = rhs(t+dt/2, x2, rho, alpha, discount)
    a, b = linear(t+dt/2, x2, rho, alpha, discount)
    a2, b2 = a@(eye+dt*a1/2), a@(dt*b1/2)+b
    x3 = x+dt*k2/2
    k3 = rhs(t+dt/2, x3, rho, alpha, discount)
    a, b = linear(t+dt/2, x3, rho, alpha, discount)
    a3, b3 = a@(eye+dt*a2/2), a@(dt*b2/2)+b
    x4 = x+dt*k3
    k4 = rhs(t+dt, x4, rho, alpha, discount)
    a, b = linear(t+dt, x4, rho, alpha, discount)
    a4, b4 = a@(eye+dt*a3), a@(dt*b3)+b
    return (x+dt*(k1+2*k2+2*k3+k4)/6,
            eye+dt*(a1+2*a2+2*a3+a4)/6,
            dt*(b1+2*b2+2*b3+b4)/6)


def evaluate(rhos, x0, alpha, horizon, discount=0., substeps=4):
    n = len(rhos)
    dt = horizon/n/substeps
    x = np.array(x0, float)
    d = np.zeros((4, n))
    xs, ds = [x.copy()], [d.copy()]
    for i, rho in enumerate(rhos):
        for j in range(substeps):
            t = (i*substeps+j)*dt
            x, a, b = step(t, x, rho, alpha, discount, dt)
            d = a@d
            d[:, i] += b
            xs.append(x.copy())
            ds.append(d.copy())
    xs, ds = np.array(xs), np.array(ds)
    constraints = np.column_stack([xs[1:, 0]-Q_FLOOR,
                                    xs[1:, 1]-PHI_FLOOR,
                                    1-PHI_FLOOR-xs[1:, 1]])
    jac = np.stack([ds[1:, 0], ds[1:, 1], -ds[1:, 1]], axis=1)
    return -x[3], -d[3], constraints.ravel(), jac.reshape(-1, n), xs


def optimize(alpha_before=.3, alpha_after=1.2, horizon=8., discount=0.,
             interval=.2, substeps=4, seeds=None):
    n = round(horizon/interval)
    x0 = steady(alpha_before)
    target = steady(alpha_after)[1]
    seeds = seeds or [np.full(n, target), np.linspace(x0[1], target, n),
                      np.full(n, .7 if alpha_after>alpha_before else .05)]
    memo = {}

    def value(z):
        key = z.tobytes()
        if key not in memo:
            memo.clear()
            memo[key] = evaluate(z, x0, alpha_after, horizon, discount, substeps)
        return memo[key]

    runs = []
    answers = []
    for seed in seeds:
        ans = minimize(lambda z: value(z)[0], seed, jac=lambda z: value(z)[1],
                       bounds=[(0, 1)]*n, method="SLSQP",
                       constraints=[dict(type="ineq",fun=lambda z:value(z)[2],
                                         jac=lambda z:value(z)[3])],
                       options=dict(ftol=1e-10, maxiter=300))
        checked = value(ans.x)
        runs.append(dict(success=bool(ans.success), message=str(ans.message),
                         objective=float(-ans.fun), iterations=int(ans.nit),
                         minimum_constraint=float(checked[2].min())))
        if ans.success and checked[2].min() >= -1e-7:
            answers.append(ans)
    if not answers:
        raise RuntimeError(runs)
    best = min(answers, key=lambda a:a.fun)
    ev = value(best.x)
    xs = ev[4]
    times = np.linspace(0, horizon, len(xs))
    mu = K_R*xs[:, 0]/(K+xs[:, 0])*xs[:, 1]
    return dict(alpha_before=alpha_before, alpha_after=alpha_after,
                horizon=horizon, discount=discount, interval=horizon/n,
                substeps=substeps, t=times.tolist(), x=xs.tolist(),
                rho=best.x.tolist(), growth=mu.tolist(),
                biomass=np.exp(xs[:, 2]).tolist(), runs=runs,
                summary=dict(final_biomass=float(np.exp(xs[-1, 2])),
                             integrated_specific_growth=float(xs[-1, 2]),
                             reward=float(xs[-1, 3]), initial_allocation=float(best.x[0]),
                             minimum_precursor=float(xs[:, 0].min()),
                             minimum_ribosomal_fraction=float(xs[:, 1].min()),
                             final_precursor=float(xs[-1, 0]),
                             final_ribosomal_fraction=float(xs[-1, 1])))


def constant_allocation(alpha_before, alpha_after, horizon, rho=None):
    if rho is None:
        rho = steady(alpha_after)[1]
    t = np.linspace(0, horizon, round(horizon/.05)+1)
    sol = solve_ivp(lambda now,x:rhs(now,x,rho,alpha_after),
                    (0,horizon),steady(alpha_before),t_eval=t,rtol=1e-10,atol=1e-12)
    assert sol.success
    return dict(t=t.tolist(),x=sol.y.T.tolist(),rho=float(rho),
                growth=(K_R*sol.y[0]/(K+sol.y[0])*sol.y[1]).tolist(),
                biomass=np.exp(sol.y[2]).tolist())


def main():
    out = {}
    for name,before,after in [("upshift",.3,1.2),("downshift",1.2,.3)]:
        for horizon,discount in [(8.,0.),(8.,2.),(2.,0.)]:
            key = f"{name}_T{horizon:g}_discount{discount:g}"
            out[key] = optimize(before,after,horizon,discount)
            print(key,out[key]["summary"],flush=True)
        out[name+"_constant"] = constant_allocation(before,after,8.)
    Path(__file__).with_name("allocation-results.json").write_text(
        json.dumps(out,indent=2)+"\n")


if __name__ == "__main__":
    main()
