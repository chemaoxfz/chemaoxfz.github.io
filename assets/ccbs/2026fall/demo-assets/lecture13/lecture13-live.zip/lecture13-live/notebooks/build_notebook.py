"""Build the teaching notebook from explicit, reviewable Markdown and code cells."""
from pathlib import Path
import nbformat as nbf

HERE=Path(__file__).resolve().parent
cells=[]
def md(s):cells.append(nbf.v4.new_markdown_cell(s.strip()))
def code(s):cells.append(nbf.v4.new_code_cell(s.strip()))

md(r"""
# Lecture 13 live tutorial: from a reaction entry to dynamic metabolic predictions

We will ask the same practical question repeatedly: **what additional information changes the prediction?** Start by reading a real reconstruction and changing one uptake bound. Then add an external environment, a protein budget, enzyme capacities, thermodynamic consistency, and selected kinetics. Finish by keeping internal metabolite pools dynamic while optimizing regulatory activities.

The opening follows the lecturer's April 2022 FBA notebook. Both archived BiGG models are included, so running this notebook does not download a model. The full iJO1366 reconstruction supplies the first experiments. Small declared models make the later constraints inspectable.

**Live route:** Sections 1–4 establish the API and nutrient experiment. Sections 5–10 are independent optional experiments. Section 11 connects to flux exponent control. Section 12 adds a community and compares culture protocols. Run the setup cell first. Each experiment creates a fresh model or restores modified bounds automatically.

**Model versus measurement:** iJO1366 is a published reconstruction. Its optima are predictions under the selected medium. The reduced pathway coefficients are illustrative. The Mori upshift equations are taken from the paper, with numerical choices identified below. These plots are not experimental observations.
""")
code("""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cobra
from IPython.display import display

HERE = Path.cwd()
assert (HERE / 'models' / 'iJO1366.json').exists(), 'Open this notebook inside its supplied notebooks folder.'
sys.path.insert(0, str(HERE.parent))  # the supplied ecology module is a sibling folder
import lecture13_models as demo
import tutorial_figures as figures
import fec_tracking

print('COBRApy:', cobra.__version__)
print('The model files and all helper code are local.')
""")
md(r"""
## 1. Inspect a reaction, a metabolite, and one stoichiometric coefficient

A reconstruction is a collection of identifiable objects. A reaction column says which metabolites are consumed and produced. It does not yet specify the reaction's regulatory rate law. First open the real iJO1366 model and inspect its size.
""")
code("""
model = demo.load_model('iJO1366')
model
""")
code("""
pfk = model.reactions.get_by_id('PFK')
pfk
""")
md(r"""
**Read the PFK column before optimizing.** Negative coefficients are consumed. Positive coefficients are produced. In the table, the proton is displayed as H⁺. The identifiers retain their compartment suffixes: `atp_c` is cytosolic ATP.
""")
code("""
display(demo.reaction_entries(pfk))
print('ATP coefficient in PFK:', pfk.get_coefficient('atp_c'))
print('Current PFK bounds:', pfk.bounds)
""")
code("""
atp = model.metabolites.get_by_id('atp_c')
display(atp)
print('Number of reactions containing cytosolic ATP:', len(atp.reactions))
print('Some reaction identifiers:', sorted(r.id for r in atp.reactions)[:12])
""")
md(r"""
## 2. Inspect the objective and the complete biomass column

The biomass reaction combines precursor demand with energy and other bookkeeping. Its flux is the specific growth objective. Its coefficients are **not mass fractions**. In particular, large ATP, ADP, H₂O and H⁺ terms describe energy-associated conversions. Ranking by absolute coefficient answers which entries are numerically largest in this reaction's chosen normalization.
""")
code("""
print(model.objective.expression)
biomass_reaction = next(r for r in model.reactions if r.objective_coefficient != 0)
print('Biomass reaction:', biomass_reaction.id)
biomass = demo.biomass_entries(model)
print('Number of nonzero biomass entries:', len(biomass))
display(biomass.head(25))
biomass.to_csv(HERE / 'data' / 'biomass-ranked.csv', index=False)
""")
code("""
figures.biomass(biomass)
plt.show()
""")
md(r"""
**Try a second view.** Remove the large energy-bookkeeping entries to inspect precursor demands. This changes only the table view. It does not change the biomass reaction or the optimization.
""")
code("""
energy_bookkeeping = {'atp_c', 'adp_c', 'h2o_c', 'h_c', 'pi_c'}
display(biomass.query('coefficient < 0').loc[lambda t: ~t.id.isin(energy_bookkeeping)].head(20))
""")
md(r"""
## 3. Change one bound, solve, and restore it

An exchange reaction is negative when uptake is allowed in this model convention. A glucose lower bound of −10 allows uptake up to 10 mmol/(gDW·h). It does not force the cell to use all 10. We will compare oxygen availability while holding the glucose cap fixed. The `with model:` context restores the original state even if an experiment raises an exception.
""")
code("""
oxygen = model.reactions.get_by_id('EX_o2_e')
print('Before the experiment:', oxygen.bounds)
with model:
    demo.set_medium(model, glucose=10, oxygen=20)
    aerobic = model.optimize()
    print('Aerobic maximum growth:', round(aerobic.objective_value, 4), '1/h')
    oxygen.lower_bound = 0.0  # one deliberate change: forbid oxygen uptake
    anaerobic = model.optimize()
    print('Anaerobic maximum growth:', round(anaerobic.objective_value, 4), '1/h')
    display(pd.DataFrame({'aerobic': aerobic.fluxes, 'anaerobic': anaerobic.fluxes})
            .loc[['EX_glc__D_e','EX_o2_e','EX_ac_e','EX_for_e','EX_etoh_e','ATPM']])
print('After the experiment:', oxygen.bounds)
""")
md(r"""
The optimization predicts a lower growth bound without oxygen and a different exchange pattern. A particular optimal flux vector need not be unique. The growth optimum is the primary comparison here. We can explicitly ask for the range of a flux among equally optimal solutions.
""")
code("""
from cobra.flux_analysis import flux_variability_analysis
with model:
    demo.set_medium(model, glucose=10, oxygen=20)
    display(flux_variability_analysis(model, reaction_list=['PFK','EX_ac_e'], fraction_of_optimum=1.0, processes=1))
""")
md(r"""
## 4. Change the carbon source and watch feasibility

Growth on succinate uses a different set of redox and energy routes. Closing glucose uptake while opening succinate uptake is an interpretable change to the environment. The mandatory ATP-maintenance lower bound remains part of the reconstruction. An infeasible case means these combined requirements cannot all be met.
""")
code("""
conditions = []
for name, glucose_cap, oxygen_cap, succinate_cap in [
    ('Glucose, aerobic', 10, 20, 0),
    ('Glucose, oxygen limited', 10, 5, 0),
    ('Glucose, anaerobic', 10, 0, 0),
    ('Succinate, aerobic', 0, 20, 20),
    ('Succinate, anaerobic', 0, 0, 20),
]:
    row = demo.solve_condition(model, glucose_cap, oxygen_cap, succinate_cap)
    row['condition'] = name
    conditions.append(row)
display(pd.DataFrame(conditions).set_index('condition').round(4))
print('Mandatory ATP-maintenance lower bound:', model.reactions.ATPM.lower_bound)
""")
md(r"""
**Change one number live.** Increase the glucose cap from 5 to 10 while keeping oxygen at 5. Then try oxygen at 20. The function restores every bound after each call, so the order of experiments does not affect the result.
""")
code("""
display(pd.DataFrame([demo.solve_condition(model, glucose=g, oxygen=o)
                      for o in [5,20] for g in [5,10]])[['glucose','oxygen','growth']].round(4))
""")
md(r"""
## 5. Dynamic FBA: let the culture consume its environment

In a batch culture, extracellular glucose changes. At every ODE evaluation we solve a new intracellular FBA problem. With biomass concentration $X$ and external glucose $G$,

$$\dot X=\mu^*(G)X,\qquad \dot G=v^*_{\rm EX,glucose}(G)X,$$
$$-v_{\rm EX,glucose}\leq 10\frac{G}{0.5+G}.$$

The small archived E. coli core model makes this calculation fast. Here $X$ is gDW/L, $G$ is mmol/L and time is hours. Oxygen uptake is capped at 20 mmol/(gDW·h). **For this depletion demonstration only, ATP maintenance is set to zero.** This isolates resource-limited growth and permits a no-growth endpoint. Keeping mandatory maintenance would require a separate starvation or feasibility rule.

Internal metabolites still satisfy $Sv=0$ at every solve. The new state memory is in the external resource and population. This is the dynamic-FBA idea of Mahadevan, Edwards and Doyle (2002), illustrated with a new numerical setup.
""")
code("""
batch = demo.batch_dfba(initial_biomass=0.05, initial_glucose=10, km=0.5)
print('Glucose threshold reached at:', round(batch['stop_time'],3), 'h')
print('Final biomass:', round(batch['biomass'][-1],4), 'gDW/L')
figures.batch(batch)
plt.show()
""")
md(r"""
**Experiment:** double the initial biomass. This changes the speed of resource consumption. It does not change the intracellular objective. Compare the depletion time and final biomass.
""")
code("""
denser_batch = demo.batch_dfba(initial_biomass=0.10, initial_glucose=10)
display(pd.DataFrame([
    {'initial biomass':0.05, 'depletion time':batch['stop_time'], 'final biomass':batch['biomass'][-1]},
    {'initial biomass':0.10, 'depletion time':denser_batch['stop_time'], 'final biomass':denser_batch['biomass'][-1]},
]).round(4))
""")
md(r"""
## 6. Proteome allocation: why use a lower-yield pathway?

High carbon yield need not mean low protein cost. A simple reduction makes this tradeoff visible. Let $u$ be substrate processing, $r$ respiration, $f$ fermentation and $\mu$ growth. Use

$$u=r+f,\qquad \mu=0.4r+0.2f,\qquad
0.12r+0.03f+0.5\mu\leq0.5.$$

Maximize $\mu$ subject to the uptake cap and nonnegative fluxes. The last inequality is a protein budget. The flux normalization makes its terms dimensionless protein fractions. The coefficients are illustrative, not an E. coli fit. The mechanism follows allocation models such as Basan et al. (2015) and constrained allocation FBA.

At low uptake, respiration gives more growth from each unit of substrate. Its total protein cost is $0.12+0.5(0.4)=0.32$ per unit of respiratory flux. The all-respiration solution reaches the budget at $u=0.5/0.32=1.5625$. Further growth requires the cheaper fermentative route.
""")
code("""
protein = demo.proteome_sweep()
print('Predicted overflow threshold:', protein['overflow_threshold'])
display(pd.DataFrame([demo.proteome_fluxes(cap) for cap in [1.0,2.0,4.0]])
        [['capacity','respiration','fermentation','growth','protein']].round(4))
figures.proteome(protein)
plt.show()
""")
md(r"""
**Experiment:** change the protein budget while holding uptake capacity at 2. A larger budget can restore the higher-yield route. The result changes because a physiological resource was added to the constraints.
""")
code("""
display(pd.DataFrame([demo.proteome_fluxes(2.0, protein_budget=p) for p in [0.4,0.5,0.8]])
        [['budget','respiration','fermentation','growth']].round(4))
""")
md(r"""
## 7. Proteome reserve: an upshift needs an allocation state

A static protein budget does not determine how fast ribosomes accumulate. Mori et al. (2017), Eqs. (2)–(8), retain ribosomal protein mass $M_R$ and total protein mass $M$. With ribosome fraction $\phi_R=M_R/M$ and allocation fraction $\chi_R$,

$$\dot M=\sigma\phi_R M,\qquad
\dot\phi_R=\sigma\phi_R(\chi_R-\phi_R),\qquad \mu=\sigma\phi_R.$$

For an upshift to rich medium, the paper approximates $\sigma$ and $\chi_R$ as jumping immediately to their final constants. The internal state that relaxes is $\phi_R$, not $\sigma$. Set final $\mu_f=2.45$ h⁻¹ and $\phi_R^f=0.50$, the paper's reported scales. The three initial fractions below are chosen illustrations. The exact solution is

$$\mu(t)=\frac{\mu_f}{1+(\mu_f/\mu_0-1)e^{-\mu_ft}},\qquad
\frac{M(t)}{M(0)}=1+\frac{\mu_0}{\mu_f}(e^{\mu_ft}-1),\qquad
\mu_0=\phi_R^i\frac{\mu_f}{\phi_R^f}.$$

The assumption that metabolic precursors become nonlimiting is central. The paper explicitly leaves biosynthetically limited downshifts to incomplete medium outside this simple model. This is a dynamic allocation model related to the same physiology, not a claim that static FBA alone generates the recovery.
""")
code("""
upshifts = [demo.mori_upshift(phi_initial=p) for p in [0.03,0.10,0.20]]
display(pd.DataFrame([{'initial ribosome fraction':d['phi_initial'],
                      'growth immediately after upshift':d['growth_initial_after_shift'],
                      'final growth':d['growth_final']} for d in upshifts]))
figures.mori(upshifts)
plt.show()
""")
md(r"""
**Reserve has a cost as well as a benefit.** For a new reduction based on the paper's Eqs. (8) and (10), take a near-starved initial ribosome fraction equal to reserve $\phi_0$. Set $\phi_R^{\max}=0.48$, $\nu_R=6$ h⁻¹ and final growth $\mu_f=\nu_R(\phi_R^{\max}-\phi_0)$. These values approximate the paper's parameter scales. The resulting curves are a calculation from the equations, not traced experimental curves. More reserve gives a faster start while reducing the eventual growth rate. The preferred reserve depends on the duration of the feast.
""")
code("""
reserve_curves = demo.reserve_comparison()
figures.reserves(reserve_curves)
plt.show()
display(pd.DataFrame([{'reserve':d['reserve'], 'mass after 0.5h':np.interp(.5,d['t'],d['mass']),
                      'mass after 3h':np.interp(3,d['t'],d['mass']),
                      'mass after 6h':d['mass'][-1]} for d in reserve_curves]).round(3))
""")
md(r"""
### A distinct carbon-shift model retains translational activity

Erickson et al. (2017), Eq. (5), supplies the related one-dimensional equation for translational activity $\sigma$. It differs from Mori's rich-medium approximation:

$$\dot\sigma=\sigma[\mu_f\widehat\chi_{\rm Cat}(\sigma)-\sigma\widehat\chi_{\rm Rb}(\sigma)],$$
$$\widehat\chi_{\rm Rb}=\frac{\phi_{\rm Rb,0}}{1-\sigma/\gamma},\qquad
\widehat\chi_{\rm Cat}=\max\left(0,1-\frac{\sigma\widehat\chi_{\rm Rb}}{\lambda_C}\right),\qquad
\mu_f=\frac{\lambda_f}{1-\lambda_f/\lambda_C}.$$

Here $\mu_f$ parameterizes post-shift carbon uptake capacity. It is not the instantaneous growth rate, which is $\lambda=\sigma\phi_{\rm Rb}$. The ribosome fraction obeys $\dot\phi_{\rm Rb}=\lambda(\widehat\chi_{\rm Rb}-\phi_{\rm Rb})$. Use the paper's fitted scales $\phi_{\rm Rb,0}=0.049$, $\gamma=11.02$ h⁻¹ and $\lambda_C=1.17$ h⁻¹. The particular growth conditions below are illustrative.

For an upshift without pre-expression of the new uptake system, $\sigma$ starts continuously at its old value. For removal of one co-utilized substrate, it initially drops by the ratio $\mu_f/\mu_i$ (SI Eqs. S52 and S56). This creates different recovery curves from the same allocation rule. The shaded first ten minutes identify a regime this coarse description does not resolve. The paper also excludes prolonged growth arrest.
""")
code("""
carbon_shifts = [demo.erickson_shift(kind=k) for k in ['upshift','downshift']]
display(pd.DataFrame([{'shift':d['kind'],'growth before':d['growth_before'],
                      'growth immediately after':d['growth'][0],
                      'growth after 12 h':d['growth'][-1],
                      'final steady growth':d['growth_final']} for d in carbon_shifts]).round(4))
figures.erickson(carbon_shifts)
plt.show()
""")
md(r"""
## 8. Thermodynamic constraints: exclude ATP from a closed cycle

Mass balance alone can permit an energetically impossible circulation. Consider an illustrative network with these composite conversions:

$$A+ADP\rightsquigarrow B+ATP,\qquad B\rightsquigarrow A.$$

Add an ATP drain, and optionally a legitimate fuel-coupled ATP source capped at 2. The two internal reactions can circulate at flux 10 in ordinary FBA. Their net effect is ADP-to-ATP conversion without consuming a net resource.

Phosphate, water and H⁺ are omitted chemostatted species in these transformed reactions. Their fixed chemical potentials are included in the stated ATP-synthesis free energy. The legitimate source additionally consumes supplied fuel and exports waste.

Let $d=\mu_B-\mu_A$ be the chemical-potential difference in kJ/mol and let ATP synthesis cost 30 kJ/mol in the selected state. The reaction free energies are $\Delta G_1=d+30$ and $\Delta G_2=-d$. Both active directions would require $\Delta G\leq-1$. Adding those inequalities demands $30\leq-2$, which is impossible. The legitimate fuel reaction has $\Delta G=-10$ and remains allowed.

The helper enumerates all four on/off patterns and solves the chemical-potential and flux feasibility problems. In a large network this direction/flux coupling is usually formulated with integer variables. The example concerns thermodynamic consistency, not simply preferring a smaller flux norm.
""")
code("""
thermo = {name:demo.thermodynamic_cycle(fuel,flag) for name,fuel,flag in [
    ('no_fuel_fba',0,False), ('no_fuel_thermo',0,True),
    ('fuel_fba',2,False), ('fuel_thermo',2,True),
]}
display(pd.DataFrame([{'condition':name,'maximum ATP drain':d['ATP']} for name,d in thermo.items()]))
display(pd.DataFrame(thermo['fuel_thermo']['audits']))
figures.thermodynamics(thermo)
plt.show()
""")
md(r"""
## 9. Enzyme constraints and kinetic saturation answer different questions

Two parallel enzymes convert the same substrate pool to a product that can enter a biomass drain. Stoichiometry alone gives product flux 10, set by uptake. Enzyme amounts add individual capacities:

$$v_i\leq k_{{\rm cat},i}E_i.$$

Choose normalized turnover constants $(10,5)$ and enzyme amounts $(0.6,0.4)$. The total maximum falls to $6+2=8$. If the substrate pool is only $q=0.1$, saturation adds another restriction:

$$v_i\leq k_{{\rm cat},i}E_i\frac{q}{K_i+q},\qquad (K_1,K_2)=(1,0.05).$$

All values here are illustrative and use consistent normalized units. $E_i$ is an enzyme abundance whose normalization matches the flux basis. For flux per gram dry weight, enzyme abundance is also per gram dry weight. It is not automatically a molar concentration. Enzyme-constrained FBA can also include a shared protein budget, so these categories overlap. A saturation inequality specifies an additional kinetic ceiling. It is not the same claim as knowing every realized rate exactly.
""")
code("""
enzyme_cases = [demo.enzyme_fluxes(mode=mode,substrate=.1) for mode in ['fba','enzyme','kinetic']]
display(pd.DataFrame([{'model':d['mode'],'product flux':d['output'],
                      'enzyme 1 flux':d['flux'][1],'enzyme 2 flux':d['flux'][2]} for d in enzyme_cases]).round(5))
substrates = np.logspace(-3,2,101)
outputs = np.array([demo.enzyme_fluxes(substrate=q)['output'] for q in substrates])
figures.enzymes(enzyme_cases,substrates,outputs)
plt.show()
""")
md(r"""
**Experiment:** double enzyme 1, then raise the substrate. These changes relieve different bottlenecks. The uptake cap still limits the answer.
""")
code("""
display(pd.DataFrame([{'enzyme 1 amount':e1,'substrate':q,
                      'product flux':demo.enzyme_fluxes(substrate=q,abundance=(e1,.4))['output']}
                     for e1 in [.6,1.2] for q in [.1,10.]]).round(4))
""")
md(r"""
## 10. A kinetic hybrid can restore selected internal dynamics

To predict the transient of the substrate pool, release its steady-balance constraint. Keep the downstream product balanced and choose maximal output at the concentration-dependent capacities. The two one-way pathways have independent bounds and no shared resource cost here. Product maximization therefore saturates both bounds, fixing $v_i(q)=k_{{\rm cat},i}E_iq/(K_i+q)$. Then

$$\dot q=u-v_1(q)-v_2(q),\qquad \dot B=v_1(q)+v_2(q).$$

Here $B$ is cumulative product, not a population growth rate. The input steps from 1 to 5 at time 3. Immediately after the step, the new input exceeds output, so the internal pool accumulates. The increased pool progressively activates the enzymes. Its state and history now matter.

This is an explicitly constructed kinetic/optimization hybrid. It shows why a statement about all FBA-related methods needs care: conventional dFBA retains internal steady balance, but hybrids can release selected internal balances and integrate them.
""")
code("""
hybrid = demo.hybrid_pool()
print('Initial internal pool:', round(hybrid['initial_pool'],5))
print('Final steady pool:', round(hybrid['final_pool'],5))
figures.hybrid(hybrid)
plt.show()
""")
md(r"""
## 11. Flux exponent control: retain the catalytic plant and choose activities

The glycolysis example has two evolving internal pools, intermediate $q_I$ and ATP $q_A$:

$$\dot q=S v+\begin{bmatrix}0\\-w\end{bmatrix},\quad
S=\begin{bmatrix}1&-1\\-1&2\end{bmatrix},\quad
v_1=2q_Au_1,\quad v_2=2\kappa q_Iu_2,\quad\kappa=1.1.$$

The catalytic substrate dependences remain. We optimize multiplicative activities $u_1,u_2$ without specifying the Hill feedback laws. The finite-horizon objective penalizes log-concentration tracking error and changes of log activity. The weights, horizon and targets follow the archived 2023 notebook reproduction. Here the demand step is synchronized to time zero and starts from an exact equilibrium.

Demand rises from 1 to 1.1. The chosen target is $(1/\kappa+0.07,0.93)$. That target shift is an explicit task assumption. It is not inferred from stoichiometry. State floors are checked. The fast quadratic solve is used only while they remain inactive. No activity ceiling or explicit binding-order polytope is imposed in this particular reproduction.

The optimized activities are not themselves reaction exponents. Binding structure constrains how activities can depend on concentrations in the full flux exponent control theory. This experiment demonstrates structured dynamic optimization and oscillatory transients, not recovery of a unique molecular mechanism.
""")
code("""
fec_curves = [fec_tracking.simulate(penalty=p) for p in [3.,5.5]]
display(pd.DataFrame([{'activity-change penalty':d['penalty'],
                      'minimum ATP':d['q'][:,1].min(),
                      'minimum predicted ATP':d['predicted_minimum'][1],
                      'quadratic stationarity residual':d['stationarity_max']} for d in fec_curves]))
figures.fec(fec_curves)
plt.show()
""")
md(r"""
**Check what FBA would erase.** A balanced flux vector would require $Sv+(0,-w)^T=0$ at every time. The chosen activities instead produce a nonzero pool derivative during the transient. Read one entry directly.
""")
code("""
run = fec_curves[0]
index = np.searchsorted(run['t'],1.0)
q = run['q'][index]
u = run['activity'][index]
v = fec_tracking.flux(q,u)
display(pd.Series({'time':run['t'][index], 'intermediate':q[0], 'ATP':q[1],
                   'upstream activity':u[0], 'downstream activity':u[1],
                   'intermediate derivative':(fec_tracking.S@v)[0],
                   'ATP derivative':(fec_tracking.S@v)[1]-run['demand']}))
""")
md(r"""
## 12. Add a community environment

The supplied ecology module uses the same pattern as batch dFBA: solve per-species metabolic problems, then integrate biomasses and extracellular resources. Its primary mechanism follows the carbon/oxygen interaction in Khazaei et al. (2020). Their experiment used continuous culture. Serial dilution is a separate, explicitly constructed protocol in this teaching package.

Species B degrades polymer and releases simple carbon. Species A consumes simple carbon and oxygen. That oxygen removal helps the anaerobic species B. Each species maximizes its own instantaneous growth subject to its small metabolic LP. Both species and all three external resources are dynamic. The organisms, coefficients and curves here are a new illustrative reduction, not a reproduction of the paper's whole-genome models.
""")
code("""
from ecology.ecology_dfba import (EcologyParameters, solve_fluxes, simulate_cstr,
                                 simulate_serial_dilution, hysteresis_sweep)
ecology_parameters = EcologyParameters()
flux_example = solve_fluxes([0.5,10.0,0.2], ecology_parameters)  # actual HiGHS LPs
print('Growth rates at these external resources:', flux_example['growth_rate'])
print('Species A LP fluxes:', flux_example['facultative_fluxes'])
print('Species B LP fluxes:', flux_example['anaerobe_fluxes'])
""")
md(r"""
**Run two inoculation histories under the same continuous feed.** The dilution rate is 0.1 h⁻¹. The medium supplies 0.5 mmol/L simple carbon and 10 mmol/L polymer-equivalent carbon, with oxygen transfer toward 0.2 mmol/L. The histories differ in initial biomass and oxygen. Actual LPs are solved during both trajectories. One history approaches a state with negligible B. The other sustains both species by lowering oxygen.
""")
code("""
cstr = {
    'Initially oxygenated': simulate_cstr([.05,1e-5,.5,10,.2],backend='lp'),
    'Initially established anaerobe': simulate_cstr([.1,.15,.5,10,.001],backend='lp'),
}
display(pd.DataFrame([{'history':name,'final A':d['biomass'][-1,0],
                      'final B':d['biomass'][-1,1],'final oxygen':d['resources'][-1,2],
                      'steady residual':np.max(np.abs(d['terminal_derivative']))}
                     for name,d in cstr.items()]).round(7))
figures.ecology_cstr(cstr)
plt.show()
""")
md(r"""
**Now change the experimental protocol.** After each 12-hour batch, keep 30% of the culture and replenish the rest with fresh medium. These are newly chosen teaching parameters. Plot the state immediately after each transfer. This tests convergence to a repeatable cycle, rather than a constant continuous-culture state.

For the longer repeated simulations, `backend='analytic'` evaluates the exact optimizer of these particular tiny LPs. Its equality to HiGHS has been independently checked across resource conditions. The mathematical model is unchanged. Change it to `'lp'` to resolve the LP at every ODE evaluation.
""")
code("""
serial = {
    'Small anaerobic inoculum': simulate_serial_dilution([.01,1e-7,.5,10,.2],cycles=60,backend='analytic'),
    'Established anaerobe': simulate_serial_dilution([.1,.1,.5,10,.001],cycles=60,backend='analytic'),
}
display(pd.DataFrame([{'history':name,'final A after transfer':d['post_dilution'][-1,0],
                      'final B after transfer':d['post_dilution'][-1,1],
                      'last-cycle change':d['convergence_error']} for name,d in serial.items()]))
figures.ecology_serial(serial)
plt.show()
""")
md(r"""
**Sweep a parameter in both directions.** Begin each new oxygen-supply condition from the previous final state. At the start of each condition, a rare-species probe of $10^{-8}$ gDW/L tests whether a missing species can invade. This avoids making numerical extinction an irreversible rule. The probes are not continuous immigration.

Each step runs for 1,000 hours to approach its attractor. The two curves therefore compare slowly changed conditions, not the lag from a fast ramp. Different switching thresholds expose the two branches of the model's hysteresis.
""")
code("""
oxygen_supply = np.linspace(.02,.8,40)
hysteresis = {direction:hysteresis_sweep(oxygen_supply,direction=direction,backend='analytic',
                                       duration_per_step=1000.) for direction in ['up','down']}
print('Largest final derivative:', max(np.max(d['derivative_error']) for d in hysteresis.values()))
figures.ecology_hysteresis(hysteresis)
plt.show()
""")

md(r"""
## Source and model notes

The detailed equations, parameter status, references and verification are in `MODEL-NOTES.md` and `verification.json`. Starting sources include Orth et al. (2011) for iJO1366, Mahadevan et al. (2002) for dynamic FBA, Basan et al. (2015) and Mori et al. (2016) for allocation constraints, Mori et al. (2017) for reserve-dependent rich-medium recovery, Erickson et al. (2017) for carbon-shift kinetics, Henry et al. (2007) for thermodynamic consistency, Sánchez et al. (2017) for enzyme constraints, Covert et al. (2008) for kinetic hybrids, Xiao, Li and Doyle (2023) for flux exponent control, and Khazaei et al. (2020) for community multistability. The offline model JSON files were archived from BiGG on 13 October 2026 and copied unchanged into this package.

COBRApy API documentation: [object inspection and bound resets](https://cobrapy.readthedocs.io/en/latest/getting_started.html), [local JSON loading](https://cobrapy.readthedocs.io/en/latest/io.html), and [dynamic FBA](https://cobrapy.readthedocs.io/en/latest/dfba.html). These links are optional reading. The notebook itself runs offline after its Python dependencies are installed.
""")

notebook=nbf.v4.new_notebook(cells=cells,metadata={'kernelspec':{'name':'python3','display_name':'Python 3','language':'python'},'language_info':{'name':'python','version':'3.13'}})
nbf.write(notebook,HERE/'lecture13-live-tutorial.ipynb')
print('Wrote',len(cells),'cells.')
