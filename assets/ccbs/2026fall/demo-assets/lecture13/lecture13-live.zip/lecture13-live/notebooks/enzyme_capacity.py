"""Two independent enzymes and a competing pair sharing one enzyme."""
import numpy as np
from scipy.optimize import linprog


def parallel(enzymes=(.6, .4), uptake=10., substrate=None):
    turnover = np.array([10., 5.])
    capacity = turnover * np.array(enzymes)
    if substrate is not None:
        capacity *= substrate/(np.array([1., .05])+substrate)
    sol = linprog([-1., -1.], A_ub=[[1., 1.]], b_ub=[uptake],
                  bounds=[(0, c) for c in capacity], method="highs")
    assert sol.success
    return dict(capacities=capacity.tolist(), fluxes=sol.x.tolist(),
                output=float(-sol.fun), unused=(capacity-sol.x).tolist())


def shared(minimum_second=0., enzyme=.6):
    # A single catalyst serves two conversions with turnover 10 and 5.
    sol = linprog([-1., 0.], A_ub=[[.1, .2]], b_ub=[enzyme],
                  bounds=[(0, None), (minimum_second, None)])
    assert sol.success
    return dict(fluxes=sol.x.tolist(), output=float(sol.x[0]),
                enzyme_usage=float(.1*sol.x[0]+.2*sol.x[1]))


def report():
    return dict(parallel_default=parallel(),
                increased_first=parallel((.9, .4)),
                uptake_limited=parallel((.9, .4), uptake=5.),
                saturated=parallel(substrate=.1),
                shared_no_other_task=shared(),
                shared_second_task=shared(1.))
