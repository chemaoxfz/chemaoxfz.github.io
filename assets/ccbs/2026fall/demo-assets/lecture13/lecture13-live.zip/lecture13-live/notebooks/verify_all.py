"""Run the original tutorial checks and the additional independent checks."""
from pathlib import Path
import subprocess,sys
here=Path(__file__).resolve().parent
for name in ['verify_models.py','verify_protocol.py','verify_thermodynamics.py','verify_enzyme.py','verify_growth.py']:
    subprocess.run([sys.executable,str(here/name)],cwd=here,check=True)
