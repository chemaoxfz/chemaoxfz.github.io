"""Receding terminal-biomass planning and a sufficient loss-of-viability certificate.

The ATP floor is a declared model condition, not an empirical cell-death assay.
"""
import numpy as np
from scipy.integrate import solve_ivp
import growth_control as model


def viability_certificate(state,atp_floor=.75,demand=1.4,lookahead=.001):
    """An upper bound on ATP under every admissible action, assuming viability.

    I_dot <= 1/a_floor**2 and A_dot <= 4*I-demand, because all growth
    and investment costs are nonnegative. Integrating both inequalities gives
    the upper bound. If this is below a_floor, maintaining the floor throughout
    that interval is impossible. This sufficient test need not detect every
    nonviable state. It is independent of a numerical optimizer's status.
    """
    intermediate,atp=state[:2]
    upper=atp+(4*intermediate-demand)*lookahead+2*lookahead**2/atp_floor**2
    return dict(lookahead=lookahead,atp_upper_bound=float(upper),atp_floor=atp_floor,
                certified_loss=bool(upper<atp_floor),
                meaning='No admissible continuation can maintain the declared ATP floor throughout this interval.')


def simulate(horizon,duration=4.,interval=.1):
    state=model.initial();times=[0.];states=[state.tolist()];controls=[];failure=None
    for k in range(round(duration/interval)):
        try:
            result=model.optimize(horizon=horizon,initial_state=state,interval=interval,substeps=10)
        except RuntimeError as error:
            failure=dict(time=k*interval,state=state.tolist(),solver=str(error),
                         certificate=viability_certificate(state))
            break
        action=np.array(result['u'][0]);controls.append(action.tolist())
        sol=solve_ivp(lambda t,x:model.rhs(x,action,1.4),
                      (k*interval,(k+1)*interval),state,rtol=1e-10,atol=1e-12,
                      t_eval=np.linspace(k*interval,(k+1)*interval,11))
        if not sol.success:raise RuntimeError(sol.message)
        state=sol.y[:,-1];times+=sol.t[1:].tolist();states+=sol.y.T[1:].tolist()
        if state[1]<.75-1e-6:
            failure=dict(time=(k+1)*interval,state=state.tolist(),reason='ATP floor violated',
                         certificate=viability_certificate(state))
            break
    return dict(horizon=horizon,duration=duration,interval=interval,t=times,x=states,u=controls,failure=failure)
