"""Check invasion analytically, by independent quadrature and by rare seeding."""
from pathlib import Path
import json
import numpy as np
from scipy.integrate import quad, solve_ivp
import culture_protocol as model

HERE = Path(__file__).resolve().parent
checks = []


def check(name, passed, value=None):
    checks.append(dict(name=name, passed=bool(passed), evidence=value))
    assert passed, name


check("matched logarithmic loss", abs(-np.log(model.RETENTION)/model.INTERVAL-model.DILUTION)<1e-14)
for resident in range(2):
    invader = 1-resident
    r = model.resident_cycle(resident)
    z0, z1 = np.log(r["resource_start"]), np.log(r["resource_end"])
    # Independent quadrature of the actual growth along log-resource.
    time = quad(lambda z: (model.K[resident]+np.exp(z))/
                (model.V[resident]*(model.FEED-np.exp(z))), z1, z0, epsabs=1e-10)[0]
    integ = quad(lambda z: model.growth(np.exp(z))[invader]*
                 (model.K[resident]+np.exp(z))/
                 (model.V[resident]*(model.FEED-np.exp(z))), z1, z0, epsabs=1e-10)[0]
    check(f"resident {resident} duration", abs(time-model.INTERVAL)<1e-8, time)
    check(f"invader {invader} quadrature", abs(integ+np.log(model.RETENTION)-r["log_multiplier"])<1e-8)
    # Independent coordinates: resource logarithm, resident amount, invader amount.
    seed = 1e-11
    initial = [z0, model.FEED-r["resource_start"]-seed, seed]
    def independent_rhs(t, state):
        resource = np.exp(state[0])
        rates = model.V/(model.K+resource)
        return [-(rates[resident]*state[1]+rates[invader]*state[2]),
                resource*rates[resident]*state[1], resource*rates[invader]*state[2]]
    sol = solve_ivp(independent_rhs, [0, model.INTERVAL], initial,
                    method="DOP853", rtol=1e-12, atol=1e-18)
    mult = model.RETENTION*sol.y[2, -1]/seed
    check(f"invader {invader} rare seeding", abs(mult-r["multiplier"])<1e-7, mult)
inv = model.continuous_invasion()
check("continuous A resists B", inv["B_into_A"]<0)
check("continuous A invades B", inv["A_into_B"]>0)
check("serial B invades A", model.resident_cycle(0)["multiplier"]>1)
check("serial B resists A", model.resident_cycle(1)["multiplier"]<1)
data = np.load(HERE/"data/protocol-trajectories.npz")
check("continuous selects A", data["continuous_fraction_A"][-1]>.9999)
check("serial selects B", data["serial_fraction_A"][-1]<1e-8)
for protocol in ["continuous", "serial", "batch"]:
    repeat = model.simulate(protocol, rtol=2e-12, atol=2e-14)
    error = np.max(np.abs(repeat["fraction_A"]-data[protocol+"_fraction_A"]))
    check(protocol+" tolerance refinement", error<2e-7, float(error))
    check(protocol+" nonnegative states", np.min(data[protocol+"_biomass"])>=0
          and np.min(data[protocol+"_resource"])>0)
(HERE/"protocol-verification.json").write_text(json.dumps(checks, indent=2)+"\n")
print(f"{len(checks)} independent checks passed.")
