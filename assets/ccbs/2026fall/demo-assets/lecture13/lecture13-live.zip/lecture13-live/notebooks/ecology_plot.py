"""Readable community comparison shared by the core and live notebook."""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D


def community_figure(histories, sweeps, oxygen_supply=.2, time_window=100., settling_hours=1000.):
    """Two fixed-environment histories and a separate oxygen continuation experiment.

    histories has keys 'low' and 'high'. sweeps has keys 'up' and 'down'.
    Both accept the public simulation return dictionaries or archived NPZ arrays.
    """
    with plt.rc_context({'font.family':'sans-serif', 'font.size':15,
                         'axes.labelsize':15, 'axes.titlesize':17,
                         'xtick.labelsize':13, 'ytick.labelsize':13,
                         'axes.spines.top':False, 'axes.spines.right':False}):
        fig=plt.figure(figsize=(13.2,9.7))
        grid=fig.add_gridspec(2,2,left=.085,right=.97,bottom=.28,top=.80,
                             width_ratios=[1,1.05],wspace=.40,hspace=.66)
        a=fig.add_subplot(grid[0,0]); b=fig.add_subplot(grid[1,0]); c=fig.add_subplot(grid[:,1])
        species_colors=['#EE8168','#1F9A8E']
        for tag,style in [('low',(0,(6,3))),('high','-')]:
            d=histories[tag]
            for j,color in enumerate(species_colors):
                a.plot(d['t'],d['biomass'][:,j],ls=style,color=color,lw=3.4,
                       gid=f'community-{tag}-species-{j}')
            b.plot(d['t'],d['resources'][:,2],ls=style,color='#555555',lw=3.4,
                   gid=f'community-{tag}-oxygen')
        a.set(xlim=(0,time_window),xlabel='Time (h)',ylabel='Biomass (gDW/L)',
              title='A  Biomass at fixed supply')
        b.set(xlim=(0,time_window),xlabel='Time (h)',ylabel='Dissolved oxygen (mmol/L)',
              title='B  Oxygen at the same supply')
        a.legend(handles=[Line2D([0],[0],color=species_colors[0],lw=3.4,label='Facultative species A'),
                          Line2D([0],[0],color=species_colors[1],lw=3.4,label='Anaerobic species B')],
                 fontsize=11.8,frameon=False,loc='upper right',handlelength=1.5)

        sweep_colors={'up':'#5A73CE','down':'#77488C'}
        for direction,marker,label in [('up','>','Increasing supply'),('down','<','Decreasing supply')]:
            d=sweeps[direction]
            c.plot(d['feed'],d['biomass'][:,1],color=sweep_colors[direction],lw=3.2,
                   marker=marker,ms=6.2,markevery=(1,4),label=label,gid=f'community-sweep-{direction}')
        c.axvline(oxygen_supply,color='#777777',lw=1.7,ls=':',zorder=0)
        # These points use the independently integrated fixed-condition histories.
        for tag,fill in [('high','#242424'),('low','white')]:
            final=float(histories[tag]['biomass'][-1,1])
            c.scatter([oxygen_supply],[final],s=115,facecolor=fill,edgecolor='#242424',lw=2.2,
                      zorder=6,gid=f'community-selected-{tag}')
        c.set(xlabel='Oxygen supply (mmol/L)',ylabel='Steady anaerobe biomass (gDW/L)',
              title='C  Sweep oxygen supply',ylim=(-.025,.24))
        c.set_xticks([0,.2,.4,.6,.8])
        c.legend(fontsize=13,frameon=False,loc='upper right',handlelength=2)
        yrange=np.diff(c.get_ylim())[0]
        xspan=max(np.ptp(sweeps['up']['feed']),1e-9)
        xtext=oxygen_supply+.06*xspan
        c.text(xtext,float(histories['high']['biomass'][-1,1])-.075*yrange,
               'E (solid in A–B)',fontsize=12.5,weight='bold',color='#242424')
        c.text(xtext,float(histories['low']['biomass'][-1,1])+.055*yrange,
               'R (dashed in A–B)',fontsize=12.5,weight='bold',color='#242424')
        c.text(oxygen_supply-.025*xspan,.08,'Supply used in A–B',rotation=90,
               ha='right',va='center',fontsize=12.5,color='#777777')
        for ax in [a,b,c]:
            ax.grid(False)
            ax.yaxis.labelpad=11
        fig.suptitle('The same supply supports two histories. A sweep reveals hysteresis.',
                     x=.085,ha='left',y=.975,fontsize=19,weight='bold')
        fig.text(.085,.924,f'A–B: oxygen supply fixed at {oxygen_supply:g} mmol/L',fontsize=16,weight='bold')
        fig.legend(handles=[Line2D([0],[0],color='#555555',lw=3.4,ls=(0,(6,3)),label='R: rare anaerobe, oxygenated'),
                            Line2D([0],[0],color='#555555',lw=3.4,label='E: established anaerobe, low oxygen')],
                   loc='upper left',bbox_to_anchor=(.075,.907),frameon=False,fontsize=13,
                   handlelength=2.6,labelspacing=.65)
        fig.text(.60,.925,'C: color and arrowheads show sweep direction',fontsize=13)
        fig.text(.60,.891,f'Each supply held for {settling_hours:g} h.',fontsize=13)
        fig.text(.60,.858,'Circles mark the terminal states of A–B.',fontsize=13)
        fig.text(.085,.188,'Initial state',fontsize=14,weight='bold')
        for x,label in [(.43,'Species A (gDW/L)'),(.65,'Species B (gDW/L)'),(.86,'Oxygen (mmol/L)')]:
            fig.text(x,.188,label,fontsize=13,ha='center',weight='bold')
        for tag,y,label in [('low',.143,'R: rare anaerobe, oxygenated'),('high',.099,'E: established anaerobe, low oxygen')]:
            initial=histories[tag]['state'][0]
            fig.text(.085,y,label,fontsize=13)
            for x,value in [(.43,initial[0]),(.65,initial[1]),(.86,initial[4])]:
                fig.text(x,y,f'{value:g}',fontsize=14,ha='center')
        fig.text(.085,.039,'A–B: line style identifies the initial state. C: colored arrows identify the sweep direction.',fontsize=13)
        return fig


def serial_figure(histories, batch_duration=12., retained_fraction=.3):
    """Optional serial-dilution comparison with one history key in every panel."""
    with plt.rc_context({'font.family':'sans-serif','font.size':15,
                         'axes.labelsize':15,'axes.titlesize':17,
                         'xtick.labelsize':13,'ytick.labelsize':13,
                         'axes.spines.top':False,'axes.spines.right':False}):
        fig=plt.figure(figsize=(13.2,9.7))
        grid=fig.add_gridspec(2,2,left=.085,right=.97,bottom=.28,top=.80,
                             width_ratios=[1,1.05],wspace=.40,hspace=.66)
        a=fig.add_subplot(grid[0,0]); b=fig.add_subplot(grid[1,0]); c=fig.add_subplot(grid[:,1])
        colors=['#EE8168','#1F9A8E']
        for tag,style in [('low',(0,(6,3))),('high','-')]:
            d=histories[tag]
            cycles=len(d['post_dilution'])
            start=(cycles-3)*batch_duration
            visible=d['t']>=start
            for j,color in enumerate(colors):
                a.plot(np.arange(1,cycles+1),d['post_dilution'][:,j],ls=style,color=color,lw=3.4,
                       gid=f'serial-{tag}-post-transfer-{j}')
                b.plot(d['t'][visible]-start,d['biomass'][visible,j],ls=style,color=color,lw=3.4,
                       gid=f'serial-{tag}-last-cycles-{j}')
            c.plot(d['t'][visible]-start,d['resources'][visible,2],ls=style,color='#555555',lw=3.4,
                   gid=f'serial-{tag}-oxygen')
        a.set(xlabel='Transfer cycle',ylabel='Biomass after transfer (gDW/L)',title='A  Convergence across transfers')
        b.set(xlabel='Time in final three cycles (h)',ylabel='Biomass (gDW/L)',title='B  Growth between transfers')
        c.set(xlabel='Time in final three cycles (h)',ylabel='Dissolved oxygen (mmol/L)',title='C  Oxygen within each cycle')
        for ax in [b,c]:
            ax.set_xlim(0,3*batch_duration)
            ax.set_xticks(np.arange(0,3*batch_duration+.001,batch_duration))
            for t in [batch_duration,2*batch_duration]:
                ax.axvline(t,color='#777777',ls=':',lw=1.2,zorder=0)
        for ax in [a,b,c]:ax.grid(False);ax.yaxis.labelpad=11
        a.legend(handles=[Line2D([0],[0],color=colors[0],lw=3.4,label='Facultative species A'),
                          Line2D([0],[0],color=colors[1],lw=3.4,label='Anaerobic species B')],
                 fontsize=11.8,frameon=False,loc='upper right',handlelength=1.5)
        fig.suptitle('Repeated dilution can preserve two different recurring communities',
                     x=.085,ha='left',y=.975,fontsize=19,weight='bold')
        fig.text(.085,.924,'One initial-state key applies to A, B and C',fontsize=16,weight='bold')
        fig.legend(handles=[Line2D([0],[0],color='#555555',lw=3.4,ls=(0,(6,3)),label='R: rare anaerobe, oxygenated'),
                            Line2D([0],[0],color='#555555',lw=3.4,label='E: established anaerobe, low oxygen')],
                   loc='upper left',bbox_to_anchor=(.075,.907),frameon=False,fontsize=13,
                   handlelength=2.6,labelspacing=.65)
        fig.text(.60,.925,f'Grow for {batch_duration:g} h. Retain {100*retained_fraction:g}%. Replenish medium.',fontsize=13)
        fig.text(.60,.891,'Dotted vertical lines mark transfers.',fontsize=13)
        fig.text(.60,.858,'Biomass colors identify the two species.',fontsize=13)
        fig.text(.085,.188,'Initial state',fontsize=14,weight='bold')
        for x,label in [(.43,'Species A (gDW/L)'),(.65,'Species B (gDW/L)'),(.86,'Oxygen (mmol/L)')]:
            fig.text(x,.188,label,fontsize=13,ha='center',weight='bold')
        for tag,y,label in [('low',.143,'R: rare anaerobe, oxygenated'),('high',.099,'E: established anaerobe, low oxygen')]:
            initial=histories[tag]['state'][0]
            fig.text(.085,y,label,fontsize=13)
            for x,value in [(.43,initial[0]),(.65,initial[1]),(.86,initial[4])]:
                fig.text(x,y,f'{value:g}',fontsize=14,ha='center')
        fig.text(.085,.039,'Continuous-culture equilibria become transfer-to-transfer cycles under this new protocol.',fontsize=13)
        return fig
