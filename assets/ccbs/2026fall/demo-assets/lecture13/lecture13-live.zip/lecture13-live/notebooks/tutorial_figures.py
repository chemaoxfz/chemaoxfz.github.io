"""Scientific notebook figures. Every plotted series comes from the saved computations."""
from pathlib import Path
import re
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

HERE=Path(__file__).resolve().parent
COLORS=['#198f83','#7965c1','#df8256','#438bc2','#bb5268']
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,
                     'axes.prop_cycle':plt.cycler(color=COLORS),'svg.fonttype':'none',
                     'figure.dpi':130,'svg.hashsalt':'lecture13-notebook','axes.labelcolor':'#242424','text.color':'#242424',
                     'xtick.color':'#555555','ytick.color':'#555555','axes.edgecolor':'#777777'})

def save(fig,name):
    fig.savefig(HERE/'figures'/f'{name}.png',dpi=160,bbox_inches='tight')
    svg=HERE/'figures'/f'{name}.svg'
    fig.savefig(svg,bbox_inches='tight',transparent=True)
    # The embedded course SVG inherits its host theme. Notebook PNGs stay conventional.
    text=svg.read_text()
    color_map={'#242424':'var(--fg,#242424)','#000000':'var(--fg,#242424)','#555555':'var(--muted,#555555)',
               '#777777':'var(--muted,#777777)','#cccccc':'var(--rule,#cccccc)','#ffffff':'var(--bg2,#ffffff)',
               '#198f83':'var(--teal,#198f83)','#7965c1':'var(--peri,#7965c1)','#df8256':'var(--coral,#df8256)',
               '#438bc2':'var(--blue,#438bc2)','#bb5268':'var(--rose,#bb5268)'}
    for old,new in color_map.items():text=text.replace(old,new)
    identifiers=re.findall(r'id="([^"]+)"',text)
    for old in identifiers:
        new='l13nb-'+name+'-'+old
        text=text.replace('id="'+old+'"','id="'+new+'"').replace('url(#'+old+')','url(#'+new+')').replace('href="#'+old+'"','href="#'+new+'"')
    svg.write_text(text)
    return fig

def biomass(table):
    rows=table.head(22).iloc[::-1]
    fig,ax=plt.subplots(figsize=(9,6.8),layout='constrained')
    ax.barh(np.arange(len(rows)),rows.coefficient,color=[COLORS[0] if v<0 else COLORS[2] for v in rows.coefficient])
    ax.set_yticks(np.arange(len(rows)),[str(n)[:45]+' ['+i+']' for i,n in zip(rows.id,rows.name)],fontsize=9)
    ax.axvline(0,color='#777777',lw=.8)
    ax.set_xlabel('Signed coefficient per biomass-reaction unit')
    ax.set_title('Largest absolute biomass coefficients include energy bookkeeping',loc='left',fontsize=13)
    return save(fig,'biomass-ranked')

def batch(result):
    fig,axs=plt.subplots(1,2,figsize=(10,3.6),layout='constrained')
    axs[0].plot(result['t'],result['glucose']);axs[0].set(ylabel='External glucose (mmol/L)',xlabel='Time (h)')
    axs[1].plot(result['t'],result['biomass']);axs[1].set(ylabel='Biomass (gDW/L)',xlabel='Time (h)')
    for ax in axs:ax.axvline(result['stop_time'],ls=':',color='#777777');ax.set_xlim(0,6)
    fig.suptitle('External resource depletion changes each successive FBA optimum',fontsize=13)
    return save(fig,'batch-dfba')

def proteome(result):
    a=result['values'];fig,axs=plt.subplots(1,2,figsize=(10,3.8),layout='constrained')
    axs[0].plot(a[:,0],a[:,2],ls='--',color='#777777',label='Without protein budget')
    axs[0].plot(a[:,0],a[:,1],label='With protein budget')
    axs[0].set(ylabel='Growth rate (1/h)',xlabel='Uptake capacity (normalized units)');axs[0].legend(fontsize=9)
    axs[1].plot(a[:,0],a[:,3],label='Respiration');axs[1].plot(a[:,0],a[:,4],label='Fermentation')
    axs[1].set(ylabel='Pathway flux (normalized units)',xlabel='Uptake capacity (normalized units)');axs[1].legend(fontsize=9)
    for ax in axs:ax.axvline(result['overflow_threshold'],ls=':',color=COLORS[2])
    fig.suptitle('A protein budget can favor a lower-yield pathway',fontsize=13)
    return save(fig,'proteome-overflow')

def mori(curves):
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    for d in curves:
        label=f"Initial ribosome fraction {d['phi_initial']:.2f}"
        axs[0].plot(d['t'],d['growth'],label=label);axs[1].plot(d['t'],d['mass'],label=label)
    axs[0].set(ylabel='Growth rate (1/h)',xlabel='Time after rich-medium upshift (h)');axs[0].legend(fontsize=8)
    axs[1].set(ylabel='Protein mass / initial protein mass',xlabel='Time after rich-medium upshift (h)',yscale='log')
    axs[1].set_ylim(1,1000);axs[1].set_yticks([1,10,100,1000]);axs[1].yaxis.set_major_formatter(FuncFormatter(lambda value,pos:f'{value:g}'))
    axs[1].set_ylabel('Protein mass / initial protein mass',labelpad=14)
    fig.suptitle('The initial ribosome inventory sets the immediate upshift response',fontsize=13)
    return save(fig,'mori-upshift')

def reserves(curves):
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained');reference=curves[1]['mass']
    for d in curves:
        label=f"Reserve fraction {d['reserve']:.2f}"
        axs[0].plot(d['t'],d['growth'],label=label)
        axs[1].plot(d['t'],d['mass']/reference,label=label)
    axs[0].set(ylabel='Growth rate (1/h)',xlabel='Time after upshift (h)');axs[0].legend(fontsize=9)
    axs[1].set(ylabel='Mass relative to the 0.07-reserve case',xlabel='Feast duration (h)');axs[1].axhline(1,color='#777777',ls=':')
    fig.suptitle('Reserve helps early recovery and consumes proteome in the final state',fontsize=13)
    return save(fig,'mori-reserve')

def thermodynamics(cases):
    fig,ax=plt.subplots(figsize=(7,3.7),layout='constrained')
    x=np.arange(2);width=.32
    ax.bar(x-width/2,[cases['no_fuel_fba']['ATP'],cases['fuel_fba']['ATP']],width,label='Stoichiometry and bounds')
    ax.bar(x+width/2,[cases['no_fuel_thermo']['ATP'],cases['fuel_thermo']['ATP']],width,label='Also chemical potentials')
    ax.set_xticks(x,['No supplied fuel','Fuel-coupled ATP capacity = 2']);ax.set_ylabel('Maximum ATP drain (normalized flux)');ax.legend(fontsize=9)
    ax.set_title('Chemical-potential consistency excludes ATP from a closed cycle',loc='left',fontsize=12)
    return save(fig,'thermodynamic-cycle')

def erickson(curves):
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    for ax,d,color in zip(axs,curves,COLORS):
        ax.plot([-.5,0],[d['growth_before']]*2,color=color,ls='--')
        ax.plot([0,0],[d['growth_before'],d['growth'][0]],color=color,ls=':')
        visible=d['t']<=6
        ax.plot(d['t'][visible],d['growth'][visible],color=color)
        ax.axhline(d['growth_final'],color='#777777',ls=':')
        ax.axvspan(0,1/6,color='#777777',alpha=.12)
        ax.set(xlabel='Time after carbon shift (h)',ylabel='Growth rate (1/h)',xlim=(-.5,6),ylim=(0,1))
        ax.tick_params(axis='y',pad=9)
        ax.set_title(d['kind'].capitalize()+f": {d['growth_before']:.1f} to {d['growth_final']:.1f} /h",fontsize=11)
    fig.suptitle('Carbon shifts couple translational activity and proteome allocation',fontsize=13)
    return save(fig,'erickson-shifts')

def enzymes(cases,substrates,outputs):
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    axs[0].bar(['FBA','Enzyme\ncapacity','Capacity +\nsaturation'],[d['output'] for d in cases],color=COLORS[:3]);axs[0].set_ylabel('Maximum product flux (normalized units)')
    axs[1].semilogx(substrates,outputs);axs[1].axhline(8,color='#777777',ls='--',label='Enzyme-capacity ceiling')
    axs[1].set_xlim(.001,100);axs[1].set_xticks([.001,.01,.1,1,10,100]);axs[1].xaxis.set_major_formatter(FuncFormatter(lambda value,pos:f'{value:g}'))
    axs[1].set(ylabel='Maximum product flux',xlabel='Substrate pool (normalized concentration)');axs[1].legend(fontsize=9)
    fig.suptitle('Enzyme amount and substrate saturation impose different restrictions',fontsize=13)
    return save(fig,'enzyme-kinetic')

def hybrid(result):
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    axs[0].plot(result['t'],result['pool'],label='Dynamic internal pool');axs[0].plot(result['t'],result['quasisteady_pool'],ls='--',label='Instantaneous steady solution')
    axs[0].set(ylabel='Internal substrate (normalized concentration)',xlabel='Time (normalized)');axs[0].legend(fontsize=9)
    axs[1].plot(result['t'],result['input'],ls='--',label='Input flux');axs[1].plot(result['t'],result['output'],label='Output flux')
    axs[1].set(ylabel='Flux (normalized units)',xlabel='Time (normalized)');axs[1].legend(fontsize=9)
    fig.suptitle('Releasing one internal balance creates a measurable transient',fontsize=13)
    return save(fig,'hybrid-pool')

def fec(curves):
    fig,axs=plt.subplots(1,2,figsize=(10,4.1),layout='constrained')
    for d in curves:
        axs[0].plot(d['t'],d['q'][:,1],label=f"Activity-change penalty {d['penalty']:g}")
        axs[1].plot(d['t'],d['q'][:,0],label=f"Activity-change penalty {d['penalty']:g}")
    axs[0].axhline(.93,ls=':',color='#777777');axs[1].axhline(1/1.1+.07,ls=':',color='#777777')
    axs[0].set(ylabel='ATP pool (normalized)',xlabel='Metabolic time (normalized)')
    axs[1].set(ylabel='Intermediate pool (normalized)',xlabel='Metabolic time (normalized)')
    fig.suptitle('Structured catalytic dynamics remain while activities are optimized',fontsize=13)
    fig.legend(*axs[0].get_legend_handles_labels(),loc='outside lower center',ncol=2,fontsize=9)
    return save(fig,'fec-pools')

def ecology_cstr(curves):
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    for ax,(name,d) in zip(axs,curves.items()):
        visible=d['t']<=150
        ax.plot(d['t'][visible],d['biomass'][visible,0],label='Facultative species A')
        ax.plot(d['t'][visible],d['biomass'][visible,1],label='Anaerobic species B')
        ax.set(title=name,xlabel='Time (h)',ylabel='Biomass (gDW/L)',xlim=(0,150));ax.legend(fontsize=9)
    fig.suptitle('The same continuous feed can support two community states',fontsize=13)
    return save(fig,'ecology-cstr')

def ecology_serial(curves):
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    for ax,(name,d) in zip(axs,curves.items()):
        cycle=np.arange(1,len(d['post_dilution'])+1)
        ax.plot(cycle,d['post_dilution'][:,0],label='Species A after transfer')
        ax.plot(cycle,d['post_dilution'][:,1],label='Species B after transfer')
        ax.set(title=name,xlabel='Dilution cycle',ylabel='Post-transfer biomass (gDW/L)');ax.legend(fontsize=8)
    fig.suptitle('A separate serial-dilution protocol retains two repeatable cycles',fontsize=13)
    return save(fig,'ecology-serial')

def ecology_hysteresis(curves):
    fig,ax=plt.subplots(figsize=(7,3.8),layout='constrained')
    for name,d in curves.items():ax.plot(d['feed'],d['composition'],'o-',ms=3,label=name)
    ax.set(xlabel='Oxygen supply (mmol/L)',ylabel='Anaerobic species fraction',ylim=(-.03,1));ax.legend()
    ax.set_title('The switch depends on the direction of the oxygen sweep',loc='left',fontsize=12)
    return save(fig,'ecology-hysteresis')
