"""Scientific notebook figures. Every plotted series comes from the saved computations."""
from pathlib import Path
import re
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

HERE=Path(__file__).resolve().parent
COLORS=['#198f83','#7965c1','#df8256','#438bc2','#bb5268']
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,
                     'axes.prop_cycle':plt.cycler(color=COLORS),'svg.fonttype':'none',
                     'figure.dpi':130,'svg.hashsalt':'lecture13-notebook','axes.labelcolor':'#242424','text.color':'#242424',
                     'xtick.color':'#555555','ytick.color':'#555555','axes.edgecolor':'#777777'})

def save(fig,name):
    fig.savefig(HERE/'figures'/f'{name}.png',dpi=160,bbox_inches='tight')
    svg=HERE/'figures'/f'{name}.svg'
    fig.savefig(svg,bbox_inches='tight',transparent=True)
    # The embedded course SVG inherits its host theme. Notebook PNGs stay conventional.
    text=svg.read_text()
    color_map={'#242424':'var(--fg,#242424)','#000000':'var(--fg,#242424)','#555555':'var(--muted,#555555)',
               '#777777':'var(--muted,#777777)','#cccccc':'var(--rule,#cccccc)','#ffffff':'var(--bg2,#ffffff)',
               '#198f83':'var(--teal,#198f83)','#7965c1':'var(--peri,#7965c1)','#df8256':'var(--coral,#df8256)',
               '#438bc2':'var(--blue,#438bc2)','#bb5268':'var(--rose,#bb5268)'}
    for old,new in color_map.items():text=text.replace(old,new)
    identifiers=re.findall(r'id="([^"]+)"',text)
    for old in identifiers:
        new='l13nb-'+name+'-'+old
        text=text.replace('id="'+old+'"','id="'+new+'"').replace('url(#'+old+')','url(#'+new+')').replace('href="#'+old+'"','href="#'+new+'"')
    svg.write_text(text)
    return fig

def diagram(name):
    """Render an archived diagram on its own light canvas in any notebook theme."""
    from IPython.display import SVG
    from xml.etree import ElementTree as ET
    namespace='http://www.w3.org/2000/svg'
    ET.register_namespace('',namespace)
    root=ET.fromstring((HERE/'figures'/name).read_text())
    # Standalone SVG images cannot inherit the course page's theme. Declare the
    # canvas and ink together. The archived theme-aware source stays unchanged.
    root.set('style',root.get('style','')+';background:#fff;--fg:#20201e;--muted:#6e665f;--bg:#fff;--bg2:#f2eee7')
    root.insert(0,ET.Element('{'+namespace+'}rect',{'width':'100%','height':'100%','fill':'#fff'}))
    return SVG(data=ET.tostring(root,encoding='unicode'))

def growth_horizons(cases):
    fig,axs=plt.subplots(2,2,figsize=(12.3,8.7))
    fig.subplots_adjust(left=.095,right=.97,bottom=.16,top=.80,wspace=.30,hspace=.43)
    for key,color in [('0.1',COLORS[4]),('2.0',COLORS[0])]:
        d=cases[key];t=np.array(d['t']);x=np.array(d['x']);u=np.array(d['u'])
        label=f"Prediction horizon {d['horizon']:g}"
        edges=np.arange(len(u)+1)*d['interval']
        axs[0,0].stairs(u[:,1],edges,color=color,lw=2.8,label=label,baseline=None)
        axs[0,1].plot(t,x[:,1],color=color,lw=2.8)
        axs[1,0].plot(t,x[:,0],color=color,lw=2.8)
        axs[1,1].plot(t,np.exp(x[:,2]),color=color,lw=2.8)
    axs[0,1].axhline(.75,color='#777777',ls=':',lw=1.5)
    axs[0,1].text(2.05,.758,'Declared ATP floor',color='#777777',fontsize=12)
    bad=cases['0.1'];x=np.array(bad['x']);t=np.array(bad['t'])
    for ax,value in [(axs[0,1],x[-1,1]),(axs[1,0],x[-1,0]),(axs[1,1],np.exp(x[-1,2]))]:
        ax.scatter([t[-1]],[value],color=COLORS[4],marker='X',s=95,zorder=5)
    for ax,label,title in zip(axs.ravel(),['Chosen growth activity','ATP concentration',
                         'Intermediate concentration','Biomass / initial biomass'],
                        ['A  Spend on growth now, or pause?','B  Can the ATP floor be preserved?',
                         'C  The intermediate supports future payoff','D  Growth is rewarded at every horizon']):
        ax.set(xlabel='Elapsed time (normalized)',ylabel=label,xlim=(0,4),title=title)
        ax.title.set_size(13);ax.tick_params(labelsize=12);ax.yaxis.labelpad=10
    axs[0,0].set_ylim(-.04,1.05)
    handles,labels=axs[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper left',bbox_to_anchor=(.085,.915),frameon=False,fontsize=14,ncol=2)
    fig.suptitle('Short planning can spend the reserve needed for continued viability',
                 fontsize=18,weight='bold',x=.095,ha='left',y=.99)
    fig.text(.095,.94,'Same terminal-biomass objective. Replan every 0.1 time units from the observed state.',fontsize=12.5)
    fig.text(.095,.075,'× at t = 0.4: an analytical bound proves that the short policy has no viable continuation.',fontsize=12.5)
    fig.text(.095,.035,'The ATP floor defines viability in this teaching model. Cell death is not a measured output.',fontsize=12.5)
    return save(fig,'growth-horizon-viability')

def allocation_smoothing(cases):
    fig,axs=plt.subplots(3,2,figsize=(12.3,10.6))
    fig.subplots_adjust(left=.09,right=.97,bottom=.17,top=.82,wspace=.28,hspace=.38)
    for col,kind in enumerate(['upshift','downshift']):
        for weight,color in [(0,COLORS[0]),(.02,COLORS[1]),(.2,COLORS[2])]:
            d=cases[f'{kind}_penalty{weight:g}'];t=np.array(d['t'])
            edges=np.linspace(0,d['horizon'],len(d['rho'])+1)
            axs[0,col].stairs(d['rho'],edges,color=color,lw=2.7,label=f'Change cost γ = {weight:g} h',baseline=None)
            axs[1,col].plot(t,d['growth'],color=color,lw=2.7)
            axs[2,col].plot(t,d['biomass'],color=color,lw=2.7)
        axs[0,col].set_title(kind.capitalize()+': the same nutrient step',fontsize=15)
        for row,label in enumerate(['New protein sent to ribosomes','Specific growth (h⁻¹)','Biomass / initial biomass']):
            axs[row,col].set(xlim=(0,8),ylabel=label)
            axs[row,col].tick_params(labelsize=12);axs[row,col].yaxis.labelpad=10
        axs[0,col].set_ylim(-.03,1.03)
        axs[-1,col].set_xlabel('Time after shift (h)',fontsize=13)
    handles,labels=axs[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper left',bbox_to_anchor=(.08,.915),frameon=False,fontsize=13,ncol=3)
    fig.suptitle('Charging for allocation changes smooths the action and costs biomass',
                 x=.09,ha='left',y=.99,fontsize=18,weight='bold')
    fig.text(.09,.945,'Keep the plant, eight-hour horizon, viability limits and nutrient conditions fixed.',fontsize=13)
    fig.text(.09,.061,'All curves are computed examples. The penalty is a declared control cost, not a fitted physiological law.',fontsize=12)
    fig.text(.09,.027,'A finite endpoint can still favor reserve spending. Smoother control does not identify the biological objective.',fontsize=12)
    return save(fig,'allocation-smoothing')

def biomass(table):
    rows=table.head(22).iloc[::-1]
    fig,ax=plt.subplots(figsize=(9,6.8),layout='constrained')
    ax.barh(np.arange(len(rows)),rows.coefficient,color=[COLORS[0] if v<0 else COLORS[2] for v in rows.coefficient])
    ax.set_yticks(np.arange(len(rows)),[str(n)[:45]+' ['+i+']' for i,n in zip(rows.id,rows.name)],fontsize=9)
    ax.axvline(0,color='#777777',lw=.8)
    ax.set_xlabel('Signed coefficient per biomass-reaction unit')
    ax.set_title('Largest absolute biomass coefficients include energy bookkeeping',loc='left',fontsize=13)
    return save(fig,'biomass-ranked')

def batch(result):
    fig,axs=plt.subplots(1,2,figsize=(10,3.6),layout='constrained')
    axs[0].plot(result['t'],result['glucose']);axs[0].set(ylabel='External glucose (mmol/L)',xlabel='Time (h)')
    axs[1].plot(result['t'],result['biomass']);axs[1].set(ylabel='Biomass (gDW/L)',xlabel='Time (h)')
    for ax in axs:
        if result.get('depleted',True):
            ax.axvline(result['stop_time'],ls=':',color='#777777')
        ax.set_xlim(result['t'][0],result['t'][-1])
    fig.suptitle('External resource depletion changes each successive FBA optimum',fontsize=13)
    return save(fig,'batch-dfba')

def proteome(result):
    a=result['values'];fig,axs=plt.subplots(1,2,figsize=(10,3.8),layout='constrained')
    axs[0].plot(a[:,0],a[:,2],ls='--',color='#777777',label='Without protein budget')
    axs[0].plot(a[:,0],a[:,1],label='With protein budget')
    axs[0].set(ylabel='Growth rate (1/h)',xlabel='Uptake capacity (normalized units)');axs[0].legend(fontsize=9)
    axs[1].plot(a[:,0],a[:,3],label='Respiration');axs[1].plot(a[:,0],a[:,4],label='Fermentation')
    axs[1].set(ylabel='Pathway flux (normalized units)',xlabel='Uptake capacity (normalized units)');axs[1].legend(fontsize=9)
    for ax in axs:ax.axvline(result['overflow_threshold'],ls=':',color=COLORS[2])
    fig.suptitle('A protein budget can favor a lower-yield pathway',fontsize=13)
    return save(fig,'proteome-overflow')

def mori(curves):
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    for d in curves:
        label=f"Initial ribosome fraction {d['phi_initial']:.2f}"
        axs[0].plot(d['t'],d['growth'],label=label);axs[1].plot(d['t'],d['mass'],label=label)
    axs[0].set(ylabel='Growth rate (1/h)',xlabel='Time after rich-medium upshift (h)');axs[0].legend(fontsize=8)
    axs[1].set(ylabel='Protein mass / initial protein mass',xlabel='Time after rich-medium upshift (h)',yscale='log')
    axs[1].set_ylim(1,1000);axs[1].set_yticks([1,10,100,1000]);axs[1].yaxis.set_major_formatter(FuncFormatter(lambda value,pos:f'{value:g}'))
    axs[1].set_ylabel('Protein mass / initial protein mass',labelpad=14)
    fig.suptitle('The initial ribosome inventory sets the immediate upshift response',fontsize=13)
    return save(fig,'mori-upshift')

def reserves(curves):
    fig=plt.figure(figsize=(12.4,8.3))
    grid=fig.add_gridspec(1,2,left=.09,right=.97,bottom=.47,top=.81,wspace=.30)
    axs=[fig.add_subplot(grid[0,i]) for i in range(2)]
    for d,color in zip(curves,COLORS):
        label=f"Reserve {100*d['reserve']:g}%"
        axs[0].plot(d['t'],d['growth'],label=label,color=color,lw=3.2)
        axs[1].semilogy(d['t'],d['mass'],color=color,lw=3.2)
    axs[0].set(ylabel='Specific growth rate (h⁻¹)',xlabel='Time after upshift (h)',
               title='A  More reserve helps first, then costs growth')
    axs[1].set(ylabel='Protein mass / its initial value',xlabel='Feast duration (h)',
               title='B  Integrate growth over the whole feast')
    axs[1].set_yticks([1,10,100,1000,10000,100000,1000000])
    axs[1].yaxis.set_major_formatter(FuncFormatter(lambda value,pos:f'{value:,.0f}'))
    for ax in axs:
        ax.tick_params(labelsize=12);ax.yaxis.labelpad=10
        ax.xaxis.label.set_size(13);ax.yaxis.label.set_size(13)
        ax.title.set_size(13)
        ax.set_xlim(0,max(d['t'][-1] for d in curves))
    handles,labels=axs[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper left',bbox_to_anchor=(.08,.925),
               ncol=len(curves),frameon=False,fontsize=15,handlelength=2.5)
    fig.suptitle('Which reserve wins depends on how long the feast lasts',
                 x=.09,ha='left',y=.985,fontsize=19,weight='bold')
    fig.text(.09,.933,'Equal initial protein mass. The same color denotes the same reserve in every panel.',fontsize=13)
    horizons=[.5,3.,6.]
    values=np.array([[np.interp(t,d['t'],d['mass']) for t in horizons] for d in curves])
    fig.text(.09,.35,'C  Read the accumulated protein mass directly',fontsize=15,weight='bold')
    fig.text(.09,.312,'Each number is a fold increase from 1. Outlined values are largest at that horizon.',fontsize=12.5)
    xs=[.43,.65,.87]
    fig.text(.10,.259,'Reserve fraction',fontsize=13,weight='bold')
    for x,t in zip(xs,horizons):fig.text(x,.259,f'After {t:g} h',ha='center',fontsize=13,weight='bold')
    for i,(d,color) in enumerate(zip(curves,COLORS)):
        y=.211-.047*i
        fig.text(.10,y,f"{100*d['reserve']:g}%",fontsize=14,color=color,weight='bold')
        for j,x in enumerate(xs):
            v=values[i,j]
            box=dict(boxstyle='round,pad=.25',facecolor='none',edgecolor=color,lw=1.8) if i==values[:,j].argmax() else None
            fig.text(x,y,f'{v:.3f}×' if v<10 else f'{v:,.0f}×',ha='center',fontsize=14,color=color,bbox=box)
    fig.text(.09,.045,'Source-based thought experiment. Nutrients remain plentiful for the entire chosen feast.',fontsize=12.5)
    return save(fig,'mori-reserve')

def erickson_matched(curves):
    fig=plt.figure(figsize=(12.4,7.1))
    grid=fig.add_gridspec(1,2,left=.085,right=.97,bottom=.28,top=.73,wspace=.31)
    axs=[fig.add_subplot(grid[0,i]) for i in range(2)]
    for d,color in zip(curves,[COLORS[2],COLORS[0]]):
        label='Upshift: fewer inherited ribosomes' if d['kind']=='upshift' else 'Downshift: more inherited ribosomes'
        axs[0].plot([-.3,0],[d['growth_before']]*2,color=color,lw=3.2)
        axs[0].plot([0,0],[d['growth_before'],d['growth'][0]],color=color,lw=2.0)
        axs[0].plot(d['t'],d['growth'],color=color,lw=3.2,label=label)
        axs[1].plot([-.3,0],[d['phi'][0]]*2,color=color,lw=3.2)
        axs[1].plot(d['t'],d['phi'],color=color,lw=3.2)
    for ax in axs:
        ax.axvspan(0,1/6,color='#777777',alpha=.13)
        ax.set_xlim(-.3,6);ax.set_xlabel('Time from environmental shift (h)',fontsize=13)
        ax.tick_params(labelsize=12);ax.yaxis.labelpad=10
    axs[0].set(ylabel='Specific growth rate (h⁻¹)',ylim=(.2,1.02),title='A  Same growth just after the shift')
    axs[1].set(ylabel='Ribosomal protein / total protein',ylim=(.06,.15),title='B  Different machinery already present')
    for ax in axs:ax.title.set_size(14);ax.yaxis.label.set_size(13)
    axs[0].set_yticks([.3,.5,.7,.95]);axs[1].set_yticks([.07,.09,.11,.13,.15])
    handles,labels=axs[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper left',bbox_to_anchor=(.075,.90),frameon=False,fontsize=14,ncol=1)
    fig.suptitle('Inherited ribosomes can make downshift recovery faster',x=.085,ha='left',y=.99,fontsize=19,weight='bold')
    fig.text(.085,.93,'Both start at 0.30 h⁻¹ after the change and approach 0.95 h⁻¹. Only the inherited state differs.',fontsize=13)
    fig.text(.085,.183,'Upshift: build more ribosomes while growing.',fontsize=13,color=COLORS[2],weight='bold')
    fig.text(.085,.139,'Downshift: existing ribosomes accelerate synthesis of the needed catabolic proteins.',fontsize=13,color=COLORS[0],weight='bold')
    fig.text(.085,.095,'Both responses reallocate protein. A fast drop in activity does not require instant protein removal.',fontsize=12.5)
    fig.text(.085,.035,'Erickson et al. (2017), Supplementary Note 6.2. Shaded first 10 min lie outside the slow model’s scope.',fontsize=12)
    return save(fig,'erickson-matched-recovery')

def thermodynamics(cases):
    fig,ax=plt.subplots(figsize=(7,3.7),layout='constrained')
    x=np.arange(2);width=.32
    ax.bar(x-width/2,[cases['no_fuel_fba']['ATP'],cases['fuel_fba']['ATP']],width,label='Stoichiometry and bounds')
    ax.bar(x+width/2,[cases['no_fuel_thermo']['ATP'],cases['fuel_thermo']['ATP']],width,label='Also chemical potentials')
    ax.set_xticks(x,['No supplied fuel','Fuel-coupled ATP capacity = 2']);ax.set_ylabel('Maximum ATP drain (normalized flux)');ax.legend(fontsize=9)
    ax.set_title('Chemical-potential consistency excludes ATP from a closed cycle',loc='left',fontsize=12)
    return save(fig,'thermodynamic-cycle')

def erickson(curves):
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    for ax,d,color in zip(axs,curves,COLORS):
        ax.plot([-.5,0],[d['growth_before']]*2,color=color,ls='--')
        ax.plot([0,0],[d['growth_before'],d['growth'][0]],color=color,ls=':')
        visible=d['t']<=6
        ax.plot(d['t'][visible],d['growth'][visible],color=color)
        ax.axhline(d['growth_final'],color='#777777',ls=':')
        ax.axvspan(0,1/6,color='#777777',alpha=.12)
        ax.set(xlabel='Time after carbon shift (h)',ylabel='Growth rate (1/h)',xlim=(-.5,6),ylim=(0,1))
        ax.tick_params(axis='y',pad=9)
        ax.yaxis.labelpad = 12
        ax.set_title(d['kind'].capitalize()+f": {d['growth_before']:.1f} to {d['growth_final']:.1f} /h",fontsize=11)
    fig.suptitle('Carbon shifts couple translational activity and proteome allocation',fontsize=13)
    return save(fig,'erickson-shifts')

def enzymes(cases,substrates,outputs):
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    axs[0].bar(['FBA','Enzyme\ncapacity','Capacity +\nsaturation'],[d['output'] for d in cases],color=COLORS[:3]);axs[0].set_ylabel('Maximum product flux (normalized units)')
    axs[1].semilogx(substrates,outputs);axs[1].axhline(8,color='#777777',ls='--',label='Enzyme-capacity ceiling')
    axs[1].set_xlim(.001,100);axs[1].set_xticks([.001,.01,.1,1,10,100]);axs[1].xaxis.set_major_formatter(FuncFormatter(lambda value,pos:f'{value:g}'))
    axs[1].set(ylabel='Maximum product flux',xlabel='Substrate pool (normalized concentration)');axs[1].legend(fontsize=9)
    fig.suptitle('Enzyme amount and substrate saturation impose different restrictions',fontsize=13)
    return save(fig,'enzyme-kinetic')

def hybrid(result):
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    axs[0].plot(result['t'],result['pool'],label='Dynamic internal pool');axs[0].plot(result['t'],result['quasisteady_pool'],ls='--',label='Instantaneous steady solution')
    axs[0].set(ylabel='Internal substrate (normalized concentration)',xlabel='Time (normalized)');axs[0].legend(fontsize=9)
    axs[1].plot(result['t'],result['input'],ls='--',label='Input flux');axs[1].plot(result['t'],result['output'],label='Output flux')
    axs[1].set(ylabel='Flux (normalized units)',xlabel='Time (normalized)');axs[1].legend(fontsize=9)
    fig.suptitle('Releasing one internal balance creates a measurable transient',fontsize=13)
    return save(fig,'hybrid-pool')

def fec(curves):
    fig,axs=plt.subplots(1,2,figsize=(10,4.1),layout='constrained')
    for d in curves:
        axs[0].plot(d['t'],d['q'][:,1],label=f"Activity-change penalty {d['penalty']:g}")
        axs[1].plot(d['t'],d['q'][:,0],label=f"Activity-change penalty {d['penalty']:g}")
    axs[0].axhline(.93,ls=':',color='#777777');axs[1].axhline(1/1.1+.07,ls=':',color='#777777')
    axs[0].set(ylabel='ATP pool (normalized)',xlabel='Metabolic time (normalized)')
    axs[1].set(ylabel='Intermediate pool (normalized)',xlabel='Metabolic time (normalized)')
    fig.suptitle('Structured catalytic dynamics remain while activities are optimized',fontsize=13)
    fig.legend(*axs[0].get_legend_handles_labels(),loc='outside lower center',ncol=2,fontsize=9)
    return save(fig,'fec-pools')

def ecology_cstr(curves):
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    for ax,(name,d) in zip(axs,curves.items()):
        visible=d['t']<=150
        ax.plot(d['t'][visible],d['biomass'][visible,0],label='Facultative species A')
        ax.plot(d['t'][visible],d['biomass'][visible,1],label='Anaerobic species B')
        ax.set(title=name,xlabel='Time (h)',ylabel='Biomass (gDW/L)',xlim=(0,150));ax.legend(fontsize=9)
    fig.suptitle('The same continuous feed can support two community states',fontsize=13)
    return save(fig,'ecology-cstr')

def ecology_serial(curves):
    from ecology_plot import serial_figure
    values=list(curves.values())
    params=values[0]['metadata']['parameters']
    fig=serial_figure({'low':values[0], 'high':values[1]},
                      batch_duration=params['batch_duration'],
                      retained_fraction=params['retained_fraction'])
    return save(fig,'ecology-serial')


def ecology_hysteresis(curves):
    fig,ax=plt.subplots(figsize=(7,3.8),layout='constrained')
    for name,d in curves.items():ax.plot(d['feed'],d['composition'],'o-',ms=3,label=name)
    ax.set(xlabel='Oxygen supply (mmol/L)',ylabel='Anaerobic species fraction',ylim=(-.03,1));ax.legend()
    ax.set_title('The switch depends on the direction of the oxygen sweep',loc='left',fontsize=12)
    return save(fig,'ecology-hysteresis')


def ecology_comparison(histories, sweeps, oxygen_supply=.2, settling_hours=1000.):
    from ecology_plot import community_figure
    fig=community_figure(histories,sweeps,oxygen_supply=oxygen_supply,settling_hours=settling_hours)
    return save(fig,'ecology-cstr-hysteresis')
