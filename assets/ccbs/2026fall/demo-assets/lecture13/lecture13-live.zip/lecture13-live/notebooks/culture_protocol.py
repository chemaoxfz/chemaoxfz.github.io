"""Two uptake-limited consumers under matched logarithmic cell dilution.

Teaching parameters, not a species fit. Biomass yield is one resource mass unit
per biomass mass unit. R + X_A + X_B = 1 for the specified initial conditions.
The uptake-limited LP optimum is mu_i = V_i R/(K_i+R).
"""
import numpy as np
from scipy.integrate import solve_ivp
from scipy.special import expit

V = np.array([.6, 1.2])        # h^-1
K = np.array([.05, .4])        # resource mass units / volume
FEED = 1.
DILUTION = .15                # h^-1
RETENTION = .01
INTERVAL = -np.log(RETENTION)/DILUTION


def growth(resource):
    return V*np.asarray(resource)[..., None]/(K+np.asarray(resource)[..., None])


def rhs(t, state, continuous=False):
    log_resource, log_odds = state
    resource = np.exp(log_resource)
    fraction = expit(log_odds)
    per_resource = V/(K+resource)
    uptake_per_resource = (FEED-resource)*(fraction*per_resource[0]
                                          +(1-fraction)*per_resource[1])
    dlog_resource = -uptake_per_resource
    if continuous:
        dlog_resource += DILUTION*(FEED/resource-1)
    return [dlog_resource, resource*(per_resource[0]-per_resource[1])]


def simulate(protocol="serial", cycles=24, rtol=1e-10, atol=1e-12):
    initial = np.array([np.log(.99), 0.])
    times, states = [], []
    if protocol == "continuous":
        t = np.linspace(0, cycles*INTERVAL, 1501)
        solution = solve_ivp(lambda t, y: rhs(t, y, True), [0, t[-1]], initial,
                             t_eval=t, method="DOP853", rtol=rtol, atol=atol)
        assert solution.success
        times, states = solution.t, solution.y.T
    else:
        n = 1 if protocol == "batch" else cycles
        for cycle in range(n):
            t = np.linspace(0, INTERVAL, 241)
            solution = solve_ivp(rhs, [0, INTERVAL], initial, t_eval=t,
                                 method="DOP853", rtol=rtol, atol=atol)
            assert solution.success
            times.extend(t+cycle*INTERVAL)
            states.extend(solution.y.T)
            final = solution.y[:, -1]
            resource_after = RETENTION*np.exp(final[0])+(1-RETENTION)*FEED
            initial = np.array([np.log(resource_after), final[1]])
    times, states = np.asarray(times), np.asarray(states)
    resource = np.exp(states[:, 0])
    fraction = expit(states[:, 1])
    biomass = np.column_stack(((FEED-resource)*fraction, (FEED-resource)*(1-fraction)))
    return dict(time=times, generations=DILUTION*times/np.log(2),
                resource=resource, fraction_A=fraction, biomass=biomass,
                log_odds=states[:, 1])


def resident_cycle(resident):
    """Analytic endpoints and rare-invader multiplier on a resident cycle."""
    f, S, L = RETENTION, FEED, -np.log(RETENTION)
    a = S/K[resident]*(V[resident]*INTERVAL-(1+K[resident]/S)*L)
    assert a > 0
    q = np.exp(-a)
    end = (1-f)*S*q/(1-f*q)
    start = (1-f)*S+f*end
    invader = 1-resident
    a_partial = (K[resident]-K[invader])/(S+K[invader])
    b_partial = (S+K[resident])/(S+K[invader])
    integrated_growth = V[invader]/V[resident]*(
        a_partial*np.log((K[invader]+start)/(K[invader]+end))+b_partial*L)
    return dict(resident=resident, invader=invader, resource_start=start,
                resource_end=end, log_multiplier=integrated_growth-L,
                multiplier=float(np.exp(integrated_growth-L)))


def continuous_invasion():
    roots = K*DILUTION/(V-DILUTION)
    return dict(break_even_resource=roots.tolist(),
                B_into_A=float(growth(roots[0])[1]-DILUTION),
                A_into_B=float(growth(roots[1])[0]-DILUTION))
