"""Offline notebook HTML shared by the portable bundle and course exporter.

The course builder renders the marked LaTeX. The portable exporter uses
latex2mathml in Python, so opening its HTML needs no CDN or Python kernel.
"""
from pathlib import Path
import hashlib
import html
import re
import sys
from bs4 import BeautifulSoup, NavigableString
import nbformat
from nbconvert import HTMLExporter

MATH = re.compile(r"\$\$(.+?)\$\$|(?<!\\)\$([^$\n]+?)(?<!\\)\$", re.S)

STYLE = '<style>\n.nb-document{max-width:56rem!important;min-width:0}\n.nb-document .jp-Cell{margin:1.35rem 0;min-width:0}\n.nb-document .jp-InputArea,.nb-document .jp-OutputArea-child{display:grid;grid-template-columns:4.5rem minmax(0,1fr);gap:.6rem;align-items:start;min-width:0}\n.nb-document .jp-MarkdownCell .jp-InputArea{display:block}\n.nb-document .jp-InputPrompt,.nb-document .jp-OutputPrompt{padding:.8rem 0;font:12px/1.6 var(--mono);color:var(--muted);text-align:right;white-space:nowrap}\n.nb-document .jp-OutputPrompt{color:var(--teal)}\n.nb-document .jp-CodeMirrorEditor{min-width:0;border:1px solid var(--rule);border-radius:7px;background:var(--bg2);overflow-x:auto}\n.nb-document pre{font:13px/1.65 var(--mono);white-space:pre;tab-size:4;margin:0;padding:.85rem 1rem;overflow-x:auto;color:var(--fg)}\n.nb-document .jp-Cell-outputWrapper{margin:.55rem 0 1.8rem}\n.nb-document .jp-OutputArea-child{margin:.5rem 0}\n.nb-document .jp-OutputArea-output{grid-column:2;min-width:0;max-width:100%;overflow-x:auto}\n.nb-document .jp-RenderedHTML{padding:.35rem 0}\n.nb-document table{width:auto;min-width:60%;font-size:13px;background:var(--bg2)}\n.nb-document th,.nb-document td{padding:.45rem .6rem;text-transform:none;letter-spacing:0;font-size:inherit}\n.nb-document .jp-RenderedImage{background:#fff;border:1px solid var(--rule);border-radius:7px;padding:.35rem}\n.nb-document img{display:block;max-width:100%;height:auto;margin:0 auto;background:#fff;border-radius:5px}\n.nb-document .jp-RenderedMarkdown code{font: .85em var(--mono);overflow-wrap:anywhere;background:var(--bg2);padding:.08em .25em;border-radius:3px}\n.nb-document h2{font-size:1.2rem;line-height:1.4;margin-top:3.4rem;padding-top:1rem;border-top:1px solid var(--rule)}\n.nb-document h3{line-height:1.45}\n.nb-document .nb-k,.nb-document .nb-kn,.nb-document .nb-kc,.nb-document .nb-kd{color:var(--plum);font-weight:600}\n.nb-document .nb-s,.nb-document .nb-s1,.nb-document .nb-s2,.nb-document .nb-sa,.nb-document .nb-sr{color:var(--teal)}\n.nb-document .nb-c1,.nb-document .nb-cm{color:var(--muted);font-style:italic}\n.nb-document .nb-mi,.nb-document .nb-mf{color:var(--rose)}\n.nb-document .nb-nf,.nb-document .nb-nb{color:var(--peri)}\n.nb-downloads{display:flex;gap:.7rem;flex-wrap:wrap;font:14px/1.45 var(--sans);margin:1rem 0}\n.nb-downloads a{border:1px solid var(--rule);border-radius:6px;padding:.65rem .85rem;background:var(--bg2);text-decoration:none}\n.nb-downloads a:first-child{border-color:var(--teal);color:var(--teal);font-weight:650}\n.nb-intro-note{font:.88rem/1.55 var(--sans);color:var(--muted);margin-bottom:2rem}\n@media(max-width:600px){.nb-document .jp-InputArea,.nb-document .jp-OutputArea-child{grid-template-columns:minmax(0,1fr);gap:0}.nb-document .jp-OutputArea-output{grid-column:1}.nb-document .jp-InputPrompt,.nb-document .jp-OutputPrompt{text-align:left;padding:.2rem 0}.nb-document .nb-empty-prompt{display:none}.nb-document pre{font-size:12px;padding:.7rem}.nb-document .m{display:inline-block;max-width:100%;overflow-x:auto;vertical-align:middle}}\n@media print{.nb-downloads{display:none}.nb-document pre{white-space:pre-wrap;overflow-wrap:anywhere}.nb-document .jp-Cell{break-inside:avoid}.nb-document .jp-OutputArea-output{overflow:visible}}\n</style>'

def mark_math(soup):
    """Mark only rendered Markdown text. Python and output literals stay exact."""
    count = 0
    for block in soup.select(".jp-MarkdownOutput"):
        for node in list(block.find_all(string=True)):
            if node.find_parent(["code", "pre", "script", "style"]):
                continue
            value = str(node)
            cursor = 0
            parts = []
            for match in MATH.finditer(value):
                parts.append(NavigableString(value[cursor:match.start()]))
                tag = soup.new_tag("div" if match[1] else "span")
                tag["class"] = "eq" if match[1] else "m"
                tag.string = (match[1] or match[2]).strip()
                parts.append(tag)
                cursor = match.end()
                count += 1
            if parts:
                parts.append(NavigableString(value[cursor:]))
                node.replace_with(*parts)
        # A display formula is a block, not a div nested inside a paragraph.
        for paragraph in list(block.find_all("p")):
            if not paragraph.find("div", class_="eq", recursive=False):
                continue
            replacement = []
            current = soup.new_tag("p")
            for child in list(paragraph.contents):
                if getattr(child, "name", None) == "div" and child.get("class") == ["eq"]:
                    if current.get_text().strip():
                        replacement.append(current)
                    replacement.append(child.extract())
                    current = soup.new_tag("p")
                else:
                    current.append(child.extract())
            if current.get_text().strip():
                replacement.append(current)
            paragraph.replace_with(*replacement)
    return count


STYLE += '''<style>
.nb-toolbar{display:flex;flex-wrap:wrap;gap:.6rem;align-items:center;margin:1rem 0;font:14px/1.5 var(--sans)}
.nb-toolbar button,.nb-enlarge,.nb-viewer button{font:inherit;color:var(--fg);background:var(--bg2);border:1px solid var(--rule);border-radius:5px;padding:.4rem .7rem;cursor:pointer}
.nb-toolbar button:focus-visible,.nb-enlarge:focus-visible,.nb-viewer button:focus-visible,summary:focus-visible{outline:2px solid var(--teal);outline-offset:3px}
.nb-document details.nb-code{margin:0;padding:0;border:0;max-width:none;background:transparent}
.nb-code>summary{font:12px/1.5 var(--mono);color:var(--muted);cursor:pointer;padding:.3rem 0}
.nb-code>summary:hover{color:var(--fg)}
.nb-enlarge{grid-column:2;justify-self:start;font:12px/1.4 var(--sans);margin:.2rem 0 .6rem}
.nb-viewer{box-sizing:border-box;width:calc(100vw - 2rem);max-width:1500px;max-height:94vh;border:1px solid var(--rule);border-radius:9px;background:var(--bg);color:var(--fg);padding:1rem}
.nb-viewer::backdrop{background:rgba(0,0,0,.7)}
.nb-viewer header{display:flex;gap:.7rem;align-items:center;flex-wrap:wrap;font:14px/1.4 var(--sans);margin-bottom:.8rem}
.nb-viewer header p{margin:0;flex:1;min-width:12rem}
.nb-viewer .nb-viewer-image{overflow:auto;max-height:74vh;background:white;border-radius:5px}
.nb-viewer img{display:block;max-width:100%;height:auto;margin:auto}
.nb-viewer[data-size="actual"] img{max-width:none;margin:0}
.nb-document .eq{overflow-x:auto;max-width:100%;padding:.8rem .15rem}
.nb-document a:focus-visible{outline:2px solid var(--teal)}
@media(max-width:600px){.nb-enlarge{grid-column:1}.nb-viewer{padding:.6rem}.nb-toolbar{font-size:13px}}
@media print{.nb-toolbar,.nb-enlarge,.nb-viewer,.nb-code>summary{display:none!important}.nb-code>.jp-InputArea{display:grid!important}}
</style>'''

CONTROLS = '''<div class="nb-toolbar" role="group" aria-label="Notebook reading controls">
<button type="button" data-nb-action="hide">Hide all code</button>
<button type="button" data-nb-action="show">Show all code</button>
<span>Explanations and results stay visible.</span></div>'''
VIEWER = '''<dialog class="nb-viewer" id="nb-figure-viewer" aria-labelledby="nb-figure-title" data-size="fit">
<header><p id="nb-figure-title">Notebook figure</p><button type="button" data-nb-action="fit">Fit width</button><button type="button" data-nb-action="actual">Original size</button><button type="button" data-nb-action="close">Close</button></header><div class="nb-viewer-image"></div></dialog>'''
SCRIPT = '''<script>
(()=>{
const viewer=document.getElementById('nb-figure-viewer');
document.addEventListener('click',event=>{
 const button=event.target.closest('button[data-nb-action],button.nb-enlarge');
 if(!button)return;
 const action=button.dataset.nbAction;
 if(action==='hide'||action==='show'){
  document.querySelectorAll('.nb-code').forEach(d=>{d.open=action==='show'});
 }else if(button.classList.contains('nb-enlarge')){
  const original=document.getElementById(button.dataset.figure);
  const copy=original.cloneNode(); copy.removeAttribute('id'); copy.loading='eager';
  viewer.querySelector('.nb-viewer-image').replaceChildren(copy);
  document.getElementById('nb-figure-title').textContent=original.alt;
  viewer.dataset.size='fit'; viewer.showModal();
 }else if(action==='close'){viewer.close();}
 else if(action==='fit'||action==='actual'){viewer.dataset.size=action;}
 else if(action==='theme'){
  const root=document.documentElement;
  root.dataset.theme=root.dataset.theme==='dark'?'light':'dark';
  button.textContent=root.dataset.theme==='dark'?'Use light theme':'Use dark theme';
 }
});
viewer.addEventListener('click',event=>{if(event.target===viewer){
 const r=viewer.getBoundingClientRect();
 if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)viewer.close();
}});
})();
</script>'''

BASE_STYLE = '''<style>
:root{--bg:#faf8f4;--bg2:#f2eee7;--fg:#20201e;--muted:#6e665f;--rule:#d9d0c6;--teal:#08776c;--peri:#5a73ce;--plum:#77488c;--rose:#b54557;--mono:ui-monospace,SFMono-Regular,Consolas,monospace;--sans:system-ui,-apple-system,sans-serif;color-scheme:light}
:root[data-theme="dark"]{--bg:#1e2026;--bg2:#292c34;--fg:#eeece5;--muted:#b8b0a6;--rule:#4a4d56;--teal:#67c9b9;--peri:#a1b1ff;--plum:#c59bd8;--rose:#f198a5;color-scheme:dark}
*{box-sizing:border-box}body{margin:0;padding:2rem 1rem;background:var(--bg);color:var(--fg);font:17px/1.7 var(--sans)}
main{max-width:56rem;margin:auto;min-width:0}h1{font-size:2rem;line-height:1.25}p{margin:1rem 0}a{color:var(--teal)}
.nb-contents{margin:1.5rem 0;padding:1rem;border:1px solid var(--rule);border-radius:7px}.nb-contents ol{margin:.7rem 0;padding-left:1.4rem}.nb-contents summary{cursor:pointer;font-weight:650}
.nb-document table{border-collapse:collapse;max-width:100%;display:block;overflow-x:auto}.nb-document th,.nb-document td{border-bottom:1px solid var(--rule);text-align:left}
.nb-document .m{display:inline-block;max-width:100%;overflow-x:auto;vertical-align:middle}.nb-document math{font-family:math}.nb-document .eq math{margin:0 auto}
@media(max-width:600px){body{font-size:16px;padding:1.2rem .8rem}h1{font-size:1.65rem}}
</style>'''


def prepare_notebook(notebook):
    """Return marked HTML, preserving notebook cells, code and saved outputs."""
    templates=str(Path(sys.base_prefix)/'share/jupyter/nbconvert/templates')
    exported,_=HTMLExporter(template_name='lab',extra_template_basedirs=[templates],
                            extra_template_paths=[templates]).from_notebook_node(notebook)
    soup=BeautifulSoup(exported,'html.parser')
    body=soup.body.find('main').extract()
    body.name='div';body['class']='nb-document';body['id']='notebook'
    for tag in body.select('script,style,.jp-Collapser,.anchor-link'):tag.decompose()
    for tag in body.select('[tabindex]'):del tag['tabindex']
    for tag in body.select('.highlight span[class]'):
        tag['class']=['nb-'+value for value in tag['class']]
    for tag in body.select('.jp-InputPrompt,.jp-OutputPrompt'):
        if not tag.get_text().strip():
            tag['class'] += ['nb-empty-prompt'];tag['aria-hidden']='true'
    title=body.h1.get_text();body.h1.decompose()
    headings=[];old_ids={}
    for index,heading in enumerate(body.find_all('h2'),1):
        anchor='notebook-sources' if heading.get_text().strip()=='Source and model notes' else f'notebook-{index}'
        if heading.get('id'):old_ids[heading['id']]=anchor
        heading['id']=anchor;headings.append((anchor,heading.get_text()))
    for a in body.select('a[href^="#"]'):
        if a['href'][1:] in old_ids:a['href']='#'+old_ids[a['href'][1:]]
    for cell in body.select('.jp-CodeCell'):
        input_area=cell.select_one('.jp-InputArea')
        details=soup.new_tag('details',attrs={'class':'nb-code','open':''})
        summary=soup.new_tag('summary')
        prompt=cell.select_one('.jp-InputPrompt').get_text().strip().replace('\xa0',' ')
        summary.string=f'Python code · {prompt}'
        input_area.wrap(details);details.insert(0,summary)
    for i,im in enumerate(body.select('img'),1):
        heading=im.find_previous(['h2','h3'])
        im['alt']='Notebook figure: '+(heading.get_text() if heading else 'model result')
        im['loading']='lazy';im['id']=f'nb-image-{i}'
        button=soup.new_tag('button',attrs={'type':'button','class':'nb-enlarge',
                                          'data-figure':im['id'],'aria-haspopup':'dialog'})
        button.string='Enlarge figure'
        # Keep display controls outside the original output block.
        im.find_parent(class_='jp-OutputArea-child').append(button)
    fragment=BeautifulSoup(str(body),'html.parser')
    count=mark_math(fragment)
    return fragment,title,headings,count


def export_portable(path):
    """Create a standalone HTML preview from the currently executed notebook."""
    from latex2mathml.converter import convert
    notebook=nbformat.read(path,4)
    code=[c for c in notebook.cells if c.cell_type=='code']
    if any(c.execution_count is None for c in code):
        raise ValueError('Execute the notebook before exporting its saved results.')
    if any(o.output_type=='error' for c in code for o in c.outputs):
        raise ValueError('Resolve execution errors before exporting.')
    fragment,title,headings,count=prepare_notebook(notebook)
    for tag in fragment.select('.m,.eq'):
        latex=tag.get_text()
        display='block' if 'eq' in tag.get('class',[]) else 'inline'
        math=BeautifulSoup(convert(latex,display=display),'html.parser').math
        semantics=fragment.new_tag('semantics')
        for node in list(math.contents):semantics.append(node.extract())
        annotation=fragment.new_tag('annotation',attrs={'encoding':'application/x-tex'})
        annotation.string=latex;semantics.append(annotation);math.append(semantics)
        tag.clear();tag.append(math)
    contents=''.join(f'<li><a href="#{anchor}">{html.escape(text)}</a></li>' for anchor,text in headings)
    sha=hashlib.sha256(path.read_bytes()).hexdigest()
    result=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title>{BASE_STYLE}{STYLE}</head><body><main>
<!--NOTEBOOK-SHA256:{sha}-->
<h1>{html.escape(title)}</h1><p>Executed notebook with saved results. Mathematics, diagrams and plots are embedded. This page works offline. To change a calculation, open the accompanying Jupyter notebook.</p>
<div class="nb-downloads"><a href="lecture13-live-tutorial.ipynb" download>Notebook file</a><a href="https://chemaoxfz.github.io/assets/ccbs/2026fall/lecture13-core.html">Lecture 13 core online</a></div>
<div class="nb-toolbar"><button type="button" data-nb-action="theme">Use dark theme</button></div>{CONTROLS}
<details class="nb-contents"><summary>Choose an experiment</summary><ol>{contents}</ol></details>
{fragment}</main>{VIEWER}{SCRIPT}</body></html>'''
    output=path.with_suffix('.html');output.write_text(result)
    return {'html':output.name,'math_expressions':count,'offline':True,'notebook_sha256':sha}


if __name__=='__main__':
    print(export_portable(Path(__file__).with_name('lecture13-live-tutorial.ipynb')))
