# Run Lecture 13 as a live Jupyter tutorial

Open `lecture13-live-tutorial.ipynb` inside the `notebooks` folder. Its saved outputs show the expected results. The package includes the real iJO1366 and E. coli core reconstructions, small model helpers, figures and the sibling `ecology` module. The notebook runs offline after its Python dependencies are installed.

Download and unpack the complete ZIP. The notebook by itself needs the accompanying model and Python files.

## Install and open

Use Python 3.11 or newer. From the unpacked `lecture13-live` folder:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r notebooks/requirements.txt
python -m ipykernel install --user --name ccbs13 --display-name "CCBS Lecture 13"
python -m jupyter lab notebooks/lecture13-live-tutorial.ipynb
```

On Windows, activate with `.venv\Scripts\activate`. Select the **CCBS Lecture 13** kernel. Restart the kernel and run all cells once before teaching. No solver license is needed. COBRApy uses the bundled GLPK interface. The smaller examples use SciPy HiGHS.

## Choose a live route

For a short demonstration, run the setup and Sections 1–4. Inspect PFK, read its ATP coefficient, inspect the biomass reaction and change the oxygen bound. The `with model:` context automatically restores the original bound. Then compare glucose with succinate.

The later sections can be selected independently after setup:

| Section | Experiment | Quantity to change live |
| --- | --- | --- |
| 5 | Batch dynamic FBA | Initial biomass, glucose or uptake half-saturation |
| 6 | Protein budget and overflow | Available protein fraction |
| 7 | Mori rich-medium recovery and Erickson carbon shifts | Initial ribosome fraction or final growth condition |
| 8 | Chemical-potential consistency | Supplied fuel capacity |
| 9 | Enzyme capacity and saturation | Enzyme abundance or substrate pool |
| 10 | A dynamic internal pool | Input step size |
| 11 | Flux exponent control | Penalty on changing enzyme activities |
| 12 | Community persistence and hysteresis | Oxygen supply or inoculation history |

The complete reference notebook executed 29 code cells in about eight seconds on the verification machine. Runtime depends on the environment. The community section uses actual LPs for the continuous-culture trajectories. Its longer serial-dilution and hysteresis sweeps use the exact optimizer of the same small LPs. Set `backend='lp'` to solve those LPs numerically at every integration step.

## Reproduce the checks

From the `notebooks` folder, with the environment activated:

```sh
python generate_results.py
python verify_models.py
python execute_notebook.py
```

`generate_results.py` regenerates the non-ecology arrays and figures. Running the notebook regenerates its community figures. `verify_models.py` performs 571 independent checks. `execute_notebook.py` starts a fresh temporary kernel, saves executed outputs and exports an HTML preview. The scripts do not install a kernel or download data.

For the separate community reference computation, run `python generate_evidence.py` inside the `ecology` folder. It uses actual LPs throughout and takes longer. Its scientific checks cover equilibrium stability, cycle stability, continuation convergence and agreement with the exact optimizer.

`MODEL-NOTES.md` distinguishes published equations from illustrative reductions. `models/PROVENANCE.json` identifies the unchanged model downloads and their checksums. All result tables retain signed coefficients. Biomass coefficients are not mass fractions.
