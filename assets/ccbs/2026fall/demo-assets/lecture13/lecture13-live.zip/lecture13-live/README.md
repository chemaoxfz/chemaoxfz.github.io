# Run Lecture 13 as a live Jupyter tutorial

Open `lecture13-live-tutorial.ipynb` inside the `notebooks` folder. Its saved outputs show the expected results. The package includes the real iJO1366 and E. coli core reconstructions, small model helpers, figures and the sibling `ecology` module. The notebook runs offline after its Python dependencies are installed.

Download and unpack the complete ZIP. The notebook by itself needs the accompanying model and Python files.

## Install and open

Use Python 3.11 or newer. From the unpacked `lecture13-live` folder:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r notebooks/requirements.txt
python -m ipykernel install --user --name ccbs13 --display-name "CCBS Lecture 13"
python -m jupyter lab notebooks/lecture13-live-tutorial.ipynb
```

On Windows, activate with `.venv\Scripts\activate`. Select the **CCBS Lecture 13** kernel. Restart the kernel and run all cells once before teaching. No solver license is needed. COBRApy uses the bundled GLPK interface. The smaller examples use SciPy HiGHS.

## Choose a live route

For a short demonstration, run the setup and Sections 1–4. Inspect PFK, read its ATP coefficient, inspect the biomass reaction and change the oxygen bound. The `with model:` context automatically restores the original bound. Then compare glucose with succinate.

Sections 2–4 also require the model-loading cell in Section 1. Sections 5–18 can each be selected independently after setup. Run the cells within a selected section in order:

| Section | Experiment | Quantity to change live |
| --- | --- | --- |
| 5 | Batch dynamic FBA | Initial biomass, glucose or uptake half-saturation |
| 6 | Community persistence and hysteresis | Oxygen supply or inoculation history |
| 7 | Continuous versus serial culture | Retained fraction and transfer interval |
| 8 | Protein budget and overflow | Available protein fraction |
| 9 | Mori rich-medium recovery and Erickson carbon shifts | Initial ribosome fraction or final growth condition |
| 10 | Hexokinase thermodynamics | ATP/ADP activity ratio |
| 11 | Chemical-potential consistency in a cycle | Supplied fuel capacity |
| 12 | Enzyme capacity, sharing and saturation | Enzyme abundance, competing task or substrate pool |
| 13 | A dynamic internal pool | Input step size |
| 14 | Mechanistic, constraint-based and learned models | Compare the information each imposes |
| 15 | Glycolysis and cart balancing | Feedback gain and state-space matrices |
| 16 | Flux exponent control for ATP regulation | Penalty on changing enzyme activities |
| 17 | Final-biomass growth arrest | ATP viability floor, forced growth activity or receding horizon |
| 18 | Growing machinery and nutrient shifts | Horizon, carbon shift, future-growth discount or allocation-change cost |

The complete reference notebook executes 41 code cells in about eleven seconds on the verification machine. Runtime depends on the environment. The community section uses actual LPs for the continuous-culture trajectories. Its longer serial-dilution and hysteresis sweeps use the exact optimizer of the same small LPs. Set `backend='lp'` to solve those LPs numerically at every integration step.

The two-hour allocation optimization runs live. The longer growth-control comparisons load verified saved results. Use `growth_comparison`, `allocation_comparison` and `shift` to select saved comparisons. Set `RECOMPUTE_GROWTH` or `RECOMPUTE_ALLOCATION` to `True` to rerun both selected conditions. The resulting plots use those newly computed trajectories. Each output states whether it was loaded or recomputed. The slower computations remain explicit. Set `RECOMPUTE_HORIZON=True` for the short-versus-long receding-horizon comparison. Set `RECOMPUTE_SMOOTHING=True` for the eight-hour allocation-change costs. The two-hour live optimization also exposes `change_penalty`.

## Reproduce the checks

From the `notebooks` folder, with the environment activated:

```sh
python generate_results.py
python verify_all.py
python execute_notebook.py
```

`generate_results.py` regenerates the original non-ecology arrays and figures. Running the notebook regenerates its live outputs. `verify_all.py` performs 1,147 independent checks across the original and added models. `execute_notebook.py` starts a fresh temporary kernel, saves executed outputs and exports a self-contained HTML preview with offline MathML. Open `notebooks/lecture13-live-tutorial.html` to read it without a kernel or internet connection. Hide or show code without hiding the results, and use **Enlarge figure** for small labels. `python notebook_html.py` exports the current saved outputs without rerunning the cells. The scripts do not install a kernel or download data.

For the separate community reference computation, run `python generate_evidence.py` inside the `ecology` folder. It uses actual LPs throughout and takes longer. Its scientific checks cover equilibrium stability, cycle stability, continuation convergence and agreement with the exact optimizer.

`MODEL-NOTES.md` and `STAGED-MODEL-NOTES.md` distinguish published equations from illustrative reductions. `models/PROVENANCE.json` identifies the unchanged model downloads and their checksums. All result tables retain signed coefficients. Molecular-weight-weighted biomass entries are signed mass throughput, not automatically composition fractions.

## Read the comparisons correctly

The batch experiment distinguishes an observed glucose-depletion event from the end of a chosen observation window. A missing depletion time means the window ended first. The full window remains visible when initial biomass or duration changes.

Section 17 plots the chosen growth activity, the resulting specific growth, ATP and biomass. Section 18 separates allocation to newly made protein from the current protein composition. Compare horizon-dependent trajectories at the same elapsed time before comparing their endpoints.

The plotting and export tools are teaching aids. The optimal-control solutions retain the assumptions and numerical scope stated in the notebook and model notes. An optimized action sequence is not itself an identified molecular feedback law.

The short-horizon ATP example includes an analytical certificate of lost model viability. The declared ATP floor is not an experimentally calibrated death threshold. In the allocation example, penalizing changes smooths the controls and reduces final biomass. No experimental shift data were fitted.
